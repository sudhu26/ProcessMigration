#!/usr/bin/env python3
"""Deterministic first-pass Oracle SQL -> Spark SQL translation.

Mechanical, local patterns only (NVL, SYSDATE, DUAL, hints, TO_DATE/TO_CHAR
format masks, TRUNC, DECODE). Anything needing context — ROWNUM, CONNECT BY,
old-style (+) joins, sequences, FOR UPDATE, dynamic SQL — is flagged for
human/agent review instead of guessed at.

translate(sql) -> {'original', 'translated', 'applied': [rule names],
                   'flags': [messages], 'confidence': 'high'|'medium'|'needs-review'}
Stdlib only.
"""
import re

_FMT_MAP = {'YYYY': 'yyyy', 'YY': 'yy', 'MM': 'MM', 'DD': 'dd', 'HH24': 'HH',
            'HH12': 'hh', 'MI': 'mm', 'SS': 'ss', 'MON': 'MMM', 'MONTH': 'MMMM',
            'DY': 'EEE', 'DAY': 'EEEE'}
_DBMS_UTL_PAT = re.compile(r'\b(DBMS_|UTL_)[\w$]+\b', re.I)
_FLAG_PATTERNS = [
    (re.compile(r'\bROWNUM\b', re.I),
     'ROWNUM: rewrite with ROW_NUMBER() OVER (ORDER BY ...) — needs ORDER BY context'),
    (re.compile(r'\b(CONNECT\s+BY|START\s+WITH)\b', re.I),
     'CONNECT BY: rewrite as a recursive CTE'),
    (re.compile(r'\(\+\)'),
     '(+) outer join: rewrite as LEFT/RIGHT JOIN'),
    (re.compile(r'\b(NEXTVAL|CURRVAL)\b', re.I),
     'sequence (NEXTVAL/CURRVAL): no Spark equivalent — use monotonically_increasing_id or a lookup table'),
    (re.compile(r'\bFOR\s+UPDATE\b', re.I),
     'FOR UPDATE: no row locking in Spark — check transaction semantics'),
    (re.compile(r'\bEXECUTE\s+IMMEDIATE\b', re.I),
     'EXECUTE IMMEDIATE: dynamic SQL must be resolved before translation'),
    (re.compile(r'\bMODEL\b', re.I),
     'MODEL clause: no Spark equivalent — rewrite'),
    (re.compile(r'\bPIVOT\b', re.I),
     'PIVOT: rewrite with conditional aggregation'),
    (_DBMS_UTL_PAT,
     'DBMS_/UTL_ call: no Spark equivalent — rewrite in Java/Spark'),
    (re.compile(r'\bMERGE\s+INTO\b', re.I),
     'MERGE: review — Spark MERGE syntax differs in places'),
    (re.compile(r'\bBULK\s+COLLECT\b|\bFORALL\b', re.I),
     'BULK COLLECT / FORALL: procedural construct — rewrite as set-based Spark ops'),
]


def split_top_commas(s):
    parts, depth, cur = [], 0, ''
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        if ch == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return parts


def _find_calls(sql, name):
    """Yield (start, end, [args]) for name(...) calls, balanced parens."""
    for m in re.finditer(r'\b' + name + r'\s*\(', sql, re.I):
        i, depth = m.end(), 1
        while i < len(sql) and depth > 0:
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            i += 1
        yield m.start(), i, split_top_commas(sql[m.end():i - 1])


def _replace_calls(sql, name, fn, applied, flags, rule):
    """Apply fn(args) -> replacement (or None to leave unchanged) to every
    name(...) call, right-to-left so offsets stay valid."""
    calls = list(_find_calls(sql, name))
    if not calls:
        return sql
    changed = False
    for start, end, args in reversed(calls):
        rep = fn([a.strip() for a in args])
        if rep is not None:
            sql = sql[:start] + rep + sql[end:]
            changed = True
    if changed:
        applied.append(rule)
    return sql


def _map_fmt(mask):
    """Map an Oracle date-format mask to a Spark/Java mask, or None if it
    contains tokens we do not know."""
    raw = mask.strip().strip("'")
    out, i, known = '', 0, True
    toks = sorted(_FMT_MAP, key=len, reverse=True)
    while i < len(raw):
        if not raw[i].isalpha():
            out += raw[i]
            i += 1
            continue
        hit = None
        for t in toks:
            if raw[i:i + len(t)].upper() == t:
                hit = t
                break
        if hit:
            out += _FMT_MAP[hit]
            i += len(hit)
        else:
            known = False
            break
    return out if known else None


def _unquote(s):
    return s.strip().strip("'")


def translate(sql, ignored=None, overrides=None):
    """ignored: an ignore_lists.IgnoreList (or None). Calls to ignored
    Oracle packages are not flagged — they are out of migration scope.
    overrides: approved learned SQL overrides, [{"from", "to", "id"}] —
    an exact statement match (whitespace-normalized) wins over the
    mechanical rules, and is reported as applied rule "pattern:<id>"."""
    original = sql
    applied, flags = [], []
    if overrides:
        nsql = ' '.join(sql.split())
        for ov in overrides:
            if ' '.join(ov['from'].split()) == nsql:
                return {'original': original, 'translated': ov['to'],
                        'applied': [f"pattern:{ov.get('id', 'sql-override')}"],
                        'flags': [], 'confidence': 'high'}
    # --- keyword-level rules, applied outside string literals/comments ---
    segments = re.split(r"('(?:''|[^'])*'|/\*.*?\*/|--[^\n]*)", sql,
                        flags=re.DOTALL)
    for i in range(0, len(segments), 2):
        seg = segments[i]
        new = re.sub(r'\bSYSDATE\b', 'current_timestamp()', seg, flags=re.I)
        new = re.sub(r'\bSYSTIMESTAMP\b', 'current_timestamp()', new, flags=re.I)
        if new != seg:
            applied.append('SYSDATE->current_timestamp()')
            seg = new
        new = re.sub(r'\s+FROM\s+DUAL\b', '', seg, flags=re.I)
        if new != seg:
            applied.append('FROM DUAL removed')
            seg = new
        new = re.sub(r'/\*\+.*?\*/', '', seg, flags=re.DOTALL)
        if new != seg:
            applied.append('optimizer hint removed')
            seg = new
        for pat, msg in _FLAG_PATTERNS:
            matches = list(pat.finditer(seg))
            if not matches:
                continue
            if ignored and pat is _DBMS_UTL_PAT:
                # ignored packages (e.g. DBMS_OUTPUT) are out of scope:
                # only flag the ones that are NOT ignored
                matches = [m for m in matches
                           if not ignored.ignore_object(m.group(0).upper())]
                if not matches:
                    continue
            flags.append(msg)
        segments[i] = seg
    sql = ''.join(segments)

    # --- function-level rewrites (name + '(' is effectively never inside a
    # string literal in real SQL, so these run on the whole text) ---
    def nvl(args):
        return f'COALESCE({args[0]}, {args[1]})' if len(args) == 2 else None

    def nvl2(args):
        if len(args) == 3:
            return (f'CASE WHEN {args[0]} IS NOT NULL THEN {args[1]} '
                    f'ELSE {args[2]} END')
        return None

    def to_date(args):
        if len(args) == 2:
            m = _map_fmt(args[1])
            if m is None:
                flags.append(f"TO_DATE format mask {args[1]}: unmapped tokens")
                return None
            return f"to_date({args[0]}, '{m}')"
        if len(args) == 1:
            return f'to_date({args[0]})'
        return None

    def to_char(args):
        if len(args) == 2:
            m = _map_fmt(args[1])
            if m is None:
                flags.append(f"TO_CHAR format mask {args[1]}: unmapped tokens")
                return None
            return f"date_format({args[0]}, '{m}')"
        if len(args) == 1:
            return f'CAST({args[0]} AS STRING)'
        return None

    def trunc(args):
        if len(args) == 1:
            return f'to_date({args[0]})'
        if len(args) == 2:
            unit = _unquote(args[1]).upper()
            if unit in ('DD', 'D'):
                return f'to_date({args[0]})'
            if unit in ('MM', 'MON', 'MONTH'):
                return f"date_trunc('month', {args[0]})"
            if unit in ('YYYY', 'YY', 'YEAR'):
                return f"date_trunc('year', {args[0]})"
            if unit in ('HH', 'HH24'):
                return f"date_trunc('hour', {args[0]})"
            flags.append(f'TRUNC unit {args[1]}: no direct mapping')
            return None
        return None

    def decode(args):
        if len(args) < 3:
            return None
        expr, rest = args[0], args[1:]
        default = None
        if len(rest) % 2 == 1:
            default = rest[-1]
            rest = rest[:-1]
        parts = [f'CASE {expr}']
        for j in range(0, len(rest), 2):
            parts.append(f'WHEN {rest[j]} THEN {rest[j + 1]}')
        if default is not None:
            parts.append(f'ELSE {default}')
        parts.append('END')
        return ' '.join(parts)

    sql = _replace_calls(sql, 'NVL2', nvl2, applied, flags, 'NVL2->CASE')
    sql = _replace_calls(sql, 'NVL', nvl, applied, flags, 'NVL->COALESCE')
    sql = _replace_calls(sql, 'TO_DATE', to_date, applied, flags, 'TO_DATE->to_date')
    sql = _replace_calls(sql, 'TO_CHAR', to_char, applied, flags, 'TO_CHAR->date_format')
    sql = _replace_calls(sql, 'TRUNC', trunc, applied, flags, 'TRUNC->date_trunc/to_date')
    sql = _replace_calls(sql, 'DECODE', decode, applied, flags, 'DECODE->CASE')

    flags = sorted(set(flags))
    applied = sorted(set(applied))
    if flags:
        confidence = 'needs-review'
    elif 'DECODE->CASE' in applied or any('format' in a for a in applied):
        confidence = 'medium'
    else:
        confidence = 'high'
    return {'original': original, 'translated': sql,
            'applied': applied, 'flags': flags, 'confidence': confidence}


def translate_statement(sql, ignored=None, overrides=None):
    """translate() with the original preserved for the caller."""
    return translate(sql, ignored, overrides)
