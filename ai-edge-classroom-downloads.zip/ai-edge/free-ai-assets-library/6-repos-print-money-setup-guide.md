# 6 free GitHub repos to print $$ with Claude
### Drag-and-drop setup guide + prompt pack

Everything from the video, in the order it appears. All six are free and open source.

**Fastest way to use this file:** make an empty folder, open Claude Code or Codex inside it, drag this file into the terminal (or paste the whole thing), and type:

> Read this file and run the SETUP section. Install and connect everything in order, verify each one, stop and ask me when you need a key or a decision, and give me the table at the end.

The agent does the rest. Every command in here is copied from each repo's own README as of 20 September 2026. If a README has changed since, the README wins.

---

## What you need first

| Tool | Why | Get it |
|---|---|---|
| **Claude Code** or **Codex** | Runs everything below | https://docs.claude.com/en/docs/claude-code (needs Claude Pro or Max, or an API key) · https://github.com/openai/codex |
| **Docker Desktop** (running) | Twenty, Listmonk, Postiz and the scraper all run in Docker | https://docker.com |
| **Node.js 18+** | Firecrawl MCP, the `skills` CLI, the Postiz CLI | https://nodejs.org |
| **uv** (Python) | Pipecat | https://docs.astral.sh/uv — the agent will install it for you |
| **ngrok** | Pipecat's phone webhook, Postiz social logins | https://ngrok.com — free tier |
| **Git** | Twenty skills | already on a Mac; https://git-scm.com on Windows |

## Keys and accounts — have these ready or the run will stall

| For | What | Where | Cost |
|---|---|---|---|
| Firecrawl | API key | https://www.firecrawl.dev/app/api-keys | free tier |
| Pipecat (the brain) | Anthropic API key (or OpenAI if you're on Codex) | https://console.anthropic.com | cents for a test |
| Pipecat (the phone) | Twilio account + one phone number | https://twilio.com | ~$1/mo per number. A trial account only accepts calls from numbers you've verified and plays a trial message first — upgrade ($20) before you show it to a client |
| Pipecat (the ears) | Deepgram API key | https://deepgram.com | free credit |
| Pipecat (the voice) | Cartesia or ElevenLabs API key | https://cartesia.ai · https://elevenlabs.io | free tier |
| Listmonk | SMTP credentials | Postmark or Amazon SES | free tier / cents |
| Postiz | A developer app for each social you connect (start with X and LinkedIn) | each platform's developer portal | free, ~20 min each — the fiddly part |
| Twenty, google-maps-scraper | nothing | — | — |

Never paste a key into the chat. The agent will tell you the variable name and the `.env` file; you fill it in, then say "done".

---

## SETUP — the drag-and-drop block

```
I'm setting up six open-source tools from a YouTube video. Install and connect them all in this session, in order, and verify each one before moving on.

Rules:
- Work inside this folder. One subfolder per tool.
- Before installing anything, read that repo's README (and linked docs) on GitHub and follow it exactly. If the README disagrees with this file, the README wins.
- Never ask me to paste a secret into this chat. Tell me the exact variable name and which .env file to put it in, then wait until I say "done".
- Stop and ask me on any real decision. If a tool fails twice, log the error in SETUP-LOG.md and move to the next one — don't stop the whole run.
- Don't run demos. Verification only. I'll try each tool afterwards with the prompts in this file.
- Keep SETUP-LOG.md updated as you go: what's installed, which port it's on, its local URL, where its credentials live, and anything I still have to do by hand.
- Watch for port collisions. Twenty and Postiz may both want 3000. Assign ports, record them.
- Where a tool ships an Agent Skill or MCP server, install that — it's how I'll drive the tool from you.
- If you are Codex rather than Claude Code: register the Firecrawl MCP server through your own MCP configuration instead of the `claude mcp add` command, and skip any Claude-only plugin commands. Everything else is identical.

Prerequisites first: check Docker Desktop is running, and that Node 18+, uv, ngrok and git are installed. Install uv if it's missing (https://docs.astral.sh/uv). Tell me what you found before continuing.

1. google-maps-scraper — https://github.com/gosom/google-maps-scraper
   Install its Agent Skill: `npx skills add gosom/google-maps-scraper`. Pull the image: `docker pull gosom/google-maps-scraper`. Create queries.txt containing one line: `dental clinic in [my city]` — ask me for the city. Run the Quick Start docker command from the README against it with `-depth 1 -exit-on-inactivity 3m`, writing to gmaps-output/results.csv. No proxy — decline the proxy sponsor prompt. Verify: results.csv exists and has more than 20 rows with name, phone, website, rating and review columns.

2. Firecrawl — https://github.com/firecrawl/firecrawl-mcp-server
   Ask me to put my key in firecrawl/.env as FIRECRAWL_API_KEY and wait. Then register the MCP server. Claude Code: `claude mcp add firecrawl -e FIRECRAWL_API_KEY=$FIRECRAWL_API_KEY -- npx -y firecrawl-mcp` (source the .env first). Codex: add the same command — `npx -y firecrawl-mcp` with the FIRECRAWL_API_KEY environment variable — to your MCP configuration per the Codex docs. Verify: the server shows as connected, then scrape https://example.com through it and confirm markdown comes back.

3. Twenty — https://github.com/twentyhq/twenty
   Self-host with Docker Compose following https://docs.twenty.com/developers/self-host/capabilities/docker-compose exactly. Put it on a port that won't collide with Postiz and record it. Verify the UI loads. Stop and ask me to create the workspace and admin account in the browser. Then install the agent skills: `npx skills add https://github.com/twentyhq/twenty/tree/agent-skills --list` (if that branch doesn't resolve yet, follow the local build instructions in packages/twenty-agent-skills). Create an API key in Twenty's settings following the docs, ask me to save it to twenty/.env as TWENTY_API_KEY, and write twenty.py: a helper that can create a person, create a company, create an opportunity, and list opportunities by stage through the API. Verify: create and delete one test person with it.

4. Listmonk — https://github.com/knadh/listmonk
   `curl -LO https://github.com/knadh/listmonk/raw/master/docker-compose.yml` then `docker compose up -d` in listmonk/. Verify http://localhost:9000 loads. Stop and ask me to set the admin login. Then ask me to enter my SMTP settings under Settings > SMTP in the browser and say "done". Create an API user following the docs and ask me to save its token to listmonk/.env as LISTMONK_API_USER and LISTMONK_API_TOKEN. Write listmonk.py: create list, import subscribers from CSV, create campaign, send test email, start campaign. Verify: create a list called "Setup test", send a test email to the address I give you, then delete the list.

5. Postiz — https://github.com/gitroomhq/postiz-app and https://github.com/gitroomhq/postiz-agent
   Self-host with Docker Compose following https://docs.postiz.com exactly. Social logins need a public HTTPS URL, so run it behind an ngrok tunnel and set MAIN_URL / FRONTEND_URL / NEXT_PUBLIC_BACKEND_URL to the ngrok address per the docs. Record the port. Verify the UI loads. Stop and ask me to create the admin account. Install the Postiz skill: `npx skills add gitroomhq/postiz-agent` (Claude Code users can alternatively run the two plugin commands in the postiz-agent README). Install the CLI: `npm install -g postiz`. Ask me to generate a key in Postiz > Settings > Developers > Public API and save it to postiz/.env as POSTIZ_API_KEY, and point the CLI at my self-hosted instance per the README. Connecting X and LinkedIn is mine to do by hand in the UI — remind me, don't attempt it. Verify: the CLI lists integrations without error (an empty list is fine until I connect a channel).

6. Pipecat — https://github.com/pipecat-ai/pipecat
   `uv tool install "pipecat-ai[cli]"`, then in pipecat-receptionist/ run `pipecat init` and follow the quickstart at https://docs.pipecat.ai/getting-started/quickstart. Build a phone bot using the Twilio transport/serializer from the docs and the Twilio example in https://github.com/pipecat-ai/pipecat-examples. LLM: Anthropic (Claude) — OpenAI if I say so. STT: Deepgram. TTS: Cartesia (ElevenLabs if I say so). Ask me to fill pipecat-receptionist/.env with the LLM key, DEEPGRAM_API_KEY, CARTESIA_API_KEY, TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN, and wait. Write receptionist-prompt.md — an after-hours receptionist for a plumbing business called Bayside Plumbing: greet, get the caller's name, number, what's wrong and how urgent, offer a callback window, never quote prices, keep every reply under two sentences. Load it as the system prompt. Start the bot and an ngrok tunnel, then stop and give me the exact webhook URL to paste into my Twilio number's voice settings. Verify: the bot process is running and the tunnel is live. I'll make the test call.

Sample data (create these with fake data so I can try everything without touching real customer data):
- twenty/contacts.csv — 25 fake B2B contacts: name, company, email, phone, status (Lead / Quoted / Won / Lost), deal value, last_contact date
- listmonk/old-customers.csv — 200 fake customers: email (all @example.com), name, last_job_date
- postiz/transcript.md — a 1,500-word fake podcast transcript about running a trades business
- gmaps-output/queries.txt — already created in step 1

Finish with a table: Tool | Installed | Connected (skill / MCP / CLI / script) | Local URL + port | What I still need to do by hand. Then list every .env file you created and which variables are still empty.
```

---

## 1. Firecrawl — the reader

**What it does:** give it any website and it hands the agent clean text. Scrapes a page, crawls a whole site, searches the web, extracts structured data across many pages, and can watch a page for changes. 182K+ stars.

**How it makes money:** it's how you know what to say before you pitch anyone. Read a prospect's site, find the gaps, email them the gaps. On its own it sells as a weekly competitor digest — five rivals' pricing pages every Monday — at $200–300/mo to SaaS, agencies and dealers with named competitors. Smallest ticket in the video, opens the most doors.

**Install:** the MCP server at https://github.com/firecrawl/firecrawl-mcp-server — `env FIRECRAWL_API_KEY=fc-YOUR_KEY npx -y firecrawl-mcp`. Free key at https://www.firecrawl.dev/app/api-keys. Firecrawl is also in the Claude connector directory, so it works inside claude.ai without Claude Code.

**Prompts**

The pre-pitch:
```
Use Firecrawl to read [prospect website]. Tell me the three biggest gaps a customer would hit — no online booking, no pricing, no reviews page, a slow contact path, whatever you actually find. Then write it as a 4-line cold email I could send today. No flattery, lead with the worst gap.
```

The digest:
```
Scrape these five competitor pricing pages: [url 1] [url 2] [url 3] [url 4] [url 5]. Write me the Monday digest: what changed, why it matters, one line each. If nothing changed, say so in one line.
```

Lead enrichment:
```
For each domain in domains.txt, use Firecrawl to find: what they sell, their pricing if it's public, team size from their about page, and any open job postings. Give me a table, then flag the ones hiring for sales or admin roles — those are the ones to contact first.
```

## 2. Postiz — the poster

**What it does:** open-source Buffer. Schedules posts to X, LinkedIn, Instagram, TikTok, YouTube, Threads, Reddit, Bluesky and more. Self-hosted, so no per-channel fee.

**How it makes money:** "we run your socials." The agent writes, Postiz posts. Twenty posts a month at $500 setup + $400/mo, to any local business or expert whose last post was months ago. Eight clients is $3,200/mo recurring at roughly two hours per client. The pitch: "You posted three times last month. Your competitor posted 22." Screenshot both.

**Install:** self-host via Docker Compose at https://docs.postiz.com (needs a public HTTPS URL for social logins — ngrok is fine). Connect the agent with the skill: `npx skills add gitroomhq/postiz-agent`, plus the CLI: `npm install -g postiz`, authenticated with `postiz auth:login` or a POSTIZ_API_KEY from Settings > Developers > Public API.

**Prompts**

Two weeks from one episode:
```
Read transcript.md. Write 10 posts from it: 5 for X under 240 characters, 5 for LinkedIn under 120 words. Each one is a single idea from the episode, no hashtags, no emojis. Schedule them in Postiz across the next two weeks, one per weekday at 9am [my timezone], as drafts — don't publish anything.
```

The audit that gets the client:
```
Here are the last 30 days of posts from [client] and [their competitor] (pasted below). Count posts per platform for each, note the gap, and write me a 3-line message to [client] that states the numbers and offers to close the gap. No hype.
```

## 3. Twenty — the CRM the agent talks to

**What it does:** open-source CRM — people, companies, opportunities, pipeline, workflows. Ships official skills for Claude Code and Codex, so the agent can read and write to it directly.

**How it makes money:** spreadsheet-to-CRM migration with the agent on top. Every contractor runs sales off a sheet; nobody wants to learn a CRM; everyone wants to ask "which deals went quiet?" $1,500 setup + $150/mo hosting, against $40–60 a seat for the paid CRMs. Once their data's in, they don't leave. The pitch: "Where do your deals live today?"

**Install:** Docker Compose per https://docs.twenty.com/developers/self-host/capabilities/docker-compose. Skills: `npx skills add https://github.com/twentyhq/twenty/tree/agent-skills --list`. API key from Twenty's settings.

**Prompts**

The whole migration in one prompt (works with no CSV — the data's inside it, swap in your own):
```
I'm setting up a CRM for a small services business in Twenty. Do all of this in one go, don't ask me questions, use sensible defaults, and report at the end.

Here are the contacts. One per line: name, company, email, phone, status, deal value in USD, last contact date.

Sarah Mitchell, Coastline Pools, sarah@coastlinepools.ae, +971 50 111 2233, Quoted, 8400, 2026-08-28
Omar Haddad, Haddad Electrical, omar@haddadelectrical.com, +971 55 222 3344, Lead, 3200, 2026-09-16
Priya Nair, Marina Dental Clinic, priya@marinadental.ae, +971 52 333 4455, Quoted, 12000, 2026-08-19
James Whitfield, Whitfield Landscaping, james@whitfieldlandscaping.com, +971 56 444 5566, Won, 6500, 2026-09-10
Fatima Al Amri, Al Amri Interiors, fatima@alamriinteriors.ae, +971 50 555 6677, Quoted, 15500, 2026-09-02
Daniel Cho, JLT Fitness Studio, daniel@jltfitness.com, +971 54 666 7788, Lead, 2800, 2026-08-25
Lena Fischer, Fischer Property Management, lena@fischerpm.ae, +971 55 777 8899, Lost, 9000, 2026-08-30
Ravi Menon, Menon Auto Repair, ravi@menonauto.com, +971 50 888 9900, Quoted, 4750, 2026-09-18
Hannah Brooks, Brooks Legal, hannah@brookslegal.ae, +971 52 999 0011, Lead, 7200, 2026-09-04
Youssef Karam, Karam Catering, youssef@karamcatering.com, +971 56 121 2323, Quoted, 5600, 2026-08-22
Emily Turner, Turner Physio, emily@turnerphysio.ae, +971 55 343 4545, Won, 3900, 2026-09-14
Khalid Rashid, Rashid Logistics, khalid@rashidlogistics.com, +971 50 565 6767, Quoted, 21000, 2026-09-01

1. Create each company in Twenty (no duplicates), then each person linked to their company with email and phone.
2. Create one opportunity per line: name it "<Company> - job", set the amount, link the company and the person, and record the last contact date.
3. Set the pipeline stages to Lead, Quoted, Won, Lost. If Twenty won't let you rename the stage field, map each status to the closest existing stage and show me the mapping.
4. Today is [today's date]. List every open deal (Lead or Quoted) with no contact in 14 or more days, ranked by value, highest first.
5. For each stale deal, write a one-line follow-up I can send today: plain, no hype, ends with one question.
6. Finish with a summary: deals per stage, total open pipeline value, and the three people I should call first and why.
```

Talk to it afterwards:
```
Which deals over $5,000 are sitting in Quoted with no activity since last week? Rank them by value and tell me who I should call first and why.
```

## 4. Listmonk — the reactivation engine

**What it does:** self-hosted newsletter and mailing-list manager. One binary plus Postgres. No per-contact fee — the paid tools charge you for every contact sitting on the list; this charges nothing.

**How it makes money:** database reactivation. Every business has a list they haven't emailed in a year — past customers who already paid them once. Say 2,000 contacts, 1% book: 20 jobs, zero ad spend, revenue inside a week they can count. $1,000 per campaign or $300/mo to keep it running. Nervous client? Do the first campaign for a cut of the bookings. The pitch: "When did you last email your customers?"

**Install:** `curl -LO https://github.com/knadh/listmonk/raw/master/docker-compose.yml` then `docker compose up -d`, open http://localhost:9000, add your SMTP under Settings, create an API user for the agent.

**Prompts**

The campaign:
```
Create a list called "Reactivation - [client]" and import old-customers.csv. Write a 3-email reactivation sequence: subject lines and plain-text bodies under 80 words each, one clear booking link, no hashtags, no exclamation marks. Load them as campaigns. Send email 1 to my test address first and wait for me to approve before anything else goes out.
```

The report the client actually reads:
```
Pull the stats for the "Reactivation - [client]" campaigns: sent, opened, clicked, unsubscribed. Write a 5-line summary for the business owner in plain English, then tell me what to change in email 2 based on what email 1 did.
```

## 5. Pipecat — the receptionist

**What it does:** open-source framework for real-time voice agents. The LLM is the brain, Deepgram hears, Cartesia speaks, Twilio is the phone line. The `pipecat init` command is built so Claude Code or Codex scaffolds the bot for you.

**How it makes money:** missed calls. Say a plumber misses ten calls a week and one in five was a $400 job — that's $800 a week walking out the door. An after-hours AI receptionist at $1,500 setup + $500/mo is the easiest yes in the video. Hardest build too, which is why it's priced that way. Start after-hours only and grow from there. The pitch: "How many calls did you miss last week?" They don't know.

**Install:** `uv tool install "pipecat-ai[cli]"` then `pipecat init`, following https://docs.pipecat.ai/getting-started/quickstart. Use the Twilio transport from the docs and the Twilio example in https://github.com/pipecat-ai/pipecat-examples. Expose it with ngrok and paste the webhook URL into your Twilio number's voice settings.

**Prompts**

The build:
```
Turn this into an after-hours receptionist for [business name] using receptionist-prompt.md as the system prompt: greet, get the caller's name, number, what's wrong and how urgent, offer a callback window, never quote prices, replies under two sentences. After every call, write a summary to calls.md with the caller's details and urgency. Start it and give me the webhook URL for Twilio.
```

The owner's morning:
```
Read calls.md. Give me every call from last night: name, number, problem, urgency, in a table sorted by urgency. Then draft the text message I should send each caller before 8am.
```

## 6. google-maps-scraper — the leads

**What it does:** every business in a category and a city from Google Maps — name, phone, website, rating, review count, coordinates — into a CSV. Free, runs in Docker, ships an Agent Skill so you describe the leads and the agent plans and runs the scrape.

**How it makes money:** it's how you find the buyers for the other five. The scraper finds them, Firecrawl reads them, the agent writes the pitch — an outreach machine that costs nothing. Standalone, agencies, recruiters and realtors buy lists at $200–500 each. A filter like "under 4.5 stars, 50+ reviews" means a real business with unhappy customers, a list to reactivate and calls being missed — repos four and five in one query.

**Install:** `npx skills add gosom/google-maps-scraper` and `docker pull gosom/google-maps-scraper`. The README's Quick Start has the docker command.

**Prompts**

Your first list (swap the category and areas):
```
Use the google-maps-scraper skill. Don't ask me questions — use these settings and report at the end.

Goal: find dental clinics in [city] that are likely to have unhappy customers and a neglected client list, so I can pitch them a reactivation campaign.

Run these searches, depth 1, no proxy, exit on 3 minutes of inactivity:
dental clinic in [area 1]
dental clinic in [area 2]
dental clinic in [area 3]
dental clinic in [area 4]

Do a quick validation run on the first query before launching the full scrape. Save everything to gmaps-output/[city]-dentists.csv and dedupe by phone number.

Then filter to clinics with a rating under 4.5, more than 50 reviews and a phone number. Flag any with no website. Give me a table: name, area, phone, website, rating, reviews, no-website flag — sorted by review count, highest first.

For the top five, write a 3-line message I can send on WhatsApp or email: plain, no hype, mention their review count, offer to email their past patients a reactivation campaign, end with one question.

Finish with: total businesses found, how many passed the filter, and how many have no website.
```

Stack it with Firecrawl:
```
Take the top 10 from gmaps-output/[city]-dentists.csv that have a website. Use Firecrawl to read each site and find the biggest gap a patient would hit. Rewrite each outreach message to lead with that gap. Give me the 10 messages with the phone number next to each.
```

---

## No Claude Code or Codex?

Firecrawl works inside claude.ai through the connector directory. The other five need a coding agent to install and drive them — Claude Code or Codex are both fine, and everything in the SETUP block works in either.

## Safety notes, once

- Never paste keys, passwords or tokens into a chat. Everything here takes credentials through a `.env` file or a login screen.
- Scraper: keep volumes modest, no proxy needed to start, and check the terms wherever you sell the lists.
- Listmonk: only email people who were actually customers, unsubscribe link in every send, never a bought list. Anti-spam law in Australia, the UAE, the US and the EU all apply to cold email.
- Postiz: schedule as drafts until you've watched it post correctly once.
- Pipecat: a Twilio trial only takes calls from verified numbers and plays a trial message first — upgrade before a client hears it.
- Every agent call bills your plan or key. Keep the first runs short.
