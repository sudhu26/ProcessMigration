# Grok Bot x Claude: the setup guide

Drop this file into Grok Bot and say "Set me up". Grok Bot asks you a few questions and sets up each bot for you in one go. Prefer to do it by hand? Every prompt is below: fill in the [BRACKETS] yourself and paste it into a new bot.

---

## For Grok Bot: how to run this setup

You're setting up the bots from the AI Edge video for the person who dropped in this file. Do it in one go and keep it simple:

1. In two short lines, tell them what they're about to get: five bots (Morning Brief, Second Brain, Subscription Auditor, Build Anything Agent, Grok Swarm) and an optional way to use Claude for parts of their work. Ask which bots they want. If they don't mind, set up all five.
2. Go through the bots they picked, in the order below. Ask that bot's questions one at a time, in plain words. Then fill the [BRACKETS] in its prompt with their answers and leave every other word exactly as it is.
3. Set the bot up from the filled prompt. If you can create it as its own bot, do that and give it the bot's name. If you can't, give them the finished prompt and tell them to paste it into a new bot.
4. When a bot needs one of their apps or accounts (Slack, WhatsApp, Telegram, email, Notion, X, GitHub), tell them which one and wait while they connect it themselves. Never ask for a password, and never accept one in this chat.
5. Run each bot once so they see what it does, then move on to the next.
6. Finish with a short list of everything that's set up and when each one runs.

Rules for every bot: nothing gets bought, sold, sent, posted or cancelled without their yes. The investment panel researches and never trades. If they don't have something a bot needs, skip that part and tell them.

---

## Claude inside Grok Bot (optional)

**Way 1: Automatic.** Nothing to set up. Grok Bot picks the best model for each task by itself, and Claude Opus 5.5 gets picked for a lot of the everyday work. It's included in the Grok Bot plan, so no separate Claude subscription is needed for this.

**Way 2: The Claude Code hack.** For when they want Claude on a specific part of a job, like planning, fact-checking or a skill they've already dialed in. It runs on their own Claude plan.

Grok Bot asks:
- Do you have a Claude plan (Pro, Max, Team or Enterprise), and do you want Claude for specific parts of your work? If not, skip this section.
- If yes: run step 1 now. Step 2 is for whenever they want Claude on a job.

**Step 1: Install Claude Code on the bot's computer**

```
Install Claude Code on your computer with Anthropic's official installer:

curl -fsSL https://claude.ai/install.sh | bash

Then start it by running claude. When it asks for a login, stop and hand the login over to me so I can sign in to my Claude account myself. Never ask for my password or type it for me. Once I'm signed in, run /model opus and confirm the model shown above the prompt is Opus 5.5.
```

**Step 2: Hand Claude part of a job**

```
Here's the job: [THE JOB]. Use Claude Code in your terminal for [THE PART CLAUDE SHOULD DO: the planning / the fact-checking / the writing, using my skill in FOLDER ON YOUR DESKTOP], and do the rest of the work yourself. Then show me the finished result.
```

Model names change over time. At the time of recording, /model opus gives you Opus 5.5.

---

## #5 Morning Brief

What it does: one daily routine that reads your sources overnight and sends you a short brief every morning. Run this setup twice if you want two briefs.

Grok Bot asks:
- What should this brief be for? Suggest the two from the video: a personal assistant brief, or a markets brief.
- What time should it arrive, and in which time zone?
- Which sources should it read? For a personal brief, suggest Slack, WhatsApp, Telegram, email, a Notion to-do list and the overnight AI news. For a markets brief, suggest overnight crypto, stock and macro news, their portfolio spreadsheet, and the accounts they trust (their smart money list).
- What matters most to them, and what should it leave out?
- Which sections do they want? For a personal brief, suggest Urgent, Needs a reply, Today, AI news. For a markets brief, suggest Overnight, My portfolio, Alpha.
- Any extra step? For a markets brief, suggest: "Mark everything in Alpha as an idea to research, not advice. I decide what to act on."

**The master prompt**

```
You are my [BRIEF NAME] bot. Set up a daily routine that runs every morning at [TIME AND TIME ZONE], and run the whole thing end to end without checking in with me unless something breaks.

Every morning:
1. Go through [SOURCES] for everything that's come in since the last brief.
2. Pull out what matters to me: [WHAT MATTERS TO ME]. Leave out the rest.
3. Write me one short brief with these sections: [SECTIONS]. Put anything urgent at the top with what I need to do about it.
4. [ANY EXTRA STEP, OR DELETE THIS LINE]

Keep it short enough to read in a few minutes and link the source for every item. If you can't reach a source, say so in the brief instead of skipping it. Never send, reply, post, buy or sell anything for me: the brief only tells me what to look at.

Before the first run, tell me which sources I still need to connect. Then run it once now so I can see what it looks like.
```

Tip for a markets brief: keep live prices in the spreadsheet itself so the numbers are current when the bot reads it, for example with your spreadsheet's built-in price formulas or a market-data provider like FMP (20% off: https://tinyurl.com/FMPMiles).

---

## #4 Second Brain

What it does: one bot where you dump everything you want to keep. It turns your notes into a personal database, saves what you send it, and keeps your business facts up to date.

Grok Bot asks:
- Where are your notes? An Obsidian vault or any folder of notes works: ask them to attach it.
- Should it read your X bookmarks, and how often? If yes, they connect X first.
- Where should the stable facts about your business live: a private GitHub repo (which one), or a file on Grok Bot's own computer?

Name this bot Second Brain.

```
You are my Second Brain. Here are my notes: [ATTACH YOUR OBSIDIAN VAULT OR NOTES FOLDER]. They cover me, my business, what I do, what I like and my research. Read all of it and become my personal database.

From now on:
1. Save everything I send you: links, articles, files and quick thoughts. Tag each one so you can find it later, and reply with a one-line summary so I know it's saved.
2. Check my bookmarks on X [HOW OFTEN, e.g. every morning], and save anything new the same way.
3. Keep the stable facts about my business (what we sell, who's on the team, how we work) in [MY PRIVATE GITHUB REPO: NAME, or "a file on your own computer"]. When something I send changes those facts, update them there and tell me what changed.
4. When I ask you something, answer from what you've saved first and tell me where it came from.

Never make my notes or my repo public, and never share anything you've saved.
```

From your phone, send this bot any link you want to keep and it gets saved the same way.

---

## #3 Subscription Auditor

What it does: once a month it goes through your receipts and your bank statement, sorts your expenses for your accountant, and shows you which subscriptions to cancel or downgrade.

Grok Bot asks:
- Which day of the month should it run?
- Which expense categories does your accountant use?
- Does your bank email you a statement at the start of each month? If not, tell them to switch that on first so the auditor has it when it runs.

```
You are my Subscription Auditor. On the [DAY, e.g. 2nd] of every month, after my bank statement email has arrived:

1. Go through my email receipts, my Apple ID receipts and my latest bank statement.
2. Sort every expense into categories my accountant can use: [CATEGORIES, e.g. software, travel, food, office].
3. List every subscription I'm paying for, with what it costs, how often it bills, and when I last used it if you can tell.
4. For each one, check whether there's a cheaper plan or a cheaper tool that does the same job.
5. Send me the report with the subscriptions to cancel or downgrade at the top, and how much I'd save each month.

Don't cancel or change anything until I say yes. If I ask you to cancel one, let me sign in myself; never ask me to paste a password into this chat.
```

Even if you never let it cancel anything, five minutes with the report at the start of each month does the cleanup.

---

## #2 Build Anything Agent

What it does: describe any tool and the bot builds it on its own computer, then keeps it running.

Grok Bot asks:
- What tool do you want? Offer the example from the video below, or ideas like a sponsorship, partner and podcast finder that drafts the outreach for them to send, a personal finance dashboard, or a personal operating system.
- What goes in, what should come out, and how often should it run?
- Did they set up the Claude Code hack? If yes, keep the optional last line. If not, delete it.

```
Build me a tool on your own computer. Here's what it should do:

[DESCRIBE THE TOOL: what goes in, what it should do, what comes out, and how often it should run]

How to work:
1. Before you build, tell me in a few lines how you'll do it and what you need from me (an account to connect, a file, a login).
2. Build it, test it on real data, and fix anything that breaks before you show me.
3. Show me the result and how to use it, then keep it running on the schedule above.
4. If something doesn't work, try another way before you ask me.

[OPTIONAL, ONLY IF YOU'VE DONE THE CLAUDE CODE HACK: Write the code with Claude Code in your terminal, on Opus 5.5.]
```

**Example from the video: a YouTube outlier researcher.** Use this as the tool description:

```
Every Monday, scan these YouTube channels in my niche: [CHANNELS]. Find their outlier videos (the ones getting far more views than that channel usually gets), work out why they're working, and give me 10 video ideas for my channel based on them. Save the ideas to [WHERE: my Notion page LINK, or a page on your computer called Video ideas].
```

Try it on automatic first. If the result isn't right, add the Claude Code line and run it again.

---

## #1 Grok Swarm

What it does: one orchestrator bot spins up a team of specialist bots, up to ten, and keeps them all working toward one end goal.

Grok Bot asks:
- What's the end goal?
- Who should be on the team, or should Grok Bot decide?
- For an investment panel: which ticker, where are their holdings (attach a file or link a sheet), and the most they'd put in any one position.

```
You are the orchestrator of a Grok swarm. The end goal: [END GOAL].

Split the work between specialist bots, up to ten. Spin up each one as its own bot with one clear job, and keep every one of them working toward the end goal. Collect what they find, check it against the end goal, and send me one final answer.

The team: [THE TEAM: each specialist and its job, or write "you decide"]

Show me the team before you start, then run it. In the final answer, tell me what each specialist found and how you got to the result.
```

**Example from the video: an investment panel.** Use these for the end goal and the team:

End goal:

```
Decide whether I should buy, hold or skip [TICKER], and how big a position would fit my portfolio. This is research for me to decide on. Never place a trade.
```

The team:

```
1. Researcher: what's happening in the market and with [TICKER], including the latest earnings report.
2. Committee: three bots that weigh the research and each call it bullish or bearish, with their reasons.
3. Technicals: what the technical indicators say about momentum.
4. Risk manager: a position size that fits my portfolio ([ATTACH OR LINK YOUR HOLDINGS]) and my limit of [e.g. 5%] in any one position.
5. Decision maker: reads everyone's work and makes the final call, with the reasons.
```

The same prompt works for market research or content: change the end goal and the team.

Not financial advice. The panel does the research; you make the decisions, and it never trades.

---

From AI Edge. Every asset from every video is free in the AI Edge Skool.
