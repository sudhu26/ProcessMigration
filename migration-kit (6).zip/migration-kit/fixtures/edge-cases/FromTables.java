package com.risk.edge;

/** _from_tables regression (R4-G4): bare JOIN and comma-joined tables.
 *  No main() method, so no synthetic unit is created. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (FromTables.java record): tables_read ['T1', 'T2'],
 *  table_columns {'T1': {'read': ['D']}, 'T2': {'read': ['C']}},
 *  columns_unattributed ['A', 'B'] — the bare columns of the comma join
 *  and of the bare JOIN are multi-table, so they are unattributed, not
 *  attributed to T1. */
public class FromTables {

    public void run(java.sql.Statement st) throws Exception {
        // comma join: bare columns are multi-table -> unattributed
        String commaSql = "SELECT a, b FROM t1, t2";
        st.executeQuery(commaSql);

        // comma join with prefixes: attributed to the right tables
        String prefixedSql = "SELECT t2.c, t1.d FROM t1, t2";
        st.executeQuery(prefixedSql);

        // bare JOIN (no AS aliases): both tables registered, so the
        // bare column is multi-table -> unattributed, not T1's
        String joinSql = "SELECT a FROM t1 JOIN t2 ON t1.id = t2.id";
        st.executeQuery(joinSql);
    }
}
