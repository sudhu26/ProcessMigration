# The 7 GitHub Repos That Make Claude 10x More Powerful
### Drag-and-drop setup guide + prompt pack

Everything from the video, in the order it appears. All seven are free.

**Fastest way to use this file:** open Claude Code, drag this file into the terminal (or paste the whole thing), and type:

> Read this file and run the SETUP section. Install everything in order, ask me when you need something, and give me the table at the end.

Claude Code does the rest. Every command in here is copied from each repo's own README as of 17 September 2026. If a README has changed since, the README wins.

---

## What you need first

| Tool | Why | Get it |
|---|---|---|
| **Claude Code** | Runs everything below | https://docs.claude.com/en/docs/claude-code — needs a Claude Pro or Max plan, or an API key |
| **Node.js 18+** | Playwright MCP, archify, last30days | https://nodejs.org |
| **Git** | gstack, agency-agents | https://git-scm.com/downloads |
| **Bun** | gstack only | https://bun.sh — one command, Claude Code will install it for you in setup |

No API keys are required for any of the seven to run. last30days can take optional keys for X and YouTube later; skip them and it runs on Reddit, arXiv, Techmeme and the web.

---

## SETUP — the drag-and-drop block

```
I'm installing seven tools from a YouTube video. Install them all in this session, in order, and verify each one before moving on. Read each repo's README on GitHub first and follow it exactly. If anything needs a decision from me, stop and ask. If a tool fails twice, log the error and move to the next one — don't stop the whole run. Don't run any demos; I'll test each tool afterwards.

Prerequisites first: check that Node.js 18+, Git and Bun are installed. If Bun is missing, install it from https://bun.sh. Tell me what you found before continuing.

1. last30days — https://github.com/mvanhorn/last30days-skill
   Install via the Claude Code plugin marketplace using the CLI: `claude plugin marketplace add mvanhorn/last30days-skill` then `claude plugin install last30days`. If the plugin CLI isn't available in this version, tell me the two /plugin slash commands to type and continue. Don't configure any API keys — it runs keyless.

2. claude-ads — https://github.com/AgriciDaniel/claude-ads
   Same method: `claude plugin marketplace add agricidaniel/claude-ads` then `claude plugin install claude-ads@ai-marketing-hub-claude-ads`. Same fallback if the CLI isn't available. It's read-only by default — leave it that way.

3. Playwright MCP — https://github.com/microsoft/playwright-mcp
   Register at user scope: `claude mcp add playwright npx @playwright/mcp@latest`. Verify it appears in `claude mcp list`.

4. archify — https://github.com/tt-a1i/archify
   Install globally: `npx skills add tt-a1i/archify -g`. Verify the skill folder exists under ~/.claude/skills/.

5. agency-agents — https://github.com/msitarzewski/agency-agents
   Clone to ~/claude-repos/agency-agents and run `./scripts/install.sh --tool claude-code`. Tell me how many agents landed in ~/.claude/agents/ and which divisions.

6. gstack — https://github.com/garrytan/gstack
   Run: `git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git ~/.claude/skills/gstack && cd ~/.claude/skills/gstack && ./setup`. Then add a "gstack" section to my global ~/.claude/CLAUDE.md that says to use the /browse skill from gstack for all web browsing, never use mcp__claude-in-chrome__* tools, and lists the available skills: /office-hours, /plan-ceo-review, /plan-eng-review, /plan-design-review, /design-consultation, /design-shotgun, /design-html, /review, /ship, /land-and-deploy, /canary, /benchmark, /browse, /connect-chrome, /qa, /qa-only, /design-review, /scrape, /setup-browser-cookies, /setup-deploy, /setup-gbrain, /retro, /investigate, /document-release, /document-generate, /codex, /cso, /autoplan, /plan-devex-review, /devex-review, /careful, /freeze, /guard, /unfreeze, /gstack-upgrade, /learn. Don't add it to any project — global only. If setup asks about the Aside browser, use the bundled browser.

7. Buzz — https://github.com/block/buzz
   This is a desktop app, not a Claude Code install. Detect my OS and chip, then download the matching packaged build from https://github.com/block/buzz/releases/latest to ~/Downloads (aarch64.dmg for Apple Silicon Mac, x64.dmg for Intel Mac, x64-setup exe for Windows). Don't run the installer. Then check ~/.claude/settings.json: if the default model is set to Fable 5, tell me — Buzz agents need a plan-included model like Sonnet 5 and I'll change it myself. Remind me to sign up for a free hosted community at https://buzz.xyz before the app will connect.

When all seven are done, give me one table: tool, INSTALLED / FAILED / NEEDS-ME, what you verified, and any manual step I still have to do. Then tell me to restart Claude Code.
```

After it finishes: restart Claude Code, open the Buzz installer from Downloads, sign up at buzz.xyz, and you're set.

**No Claude Code?** last30days has a claude.ai version — download `last30days.skill` from https://github.com/mvanhorn/last30days-skill/releases/latest and upload it at claude.ai → Customize → Skills → Create skill → Upload. Playwright MCP works in Claude Desktop via the config at the end of section 3. The other five need Claude Code.

---

## 1. last30days — it reads the internet for you

**Repo:** https://github.com/mvanhorn/last30days-skill
**Stars:** ~62,000 · **Cost:** free, no keys needed

**What it does**
One prompt becomes a research sweep across Reddit, X, YouTube, Hacker News, arXiv, Techmeme, Polymarket and the web, all at once, limited to the last 30 days, and ranked by real engagement so a post with 400 upvotes outranks a random blog. It comes back with a brief: what people are saying, what's rising, what's overrated, with quotes and the engagement numbers behind them. Think of it as a research assistant who reads every forum overnight and hands you a page in the morning.

**Why it beats a normal Claude prompt:** Claude's web search returns what Google ranks — SEO pages and press releases. This reads where people actually talk, only the last 30 days, ranked by how many people agreed. Claude tells you what the internet *wrote*; this tells you what the internet *thinks*.

**Install (Claude Code)**
```
/plugin marketplace add mvanhorn/last30days-skill
/plugin install last30days
```
Then run `/last30days` once. It offers optional API keys for X and YouTube — skip them all and it runs keyless. Keys go in your OS keychain if you add them later.

**Prompts**

The tools you use:
```
/last30days Claude vs ChatGPT vs Gemini for people who use them every day for work - which one is winning right now, what are people switching to, and what's the complaint nobody at the AI companies wants to hear
```

Before you build something:
```
/last30days paid communities for AI operators - what are people saying about the ones that exist, what do they complain about, and what would make one worth $49 a month
```

Before you post about a topic:
```
/last30days [your topic] - what's the most-upvoted take this month, what's the contrarian take, and what angle has nobody covered yet
```

---

## 2. Playwright MCP — it uses your browser

**Repo:** https://github.com/microsoft/playwright-mcp
**Stars:** ~37,000 · **Cost:** free · **Made by:** Microsoft

**What it does**
Playwright is the browser-automation engine most web developers already use. This is Microsoft's official MCP server for it. Plugged into Claude, it means Claude opens a real browser, clicks, types, scrolls, fills forms, reads pages and comes back with what it found — across many pages, remembering where it is. Instead of looking at screenshots and guessing where to click, it reads the page's structure — every button, link and field by name — so it clicks the right thing, fast, and cheaply.

**Why it beats computer use:** Claude in Chrome and computer-use tools work from screenshots and need you at the keyboard. Playwright reads the page directly, runs its own browser (headless if you like), stays logged in between sessions, and lives in Claude Code next to everything else in this guide. Claude in Chrome needs you there; this one doesn't.

**Install (Claude Code)**
```
claude mcp add playwright npx @playwright/mcp@latest
```
Verify with `/mcp` inside Claude Code. Needs Node.js 18+.

**Install (Claude Desktop)** — add to `claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["@playwright/mcp@latest"]
    }
  }
}
```

**A note on logins:** Playwright launches its own browser profile, so it won't be signed into your accounts. Log into a site once inside the Playwright window and the session persists.

**Prompts**

Competitor scan:
```
Open a browser and go to youtube.com/@[your channel]. Open the Videos tab and read the ten most recent uploads: title, view count, upload date. Then do the same for youtube.com/@[competitor]. Put all twenty in one table sorted by views per day since upload, and tell me in three lines what their titles are doing that mine aren't. Don't click anything except channel pages and video tiles.
```

Mobile QA on your site:
```
Open [your URL] in a mobile-sized viewport, 390 pixels wide. Scroll the whole page. Screenshot every element that's cut off, overlapping, or unreadable. Click every button and tell me where each one goes. Then give me a list of what's broken, worst first. Don't submit any forms.
```

Your own dashboard (log in once first):
```
Go to studio.youtube.com, open Analytics, and tell me which of my last five videos has the best click-through rate and which has the worst average view duration. Read the numbers off the page. Don't change anything.
```

---

## 3. claude-ads — it audits your ad account

**Repo:** https://github.com/AgriciDaniel/claude-ads
**Stars:** ~9,300 · **Cost:** free · **Licence:** MIT

**What it does**
A set of paid-media skills for Google Ads, Meta, TikTok and LinkedIn. It reads your account, scores its health, finds wasted spend, checks conversion tracking, spots campaigns competing with each other, and plans and writes creative. Every adapter is read-only by default; applying a change to a live account requires a separate explicit approval, so it cannot touch your budget on its own. Think of it as a senior media buyer doing a free audit that reads every campaign, not the top ten.

**Install (Claude Code)**
```
/plugin marketplace add agricidaniel/claude-ads
/plugin install claude-ads@ai-marketing-hub-claude-ads
```
If you added this marketplace before v2.0.0, remove the old alias first: `/plugin marketplace remove agricidaniel-claude-ads`, then run the two lines above.

Or from a clone: `git clone https://github.com/AgriciDaniel/claude-ads.git && cd claude-ads && bash install.sh --source=local`

Connecting an ad account follows the plugin's own prompts. Browser capture needs a Playwright browser installed (section 2 covers that); PDF export needs WeasyPrint and Pango on your machine, which is optional.

**Prompts**

The audit:
```
Audit my Google Ads account for the last 30 days. Give me a health score, the three biggest wasted-spend problems, and the one change you'd make first - but don't change anything.
```

Tracking check:
```
Check my conversion tracking across Google and Meta. Tell me which conversions are firing, which are double-counting, and which campaigns are optimising toward a broken signal. Read-only.
```

Creative plan:
```
Based on my best-performing ads in the last 90 days, write five new ad variations for the same audience: three that keep the winning angle and two that test a new one. Show me the winning ads you based them on.
```

---

## 4. archify — it draws your diagrams

**Repo:** https://github.com/tt-a1i/archify
**Stars:** ~64,000 · **Cost:** free

**What it does**
A skill that turns a description into a clean, verifiable diagram: architecture, workflow, sequence, data flow, lifecycle. No repository needed — describe the system in the chat and it renders it. It checks its own output for overlaps and clutter before handing it back. Think of it as a designer who draws the whiteboard version of whatever you just said, clean enough for a deck.

**Install (Claude Code)**
```
npx skills add tt-a1i/archify -g
```
That's it. Also works in Cursor, Codex and other Agent Skills hosts with the same command.

**Prompts**

Your company:
```
Draw an architecture diagram of how my company runs: [teams], [pipelines], [tools], and where Claude sits in each. Here's the context: [paste a paragraph about your business]. Make it clean enough to put in a deck.
```

A process you keep explaining:
```
Draw a workflow diagram of how a customer goes from first seeing us to paying us: every touchpoint, every handoff, who owns each step. Flag the step where most people drop off.
```

Onboarding:
```
Draw a sequence diagram of what happens in the first seven days after someone joins my community: emails, calls, content, check-ins. Show what's automated and what's manual.
```

---

## 5. gstack — it works like a YC company

**Repo:** https://github.com/garrytan/gstack
**Stars:** ~133,000 · **Cost:** free · **Made by:** Garry Tan, CEO of Y Combinator

**What it does**
Garry Tan open-sourced the exact skill stack he runs in Claude Code. It installs slash commands that put Claude into a role: `/office-hours` interrogates your idea the way a YC partner would, `/plan-ceo-review` tears a plan apart from the top, `/qa` opens your live site in a browser and reports what's broken. There are about thirty commands; most are for engineers shipping code. Three are for anyone with a business, and those three are the ones in the video.

**Requirements:** Git, Bun v1.0+ (https://bun.sh). On macOS it can use the Aside browser if you have it; otherwise setup builds its own bundled browser.

**Install (Claude Code)** — paste the README's own install prompt:
```
Install gstack: run git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git ~/.claude/skills/gstack && cd ~/.claude/skills/gstack && ./setup then add a "gstack" section to CLAUDE.md that says to use the /browse skill from gstack for all web browsing, never use mcp__claude-in-chrome__* tools, and lists the available skills: /office-hours, /plan-ceo-review, /plan-eng-review, /plan-design-review, /design-consultation, /design-shotgun, /design-html, /review, /ship, /land-and-deploy, /canary, /benchmark, /browse, /connect-chrome, /qa, /qa-only, /design-review, /scrape, /setup-browser-cookies, /setup-deploy, /setup-gbrain, /retro, /investigate, /document-release, /document-generate, /codex, /cso, /autoplan, /plan-devex-review, /devex-review, /careful, /freeze, /guard, /unfreeze, /gstack-upgrade, /learn. Then ask the user if they also want to add gstack to the current project so teammates get it.
```
Say no to "add to current project" unless you're inside a code repo.

**A note:** gstack tells Claude to use its own `/browse` skill for web browsing. If you want to use Playwright MCP for a task, run it in a separate session or say "use the Playwright MCP for this" in the prompt.

**Prompts**

Site check — run this first, it's the visual one:
```
/qa https://[your site]
```

The CEO review:
```
/plan-ceo-review [paste your plan in a paragraph: what you're launching, for whom, at what price, how you'll get customers]. Tear this apart.
```

Office hours — it talks back, answer honestly:
```
/office-hours [describe what you're building and the decision you're stuck on]
```

Skip `/cso`, `/ship`, `/review` and `/autoplan` unless you have a codebase.

---

## 6. agency-agents — it hires the team

**Repo:** https://github.com/msitarzewski/agency-agents
**Stars:** ~153,000 · **Cost:** free

**What it does**
Two hundred-plus specialist personas you install into Claude Code: growth marketer, brand strategist, video producer, copywriter, sales, support, finance, legal compliance, design, engineering. Each one is a file that tells Claude how that role thinks and what it produces. Activate one, or several, and they work the problem from their angle — and argue with each other if you tell them to. Think of it as an agency roster on your laptop, and none of them invoice you. Quality varies by persona: pick the ten that match your business and ignore the rest.

**Install — three options**

Desktop app (no terminal): download from https://github.com/msitarzewski/agency-agents-app/releases/latest, or on a Mac `brew install --cask msitarzewski/agency-agents/agency-agents`. It browses the roster, installs into Claude Code, Cursor, Codex and others, and keeps them updated.

Script (Claude Code):
```
git clone https://github.com/msitarzewski/agency-agents.git
cd agency-agents
./scripts/install.sh --tool claude-code
```
Add `--division marketing,sales` to install only the teams you want, or `--list teams` to see them all.

Manual — just copy the files you want:
```
cp marketing/*.md ~/.claude/agents/
```

**Prompts**

The argument:
```
Activate the Brand Strategist, the Growth Marketer and the Video Producer. Each of you: give me your single best idea for the next 90 days of [your business], then argue with each other about which one to do first.
```

One specialist, one job:
```
Activate the Growth Marketer. Here's my current funnel: [describe it]. Give me the three highest-leverage changes, ranked, with what you'd expect each to do to conversion.
```

The uncomfortable one:
```
Activate the Legal Compliance Checker. Here's my landing page copy: [paste]. Flag every claim I can't back up and every line that could get me in trouble.
```

---

## 7. Buzz — the office they all work in

**Repo:** https://github.com/block/buzz
**Stars:** ~33,000 · **Cost:** free (hosted communities free in early beta) · **Made by:** Block, Jack Dorsey's company

**What it does**
Block open-sourced the workspace they built for humans and AI agents to work together: channels, DMs, shared repos, and every agent has its own cryptographic identity with every action landing in one signed audit log. You run it as a desktop app connected to a hosted community, so there's nothing to host. Your Claude Code agents sit in the channels as teammates — you @mention them like colleagues, and you can see exactly what they read and did. Think of it as Slack, if the bots were employees with badges. It's weeks old and the maintainers say themselves it's rough at the edges.

**Install**

1. Download the app from https://github.com/block/buzz/releases/latest — `Buzz_<version>_aarch64.dmg` for Apple Silicon Macs, `_x64.dmg` for Intel Macs, `_amd64.AppImage` or `.deb` for Linux, `_x64-setup_alpha-unsigned.exe` for Windows (Windows will show a SmartScreen warning; click More info → Run anyway).
2. Sign up for a free hosted community at https://buzz.xyz. You'll get a relay address like `wss://<name>.communities.buzz.xyz`.
3. Open the app → Join a community → paste your relay address.
4. Create a managed agent with the Claude Code runtime. It uses your existing Claude Code login.

**Before your first message:** open `~/.claude/settings.json` and make sure Claude Code's default model is a plan-included one (Sonnet 5, for example). Block's own issue tracker confirms agents go silent on a Pro plan if the default is Fable 5. If an agent won't reply, change the model and restart the agent.

**Prompts** (in a channel)

Status update:
```
@agent read the last 20 messages in this channel and write me a one-paragraph status update I can send to the team
```

Delegation:
```
@agent go through the #research channel from this week, pull out every link people shared, and post a summary with one line on why each one matters
```

Two agents, one task:
```
@writer draft the announcement for Friday's launch. @editor review it and post your edits in-thread. Both of you: keep it under 150 words.
```

---

## Safety notes, once

- Playwright MCP and gstack's `/browse` can click things. Say "don't submit any forms" and "don't change anything" in prompts until you trust a workflow.
- claude-ads is read-only by default. Keep it that way until you've watched it work for a week.
- Every Claude call bills your plan or key. Agents that argue with each other use tokens; keep the first runs short.
- Buzz is pre-1.0. Don't put anything in it you'd mind losing.
- Never paste passwords, private keys or live-account secrets into a chat. Every tool here takes credentials through config or a login screen, not through the conversation.
