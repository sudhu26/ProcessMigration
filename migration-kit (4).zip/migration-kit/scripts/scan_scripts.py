#!/usr/bin/env python3
"""Scan shell/python/perl scripts for downstream invocations: java main
classes, other scripts, sql files (sqlplus @file), python scripts.
Stdlib only.

Usage: scan_scripts.py --root <dir> --repo <name> --out <file.json>
"""
import argparse, json, os, re

EXTS = ('.sh', '.ksh', '.bash', '.pl', '.py')

JAVA_MAIN_RE = re.compile(
    r'\bjava\b\s+(?:-[^\s]+\s+(?:[^\s]+\s+)?)*?'
    r'((?:[a-zA-Z_$][\w$]*\.)+[A-Z][\w$]*)')
JAR_RE = re.compile(r'[\w./\\:-]+\.jar\b', re.IGNORECASE)
SCRIPT_RE = re.compile(r'[\w./\\:-]+\.(?:sh|ksh|bash|pl|py)\b', re.IGNORECASE)
SOURCE_RE = re.compile(r'(?:^|[\s;])(?:source|\.)\s+([\w./\\:-]+\.(?:sh|ksh|bash))\b',
                       re.IGNORECASE)
SQLPLUS_RE = re.compile(r'@([\w./\\:-]+\.sql)\b', re.IGNORECASE)
PYTHON_RE = re.compile(r'\bpython[23]?\b\s+([\w./\\:-]+\.py)\b', re.IGNORECASE)
FULL_LINE_COMMENT = re.compile(r'(?m)^\s*#.*$')


def uniq(seq):
    out = []
    for x in seq:
        if x not in out:
            out.append(x)
    return out


def analyze(path, repo):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except OSError:
        return None
    code = FULL_LINE_COMMENT.sub('', text)
    own = os.path.basename(path)

    java_mains = uniq(m.group(1) for m in JAVA_MAIN_RE.finditer(code)
                      if '.jar' not in m.group(1))
    jars = uniq(JAR_RE.findall(code))
    scripts_called = uniq(s for s in SCRIPT_RE.findall(code)
                          if os.path.basename(s).lower() != own.lower())
    scripts_called += [s for s in uniq(SOURCE_RE.findall(code))
                       if os.path.basename(s).lower() != own.lower()
                       and s not in scripts_called]
    sql_files = uniq(SQLPLUS_RE.findall(code))
    python_files = uniq(PYTHON_RE.findall(code))

    return {'path': path, 'repo': repo,
            'java_mains': java_mains, 'jars': jars,
            'scripts_called': scripts_called,
            'sql_files': sql_files, 'python_files': python_files}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--repo', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    records = []
    for dirpath, _, filenames in os.walk(a.root):
        for fn in filenames:
            if fn.lower().endswith(EXTS):
                rec = analyze(os.path.join(dirpath, fn), a.repo)
                if rec:
                    records.append(rec)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=1)
    linked = sum(1 for r in records
                 if r['java_mains'] or r['scripts_called'] or r['sql_files'])
    print(f'scanned {len(records)} scripts ({linked} with invocations) -> {a.out}')


if __name__ == '__main__':
    main()
