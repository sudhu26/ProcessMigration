package com.risk.edge;

/** Star-rule regression (R6-B2, new assertion 38): `*` is recorded as
 *  `*` only when the outer FROM tables plus the FROM-clause
 *  derived-table tables (including UNION/MINUS/INTERSECT branches)
 *  name exactly one table; subqueries in WHERE or the SELECT list do
 *  not count. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (StarRule.java record): tables_read ['T1', 'T2', 'T3'],
 *  table_columns {'T1': {'read': ['*', 'A'], 'write': []},
 *                   'T2': {'read': ['A', 'Y'], 'write': []},
 *                   'T3': {'read': ['Y'], 'write': []}},
 *  columns_unattributed [] — the outer `*` of the first and third
 *  statements is recorded under T1 (the WHERE subquery's table does
 *  not count), and the `*` of the second statement is dropped (its
 *  derived table names two tables), leaving only T1 'A' / T2 'A'
 *  from its UNION branches. */
public class StarRule {

    public void run(java.sql.Statement st) throws Exception {
        String whereSubquery =
                "SELECT * FROM t1 WHERE x IN (SELECT y FROM t2)";
        st.executeQuery(whereSubquery);

        String unionInDerived =
                "SELECT * FROM (SELECT a FROM t1 UNION SELECT a FROM t2) x";
        st.executeQuery(unionInDerived);

        String whereUnionSubquery =
                "SELECT * FROM t1 WHERE x IN (SELECT y FROM t2 UNION SELECT y FROM t3)";
        st.executeQuery(whereUnionSubquery);
    }
}
