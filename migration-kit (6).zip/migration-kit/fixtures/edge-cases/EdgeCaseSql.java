package com.risk.wm.jobs;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Statement;

/** Scanner edge cases (review blockers B10-B13). No main() method, so
 *  no synthetic unit is created. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected record: tables_read [MY_FUNC, RISK_POSITIONS, T1],
 *  tables_written [], procs_called [CALLMYPROC], sql_literal_count 4,
 *  and the text-block literal merged with its WHERE fragment. */
public class EdgeCaseSql {

    public void run(Connection con) throws Exception {
        try (Statement st = con.createStatement()) {
            // B10: SELECT ... INTO var must NOT record V as a written table
            String intoSql = "SELECT X INTO v FROM T1";
            st.executeQuery(intoSql);

            // B11: TABLE(...) reads MY_FUNC; no bogus table TABLE
            String tableSql = "SELECT * FROM TABLE(my_func)";
            st.executeQuery(tableSql);

            // B12: prepareCall without braces must be found
            try (CallableStatement cs = con.prepareCall("CALL MYPROC()")) {
                cs.execute();
            }

            // B13: text block followed by a concatenated fragment merges
            String blockSql = """
                    SELECT BOOK, EXPOSURE FROM RISK_POSITIONS
                    """
                    + " WHERE AS_OF_DATE = SYSDATE";
            st.executeQuery(blockSql);
        }
    }
}
