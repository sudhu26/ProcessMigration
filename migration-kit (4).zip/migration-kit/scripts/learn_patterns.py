#!/usr/bin/env python3
"""Learn migration patterns from already-migrated processes.

Two inputs, either or both:
  --pairs pairs.json   [{"onprem": path, "migrated": path, "approved": bool}]
                       approved=true means you vetted that migrated file as a
                       correct migration of the on-prem file.
  --migrated-dir dir   migrated-only code (no on-prem counterpart): yields the
                       cloud idiom inventory, not mappings.

Output is patterns.json:
  library_map   on-prem import -> cloud import (e.g. com.risk.db.OracleWriter
                -> com.bank.cloud.AdlsWriter), with evidence + status
  call_map      on-prem call idiom -> cloud idiom (or null = dropped, e.g.
                Connection.commit has no equivalent — Delta writes are atomic)
  sql_overrides statement-level Oracle->Spark rewrites observed in the
                exemplars that the mechanical translator did NOT produce
                (e.g. a MERGE the translator flagged but a human rewrote)
  cloud_idioms  frequency counts of imports / calls in migrated code

Honesty rule: pairing a removed on-prem import with an added cloud import is
a semantic judgment, not a name match, so derived mappings start as
`proposed` with their evidence attached. They become `approved` only when:
  - --approve auto and the pairing is unambiguous (exactly one removed and
    one added import in that pair, or the same pairing seen in >= 3 pairs), or
  - --approve all (you assert you vetted the exemplars), or
  - a human/agent edits "status" to "approved" in patterns.json.
Only `approved` entries are applied by prepare_migration_tree.py --patterns.
--base merges into an existing patterns.json instead of starting fresh, so the
library grows as more processes are migrated (approved entries stay approved).

Stdlib only.
"""
import argparse, json, os, re, sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from scan_java import analyze_file as analyze_java  # noqa: E402
from scan_plsql import analyze_file as analyze_plsql  # noqa: E402
from translate_sql import translate  # noqa: E402

JAVA_EXTS = ('.java',)
SQL_EXTS = ('.sql', '.pls', '.pks', '.pkb', '.fnc', '.prc', '.trg', '.vw',
            '.tab', '.seq')
_CALL_RE = re.compile(r'\b([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)\s*\(')
_NEW_RE = re.compile(r'\bnew\s+([A-Z]\w*)\s*\(')


def norm(s):
    return ' '.join(s.split())


def strip_code(text):
    """Remove string/char literals and comments (approximate, for call
    extraction only — never used for translation)."""
    text = re.sub(r"'(?:''|[^'])*'", "''", text)
    text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    text = re.sub(r'/\*.*?\*/', ' ', text, flags=re.DOTALL)
    text = re.sub(r'//[^\n]*', ' ', text)
    return text


def java_calls(text):
    """Method names + receiver.method shapes used in a Java file."""
    clean = strip_code(text)
    methods = set()
    shapes = set()
    for recv, meth in _CALL_RE.findall(clean):
        methods.add(meth)
        shapes.add(f'{recv}.{meth}')
    for cls in _NEW_RE.findall(clean):
        shapes.add(f'new {cls}')
    return methods, shapes


def split_statements(text):
    return [s for s in re.split(r'(?<=;)', text) if s.strip()]


def analyze_pair(onprem, migrated):
    """Return a dict of derived candidates for one exemplar pair."""
    ext = os.path.splitext(onprem)[1].lower()
    out = {'onprem': onprem, 'migrated': migrated, 'kind': ext}
    if ext in JAVA_EXTS:
        a = analyze_java(onprem, os.path.basename(os.path.dirname(onprem)))
        b = analyze_java(migrated, os.path.basename(os.path.dirname(migrated)))
        out['removed_imports'] = sorted(set(a['imports']) - set(b['imports']))
        out['added_imports'] = sorted(set(b['imports']) - set(a['imports']))
        with open(onprem, encoding='utf-8', errors='replace') as f:
            ta = f.read()
        with open(migrated, encoding='utf-8', errors='replace') as f:
            tb = f.read()
        ma, _ = java_calls(ta)
        mb, _ = java_calls(tb)
        out['removed_calls'] = sorted(ma - mb)
        out['added_calls'] = sorted(mb - ma)
    elif ext in SQL_EXTS:
        a = analyze_plsql(onprem, os.path.basename(os.path.dirname(onprem)))
        b = analyze_plsql(migrated, os.path.basename(os.path.dirname(migrated)))
        out['removed_tables'] = sorted(
            (set(a['reads']) | set(a['writes']))
            - (set(b['reads']) | set(b['writes'])))
        with open(onprem, encoding='utf-8', errors='replace') as f:
            ta = f.read()
        with open(migrated, encoding='utf-8', errors='replace') as f:
            tb = f.read()
        out['overrides'] = []
        for sa, sb in zip(split_statements(ta), split_statements(tb)):
            r = translate(sa)
            # case-insensitive compare: formatting/case alone is not a
            # learned override, a real rewrite is
            if norm(r['translated']).lower() != norm(sb).lower() and norm(sb):
                out['overrides'].append({'from': norm(sa), 'to': norm(sb),
                                         'mechanical': r['translated']})
    else:
        out['skipped'] = f'unsupported extension {ext}'
    return out


def scan_migrated_dirs(dirs):
    """Frequency counts of imports / calls across migrated-only code."""
    imports, calls = Counter(), Counter()
    for d in dirs:
        for dirpath, _, filenames in os.walk(d):
            for fn in filenames:
                p = os.path.join(dirpath, fn)
                if fn.endswith(JAVA_EXTS):
                    rec = analyze_java(p, '')
                    imports.update(rec['imports'])
                    with open(p, encoding='utf-8', errors='replace') as f:
                        m, _ = java_calls(f.read())
                    calls.update(m)
                elif fn.endswith(SQL_EXTS):
                    rec = analyze_plsql(p, '')
                    calls.update(rec.get('calls', []))
    return {'imports': dict(imports.most_common()),
            'calls': dict(calls.most_common())}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--pairs', default='',
                    help='pairs.json: [{"onprem": path, "migrated": path, '
                         '"approved": bool}]')
    ap.add_argument('--migrated-dir', default='',
                    help='comma-separated dirs of migrated-only code')
    ap.add_argument('--base', default='',
                    help='existing patterns.json to merge into')
    ap.add_argument('--approve', default='',
                    choices=['', 'auto', 'all'],
                    help='auto: approve only unambiguous derivations; '
                         'all: approve everything (you vetted the exemplars)')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()

    lib, calls, overrides = [], [], []
    pair_summaries = []
    if a.pairs:
        with open(a.pairs, encoding='utf-8') as f:
            pairs = json.load(f)
        for i, pr in enumerate(pairs):
            pid = f'pair-{i + 1}'
            if not os.path.exists(pr['onprem']) or not os.path.exists(pr['migrated']):
                print(f'warning: {pid} paths missing, skipped: '
                      f"{pr['onprem']} -> {pr['migrated']}", file=sys.stderr)
                continue
            d = analyze_pair(pr['onprem'], pr['migrated'])
            d['id'] = pid
            d['vetted'] = bool(pr.get('approved'))
            pair_summaries.append(d)
            if 'skipped' in d:
                continue
            # --- library mappings ---
            rem, add = d.get('removed_imports', []), d.get('added_imports', [])
            if len(rem) == 1 and len(add) == 1:
                lib.append({'from': rem[0], 'to': add[0],
                            'evidence': [pid], 'unambiguous': True})
            else:
                for r in rem:
                    for t in add:
                        lib.append({'from': r, 'to': t, 'evidence': [pid],
                                    'unambiguous': False,
                                    'note': f'ambiguous: {len(rem)} removed x '
                                            f'{len(add)} added in {pid}'})
            # --- call mappings: only the unambiguous shapes ---
            rc, ac = d.get('removed_calls', []), d.get('added_calls', [])
            if len(rc) == 1 and len(ac) == 1:
                calls.append({'from': rc[0], 'to': ac[0], 'evidence': [pid],
                              'unambiguous': True})
            elif len(rc) == 1 and len(ac) == 0:
                calls.append({'from': rc[0], 'to': None, 'evidence': [pid],
                              'unambiguous': True,
                              'note': 'dropped in the migrated code — no '
                                      'equivalent call observed'})
            # --- SQL overrides ---
            for ov in d.get('overrides', []):
                overrides.append({**ov, 'evidence': [pid],
                                  'vetted': d['vetted']})

    idioms = {'imports': {}, 'calls': {}}
    if a.migrated_dir:
        idioms = scan_migrated_dirs([s for s in a.migrated_dir.split(',')
                                     if s.strip()])

    # --- approve + merge ---
    base = {'library_map': [], 'call_map': [], 'sql_overrides': []}
    if a.base and os.path.exists(a.base):
        with open(a.base, encoding='utf-8') as f:
            base = json.load(f)

    def merge_list(existing, new, key):
        idx = {(e['from'], e.get('to')): e for e in existing}
        for e in new:
            k = (e['from'], e.get('to'))
            if k in idx:
                old = idx[k]
                old['evidence'] = sorted(set(old.get('evidence', []))
                                         | set(e['evidence']))
                old['count'] = len(old['evidence'])
                continue
            e['count'] = len(e['evidence'])
            if a.approve == 'all':
                e['status'] = 'approved'
            elif a.approve == 'auto' and e.get('unambiguous'):
                e['status'] = 'approved'
            elif a.approve == 'auto' and e.get('vetted'):
                e['status'] = 'approved'
            else:
                e['status'] = 'proposed'
            existing.append(e)
        return existing

    lib = merge_list(base.get('library_map', []), lib, 'library_map')
    calls = merge_list(base.get('call_map', []), calls, 'call_map')
    overrides = merge_list(base.get('sql_overrides', []), overrides,
                           'sql_overrides')
    for i, e in enumerate(lib, 1):
        e.setdefault('id', f'lib-{i:03d}')
    for i, e in enumerate(calls, 1):
        e.setdefault('id', f'call-{i:03d}')
    for i, e in enumerate(overrides, 1):
        e.setdefault('id', f'sql-{i:03d}')
    # drop the working flags from the published file
    for e in lib + calls + overrides:
        e.pop('unambiguous', None)
        e.pop('vetted', None)

    out = {'version': 1,
           'generated_from': {
               'pairs': [p['id'] for p in pair_summaries],
               'migrated_dirs': [s for s in a.migrated_dir.split(',')
                                 if s.strip()]},
           'library_map': lib, 'call_map': calls,
           'sql_overrides': overrides, 'cloud_idioms': idioms}
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(out, f, indent=1)
    n_app = sum(1 for e in lib + calls + overrides
                if e['status'] == 'approved')
    print(f"{len(lib)} library mappings, {len(calls)} call mappings, "
          f"{len(overrides)} SQL overrides ({n_app} approved) -> {a.out}")


if __name__ == '__main__':
    main()
