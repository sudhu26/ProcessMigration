# Claude + Instagram = $15,000/month
### The machine, the offers, and the exact tools — from the video

One machine, two lanes. Your face on the reel, or a faceless account. Both feed the same pipe, and nothing in the loop needs you.

---

## 1. The map

```
        CLAUDE — writes the content · writes the DMs · builds the offer
           ↓                 ↓                    ↓
Reel → Comment → DM → Free layer → Paid → Offer
 ↑
 ├── My account (my face on the reel)
 └── Faceless account (Higgsfield avatar)
```

Every box on that line is either made by Claude or automated.

---

## 2. Content in

**Shared steps (both lanes)**

1. **Scrape what's winning** — Firecrawl pulls top reels/captions in your niche
2. **Claude breaks down why it worked** — hook, structure, comment triggers
3. **Copy bank (Notion)** — hooks tagged by theme: Receipts · Leverage · Grind · Delusion · Haters · Freedom
4. **New scripts in your voice** — Claude writes the batch from the bank

**Then the lanes split**

| My account | Faceless account |
|---|---|
| I film the a-roll hooks | Higgsfield generates UGC from the script |
| Converts at every tier | Converts at $20–99, not $1k |

**Both end in Postiz** — Claude writes ten, Postiz posts them, you're not there.

**The loop:** which reels earned comments feeds the next batch. Every reel is a door into the funnel — volume of doors matters more than any single one.

---

## 3. The pipe (ManyChat)

Rows merge here. The funnel doesn't care whether there's a face.

1. **Comment keyword** — feeds the algorithm *and* captures the lead
2. **DM** — Claude wrote it (see prompt below)
3. **Phone number before the link** — 50,000 contacts came from this one step
4. **Free layer split**
   - Telegram → free alpha
   - Skool → free AI trading community (3,000 members)
   - Free Discord → never

Why not Instagram's native auto-reply? It can't capture an email or phone, and it can't branch on the answer.

---

## 4. The offer

**The rule:** static = $99 · human judgment = $199

**My ladder**

```
Free layer → $20 agents (à la carte) → $99 static → $199 discretionary → $1k+ consulting
```

**Your ladder, with no brand**

```
Free lead magnet → $27 Claude-built product → $97 course / template → done-for-you service
```

Your first offer is the thing you built for yourself with Claude. The product sold through the funnel was itself built in a Claude session.

### Seven ways to get paid with this machine

Same pipe every time — only the buyer changes.

1. **Run it for clients** — done-for-you funnel, $1–3k/mo retainer
2. **AI agency** — launch faceless / UGC accounts for clients or your own
3. **Growth operator for a creator** — rev share on their backend
4. **Local business lead gen** — dentist, gym, clinic
5. **Sell the Claude-built product** — $27–97, no calls, no clients
6. **Sponsors + affiliates** — the list is the asset
7. **DM setter service** — run the flows, book the calls

You don't need an audience. You need the pipe and one buyer.

---

## 5. Scale

Once organic tells you which reel converts, put money behind it with **claude-ads**:

1. Take the best organic reel
2. Claude writes 5 Meta ad variations of it
3. Tracking check before spend
4. Then spend — the repo is read-only until you approve

**Pricing, one line:** ManyChat Pro + Claude Pro. The repos are free.

---

## 6. The math

| Receipts | |
|---|---|
| Whop | $5.5M+ lifetime |
| Skool | 3,000 members (just launched) |
| ManyChat | 50,000 contacts |

**$15k/month is only:**

- 5 clients × $3k
- 1 sponsor
- 75 members × $199
- 150 members × $99
- ~550 × $27 product
- 1% of 50k contacts

Pick the one that fits your lane — the pipe is the same.

> Instagram isn't where you post. It's the front door to a list you own.

---

## The prompts

**Design the funnel**

```
Here's everything I sell: [list your offers with prices, free ones included].
Here's my Instagram audience: [size, niche, what they DM me about].
Design a funnel from a reel comment to the [$X] tier. For each step tell me:
what the DM says, what I ask for, what the free thing is, and where people
will drop off. Then tell me which offer is missing.
```

**Write the DM flow**

```
Write a 4-message Instagram DM flow for someone who commented "[KEYWORD]"
on a reel about [topic]. Message 1 delivers the thing, message 2 asks one
qualifying question, message 3 offers the free community, message 4 is only
sent if they reply. Sound like me — here are 10 of my real DMs: [paste].
```

**Feed the top**

```
Here are my last 30 reels with views and comment counts: [paste].
Which hooks earned comments, and why? Write 20 new lines in the same
categories, in my voice.
```

**Read the DMs**

```
Here's an export of [N] Instagram DM conversations: [paste].
What are people actually asking for? Group the requests, rank them by
frequency, and tell me which product I should build next.
```

---

## The repos

All free, all driven from Claude Code.

| Repo | What it does in this system | Link |
|---|---|---|
| **claude-ads** | Paid-media skills for Meta, Google, TikTok, LinkedIn. Audits the ad account, finds wasted spend, checks tracking, writes creative. Read-only by default. | github.com/AgriciDaniel/claude-ads |
| **Postiz** | Open-source scheduler. Claude writes the batch, Postiz posts across Instagram and everywhere else. | github.com/gitroomhq/postiz-app |
| **Firecrawl** | Scrapes competitor reels, captions and pages into clean text Claude can read. The "what's winning" step. | github.com/firecrawl/firecrawl |

**Install claude-ads** (inside Claude Code):

```
/plugin marketplace add agricidaniel/claude-ads
/plugin install claude-ads@ai-marketing-hub-claude-ads
```

**Not repos, but in the stack:** ManyChat (the pipe), Higgsfield (faceless UGC, connects to Claude), Whop / Skool (where the offer lives), Notion (copy bank).
