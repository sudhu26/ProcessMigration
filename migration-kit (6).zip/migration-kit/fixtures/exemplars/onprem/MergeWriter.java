package com.risk.jobs;

// Assertion 32 (R5-G1): the fixture MERGE as a Java string literal —
// exactly the onprem/merge_load.sql text but WITHOUT a trailing ';'
// (Java SQL literals essentially never end with ';'). With the approved
// sql-001 override, translate() must still match it (the terminator is
// stripped from both sides before comparing) and report
// applied: ["pattern:sql-001"].
public class MergeWriter {
    public void run() {
        String sql = "MERGE INTO RISK_RESULTS r USING (SELECT BOOK, SUM(EXPOSURE) AS TOTAL_EXPOSURE FROM RISK_POSITIONS GROUP BY BOOK) s ON (r.BOOK = s.BOOK) WHEN MATCHED THEN UPDATE SET r.TOTAL_EXPOSURE = s.TOTAL_EXPOSURE WHEN NOT MATCHED THEN INSERT (BOOK, TOTAL_EXPOSURE) VALUES (s.BOOK, s.TOTAL_EXPOSURE)";
    }
}
