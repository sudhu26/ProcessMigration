#!/usr/bin/env python3
"""Scan shell/python/perl scripts for downstream invocations: java main
classes, other scripts, sql files (sqlplus @file), python scripts.
Stdlib only.

Usage: scan_scripts.py --root <dir> --repo <name> --out <file.json>
"""
import argparse, json, os, re

EXTS = ('.sh', '.ksh', '.bash', '.pl', '.py')

JAVA_MAIN_RE = re.compile(
    r'\bjava\b\s+(?:-[^\s]+\s+(?:[^\s]+\s+)?)*?'
    r'((?:[a-zA-Z_$][\w$]*\.)+[A-Z][\w$]*)')
# .jar must not be followed by '.' or an identifier character, or a
# package segment literally named 'jar' (com.foo.jar.Bar) yields a
# phantom jar entry (R4-N8).
JAR_RE = re.compile(r'[\w./\\:-]+\.jar(?![\w.])', re.IGNORECASE)
SCRIPT_RE = re.compile(r'[\w./\\:-]+\.(?:sh|ksh|bash|pl|py)\b', re.IGNORECASE)
SOURCE_RE = re.compile(r'(?:^|[\s;])(?:source|\.)\s+([\w./\\:-]+\.(?:sh|ksh|bash))\b',
                       re.IGNORECASE)
SQLPLUS_RE = re.compile(r'@([\w./\\:-]+\.sql)\b', re.IGNORECASE)
# Matches `python x.py` and flagged / versioned forms: `python -u x.py`,
# `python3.11 x.py`, `python3 -u x.py`. (A flag that takes a value, e.g.
# `python -W ignore x.py`, is not matched.)
PYTHON_RE = re.compile(
    r'\bpython[23]?(?:\.\d+)*\b(?:\s+-[A-Za-z]\w*)*\s+([\w./\\:-]+\.py)\b',
    re.IGNORECASE)
FULL_LINE_COMMENT = re.compile(r'(?m)^\s*#.*$')


def uniq(seq):
    out = []
    for x in seq:
        if x not in out:
            out.append(x)
    return out


def analyze(path, repo):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except OSError:
        return None
    code = FULL_LINE_COMMENT.sub('', text)
    own = os.path.basename(path)

    # R5-G10: no 'jar'-segment filter — JAVA_MAIN_RE anchors on the
    # `java` keyword, so a .jar path can never match it; the filter could
    # only drop real mains in packages like com.foo.jar.Bar.
    # R7-G9: `-jar <jar>` is terminal, as in scan_jobs.py
    # dissect_command (R6-G7) — anything after it is an argument to the
    # jar's main(), not the main class. The gate is applied per line
    # (each line is one command): a main class is accepted only when
    # its match starts before any `-jar` token on the same line, so a
    # real main on a later line is still kept.
    java_mains = []
    for m in JAVA_MAIN_RE.finditer(code):
        line_start = code.rfind('\n', 0, m.start()) + 1
        head = code[line_start:m.start(1)]
        if re.search(r'(?<![\w-])-jar\b', head):
            continue
        java_mains.append(m.group(1))
    java_mains = uniq(java_mains)
    jars = uniq(JAR_RE.findall(code))
    scripts_called = uniq(s for s in SCRIPT_RE.findall(code)
                          if os.path.basename(s).lower() != own.lower())
    scripts_called += [s for s in uniq(SOURCE_RE.findall(code))
                       if os.path.basename(s).lower() != own.lower()
                       and s not in scripts_called]
    sql_files = uniq(m for line in code.splitlines()
                     if re.search(r'\bsqlplus\b', line, re.I)
                     for m in SQLPLUS_RE.findall(line))
    python_files = uniq(PYTHON_RE.findall(code))

    return {'path': path, 'repo': repo,
            'java_mains': java_mains, 'jars': jars,
            'scripts_called': scripts_called,
            'sql_files': sql_files, 'python_files': python_files}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--repo', required=True)
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    records = []
    for dirpath, _, filenames in os.walk(a.root):
        for fn in filenames:
            if fn.lower().endswith(EXTS):
                rec = analyze(os.path.join(dirpath, fn), a.repo)
                if rec:
                    records.append(rec)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=1)
    linked = sum(1 for r in records
                 if r['java_mains'] or r['scripts_called'] or r['sql_files'])
    print(f'scanned {len(records)} scripts ({linked} with invocations) -> {a.out}')


if __name__ == '__main__':
    main()
