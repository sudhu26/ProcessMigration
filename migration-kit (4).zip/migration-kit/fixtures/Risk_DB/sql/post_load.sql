-- post-load audit row, run via sqlplus from run_nightly.sh
INSERT INTO RISK_AUDIT (JOB_NAME, RUN_DATE, STATUS)
SELECT 'NIGHTLY_RISK_JOB', SYSDATE, 'OK' FROM RISK_RESULTS;
COMMIT;
