package com.risk.edge;

/** Comma-only FROM regression (R5-G6): a single comma-joined statement
 *  with NO JOIN statement in the same file to mask it. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (CommaTables.java record): tables_read ['T1', 'T2'],
 *  table_columns {} (a and b are multi-table bare columns),
 *  columns_unattributed ['A', 'B']. */
public class CommaTables {

    public void run(java.sql.Statement st) throws Exception {
        String commaSql = "SELECT a, b FROM t1, t2";
        st.executeQuery(commaSql);
    }
}
