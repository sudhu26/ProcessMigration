import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

/** Legacy job with NO package declaration (default package). */
public class LegacyJob {
    public static void main(String[] args) throws Exception {
        Connection con = DriverManager.getConnection("jdbc:oracle:thin:@db:1521/RISK");
        Statement st = con.createStatement();
        st.executeUpdate("UPDATE RISK_POSITIONS SET EXPOSURE = 0 WHERE BOOK = 'LEGACY'");
        con.commit();
        con.close();
    }
}
