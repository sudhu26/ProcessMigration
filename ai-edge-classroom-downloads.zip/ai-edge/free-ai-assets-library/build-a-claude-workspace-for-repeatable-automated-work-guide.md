# Build a Claude Workspace for Repeatable Automated Work

Set up connectors, portable memory, reusable skills, recurring tasks, and orchestrated workflows in one practical system.

## What you will achieve

You will create a Claude workspace that understands your context, follows your preferences, performs a repeatable task, and can run selected work on a recurring cadence.

## Who this is for

Claude users, creators, operators, and business owners who want to move beyond isolated chats into reusable workflows.

**Difficulty:** Intermediate

## Short tutorial

Set up connectors, portable memory, reusable skills, recurring tasks, and orchestrated workflows in one practical system.

### Guide: Build a Context Rich Claude Workspace That Automates Repeatable Work

**Time:** About 60 minutes

## What You Will Build

This tutorial turns Claude from a blank chat window into a context rich working system. You will create a portable local memory folder, connect useful data sources, document one repeatable skill, and configure recurring or orchestrated work where those features are available.

Use the guide in order. Start with a low risk workflow, such as research, content ideation, document preparation, or internal reporting. Review every generated file before relying on it for important decisions.

Feature names and command availability can vary by Claude version and workspace. If a command shown here is unavailable, use the equivalent control exposed in your interface.

## 1. Choose the Right Claude Surface

Use the surface that matches the task instead of forcing every job into a standard chat.

| Surface | Best use | Context available |
|---|---|---|
| Claude Chat | Questions, brainstorming, and light document review | Information supplied in the conversation or project |
| Claude Cowork | Work involving local folders, documents, memory, and file editing | Selected local files and folders |
| Claude Code | Application development, larger builds, and code intensive work | Project files and development context |

For this implementation, begin in Cowork because it combines a familiar conversation interface with access to a local memory folder. Use Chat when you are on the go, and move larger software builds to Claude Code.

## 2. Add Connectors for Current or Specialized Information

Claude can only reason over information it can access. Connectors act as bridges to other data sources and applications.

Open Claude Settings, find **Connectors**, and search the available library. The transcript highlights examples such as:

* Google Drive for company documents
* Gmail, Slack, and Google Calendar for communication and scheduling context
* Notion for tasks and workspace information
* FMP or Quiver for specialized financial information
* Media generation services when supported by an available connector

Add only connectors relevant to your workflow. A useful connector should provide information that Claude would not reliably have on its own.

### Connector checklist

Before using a connector in automated work, confirm:

* The correct account or workspace is connected.
* Claude can access the intended files or data.
* The connector exposes the information needed for the task.
* You understand whether Claude can only view information or can also edit it.
* Sensitive business data has appropriate account protection, including two factor authentication where applicable.

Test each connector with a narrow request:

```text
Using the connected [DATA SOURCE], find [SPECIFIC ITEM].

Return:
1. The information you found
2. The source record or document name
3. Any missing information

Do not make changes yet.
```

## 3. Create a Portable Local Memory System

Create a folder on your computer that you control. This folder becomes the portable context layer that can later be backed up or used with another model.

A practical structure is:

```text
AI-Brain/
├── context.md
├── instructions.md
├── memory.md
├── businesses/
│   └── primary-business/
│       ├── overview.md
│       ├── strategy.md
│       ├── offers.md
│       └── workflows.md
└── skills/
    └── first-skill/
        └── skill.md
```

Use Markdown files rather than PDFs for the core memory system. Markdown is easier for Claude to read and edit.

### Create `context.md`

This file contains relatively stable facts about you, your responsibilities, and your business. Ask Claude to interview you and draft it.

Copy this prompt into Claude:

```text
Help me create a concise context.md file that gives an AI assistant the stable context it needs to support my work.

Interview me one question at a time. Cover only relevant areas, including:

1. My role and responsibilities
2. My business or work
3. My products, services, or major projects
4. My audience or customers
5. My current goals
6. My constraints, including time, budget, and team capacity
7. My preferred decision criteria
8. Tools and data sources I use
9. Important terminology
10. Facts an assistant must not assume incorrectly

After the interview, produce a structured Markdown document. Separate verified facts from uncertain or incomplete information. Keep it concise enough to use as recurring context.

Do not invent missing details. Mark anything that requires confirmation.
```

Read the result line by line. Correct every inaccurate number, goal, constraint, and business fact. Future recommendations may depend on this file.

### Create `instructions.md`

This file defines how Claude should behave and how it should manage your memory.

Copy and adapt this template:

```markdown
# Operating Instructions

## Response Style

- Be concise, analytical, and practical.
- Lead with the recommendation or result.
- Use clear headings, numbered steps, and tables when useful.
- Avoid unnecessary repetition.
- State assumptions explicitly.
- Distinguish facts, estimates, and opinions.

## Reasoning and Decisions

- Do not confirm my bias merely because I suggested an option.
- Identify important risks, constraints, and tradeoffs.
- Prefer recommendations that support the goals in context.md.
- Ask a clarifying question when missing information could materially change the answer.
- Never invent business facts, financial figures, deadlines, or customer information.

## Context Loading

- Read context.md and memory.md when they are relevant to the request.
- Read files inside businesses/primary-business only when the request concerns that business.
- Do not load unrelated folders merely because they are available.
- If two files conflict, notify me before relying on either one.

## Memory Management

- Update memory.md when I provide a substantial new fact, decision, goal, constraint, or change in direction.
- Notify me every time you propose or make a change to memory.md.
- Show the exact information being added, changed, or removed.
- Do not store speculation as fact.
- Do not duplicate information already present.
- Keep memory.md concise and organized.
- Ask for confirmation before recording sensitive, ambiguous, or potentially temporary information.

## File Changes

- Before changing an important file, summarize the intended change.
- After changing a file, list the files changed and describe what changed.
- Preserve existing information unless the new request explicitly replaces it.
```

### Create `memory.md`

This file holds important information that changes over time. Keep it smaller than the detailed business folders.

```markdown
# Active Memory

## Current Goals

- Add confirmed goals here.

## Active Projects

- Add active projects and their status here.

## Important Decisions

- Record confirmed decisions and the reason for each decision.

## Current Constraints

- Record important budget, time, staffing, or operational constraints.

## Recent Material Changes

- Record new clients, strategic changes, product changes, or other substantial updates.

## Open Questions

- Record unresolved questions that affect future work.
```

Do not fill sections with guesses. Empty sections are better than incorrect context.

### Connect the folder to Cowork

Select the `AI-Brain` folder in Cowork, then run this initialization prompt:

```text
Review the selected AI-Brain folder.

First, read instructions.md. Then inspect context.md and memory.md. Do not edit anything yet.

Report:
1. Your understanding of my current context
2. Any contradictions or ambiguous facts
3. Information that appears outdated
4. Files that are unnecessarily long or duplicated
5. Changes you recommend before this becomes my working memory system

Wait for my approval before editing any file.
```

After approval, ask Claude to make the corrections and list every changed file.

## 4. Keep Core Memory Small

A bloated memory file can add irrelevant context, slow responses, and consume more tokens. Keep only widely useful information in `memory.md`. Store detailed material in relevant subfolders.

Use this maintenance prompt periodically:

```text
Audit memory.md for quality and relevance.

Identify:
1. Duplicate information
2. Outdated facts
3. Details that belong in a business or project folder
4. Statements that are vague or unverified
5. Information that is no longer useful for recurring decisions

Propose a shorter version that preserves all material facts. Do not edit the file until I approve the proposed changes.
```

Back up the entire folder periodically. If you move the memory system to a cloud service later, protect the account with two factor authentication.

## 5. Turn a Repeatable Process into a Claude Skill

Memory tells Claude who you are. A skill tells Claude how you perform a specific task.

Choose a task that is:

* Repeated regularly
* Governed by recognizable steps
* Improved by examples or feedback
* Easy to review before its output is used

Good starting examples include video scripting, competitor research, content ideation, copywriting, data entry, or preparing a recurring report.

### Capture the process

If screen recording is available from the plus button beside the chat, record yourself completing the task. Explain aloud:

* What you are doing
* Why each step matters
* What information you inspect
* How you make decisions
* What separates a good result from a bad one
* Which exceptions require human judgment

If recording is unavailable, describe the process verbally or provide representative documents and examples.

### Create the skill

Where supported, start with `/skill creator`. Then use this prompt:

```text
/skill creator

Create a reusable skill for [TASK NAME].

Your job is to learn the exact process I use, not to replace missing details with a generic workflow.

First, interview me about:
1. The goal of the task
2. Required inputs
3. The exact sequence of steps
4. Decision criteria at each step
5. Tools, files, and connectors used
6. Quality standards
7. Common failure modes
8. Exceptions that require human review
9. The required output format
10. Examples of strong and weak results

After the interview, create concise skill instructions containing:

- Purpose
- Required inputs
- Ordered procedure
- Decision rules
- Output specification
- Quality checklist
- Stop conditions
- Feedback and update procedure

Do not claim the skill is complete until all critical information has been confirmed.
```

Store the resulting instructions in the skill folder. For example:

```text
AI-Brain/skills/video-research/skill.md
```

### Improve the skill after each use

Do not simply tell Claude that the result was bad. Convert feedback into a durable rule.

```text
Review the output from the [SKILL NAME] skill against my feedback below.

Feedback:
[PASTE SPECIFIC FEEDBACK]

Determine:
1. Which skill instruction caused or allowed the problem
2. Whether this was a one time exception or a reusable lesson
3. The smallest change that would prevent the problem in future runs

Propose an update to the skill instructions. Show the exact text to add, change, or remove. Wait for approval before editing the skill file.
```

## 6. Combine a Goal, Skill, and Recurring Trigger

A recurring workflow needs three parts:

1. **Goal:** The result Claude should optimize for.
2. **Skill:** The documented method Claude should follow.
3. **Trigger:** A loop or schedule that determines when the task runs.

Use loops for shorter recurring intervals where the feature is supported. Use schedules for daily or weekly tasks.

### Example: recurring video research

```text
/goal
Maintain a list of the five strongest video ideas based on topics currently performing well on YouTube. Prioritize ideas that match my audience, business goals, and content standards.

/loop every 24 hours
Search for top ranked videos using these terms:
- Claude
- AI automation
- AI agents

Use my video research skill and its decision framework.

Update the designated spreadsheet with:
1. Proposed title
2. Core idea
3. Evidence of current interest
4. Relevant competing videos
5. Why the idea fits my audience
6. Confidence rating

Order the list from highest to lowest conviction. Do not remove previous ideas without recording why they were replaced.
```

### Example: scheduled portfolio briefing

This example depends on access to an appropriate financial data connector.

```text
/goal
Give me a concise briefing containing only market information materially relevant to my portfolio and current investment decisions.

On the configured morning schedule:
1. Use the connected financial data source.
2. Review overnight market movements, relevant earnings information, and material company updates.
3. Compare findings with the portfolio context in my memory system.
4. Separate confirmed facts from interpretation.
5. Explain why each included item matters to my holdings.
6. State when no material update is available.

Do not provide generic market news merely to fill space.
```

Review early runs manually. Recurring automation should not be trusted until its inputs, outputs, and file changes behave consistently.

## 7. Design a Multi Agent Workflow for Complex Tasks

For a larger process, map the work before asking Claude to orchestrate it. Break the process into stages, identify dependencies, and mark every point that requires human approval.

Use this table as a graph engineering template:

| Stage | Input | Task | Suggested worker | Output | Human approval |
|---|---|---|---|---|---|
| 1 | Business goals and audience | Generate ideas | Strong reasoning model | Ranked idea list | Yes |
| 2 | Approved idea | Research sources and examples | Research agent with connectors | Research brief | Optional |
| 3 | Research brief and style skill | Draft content | Writing agent | First draft | Yes |
| 4 | Draft and quality rules | Check structure and accuracy | Review agent | Audit and revisions | Yes |
| 5 | Approved asset | Prepare publishing materials | Lower cost model for simple formatting | Final package | Yes |

Model names change over time, so assign work by capability rather than permanently tying every step to a specific model:

* Use the strongest available reasoning model as the orchestrator.
* Use capable general models for drafting and analysis.
* Use faster or lower cost models for simple formatting, extraction, and repetitive checks.
* Keep human approval at consequential or subjective decision points.

Copy this orchestration prompt:

```text
Act as the orchestrator for the workflow below.

Goal:
[DESCRIBE THE FINAL OUTCOME]

Available context:
[LIST RELEVANT MEMORY FILES, SKILLS, CONNECTORS, AND PROJECT FILES]

Workflow stages:
[PASTE THE COMPLETED WORKFLOW TABLE]

For each stage:
1. Confirm the required input is available.
2. Assign the work to an appropriate agent or model based on complexity.
3. Require a structured output that the next stage can consume.
4. Check the output against the relevant skill and quality criteria.
5. Stop at every stage marked for human approval.
6. Record errors, unresolved questions, and assumptions.
7. Do not proceed when a required input is missing.

Before starting, return the execution plan, model allocation, expected outputs, and approval points. Wait for my confirmation.
```

## Final Implementation Checklist

Before relying on the system, verify that:

* `context.md` contains only confirmed, stable facts.
* `instructions.md` defines response style, context loading, memory updates, and file change behavior.
* `memory.md` is concise and contains current material information.
* Detailed business information is stored in separate folders.
* Claude reads those detailed folders only when relevant.
* Every connector has been tested with a narrow request.
* At least one repeatable process has been converted into a documented skill.
* Skill feedback is converted into reusable instruction updates.
* Loops or schedules have a clear goal, interval, output location, and review process.
* Complex workflows include explicit human approval points.
* The local memory folder has a current backup.

The highest leverage improvement is not writing longer prompts. It is giving Claude accurate context, a documented method, access to the right information, and a controlled mechanism for repeating the work.