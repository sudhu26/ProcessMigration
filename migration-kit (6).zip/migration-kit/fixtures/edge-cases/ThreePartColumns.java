package com.risk.edge;

/** Three-part column refs regression (R7-G7, new assertion 46):
 *  schema.table.col resolves through alias_map on the full name,
 *  then the short table name, and records only the column; a
 *  genuinely unknown prefix stays unattributed.
 *  Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (ThreePartColumns.java record):
 *  tables_read ['SCHEMA1.T1', 'T1'],
 *  table_columns {'SCHEMA1.T1': {'read': ['A', 'B'], 'write': []}},
 *  columns_unattributed ['FOO.BAR.A'] */
public class ThreePartColumns {

    public void run(java.sql.Statement st) throws Exception {
        String threePart =
                "SELECT schema1.t1.a, schema1.t1.b FROM schema1.t1";
        st.executeQuery(threePart);

        String threePartAlias =
                "SELECT s1.t1.a FROM schema1.t1 s1";
        st.executeQuery(threePartAlias);

        String unknownPrefix =
                "SELECT foo.bar.a FROM t1";
        st.executeQuery(unknownPrefix);
    }
}
