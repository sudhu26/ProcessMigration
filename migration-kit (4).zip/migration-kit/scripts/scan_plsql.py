#!/usr/bin/env python3
"""Scan Oracle SQL / PL/SQL sources for object definitions and references.
Stdlib only.

Usage: scan_plsql.py --root <repo_root> --repo <repo_name> --exts ".sql,.pks,.pkb"
                      --out <out.json>
"""
import argparse, json, os, re

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ignore_lists import load_ignore, split_kept_ignored  # noqa: E402

DEF_RE = re.compile(
    r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:FORCE\s+|EDITIONABLE\s+|NONEDITIONABLE\s+)?'
    r'(TABLE|VIEW|MATERIALIZED\s+VIEW|PACKAGE\s+BODY|PACKAGE|PROCEDURE|FUNCTION|'
    r'TRIGGER|SEQUENCE|SYNONYM|TYPE|INDEX)\s+'
    r'(?:IF\s+NOT\s+EXISTS\s+)?"?([A-Za-z_][\w$]*"?\.)?"?([A-Za-z_][\w$]*)"?',
    re.IGNORECASE)

REF_PATTERNS = [
    (re.compile(r'\bFROM\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
    (re.compile(r'\bJOIN\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
    (re.compile(r'\bINSERT\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
    (re.compile(r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET', re.IGNORECASE), 'write'),
    (re.compile(r'\bMERGE\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
    (re.compile(r'\bTABLE\s*\(\s*([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
]
CALL_RE = re.compile(r'\b([A-Za-z_][\w$]*)\.([A-Za-z_][\w$]*)\s*\(')
EXEC_RE = re.compile(r'^\s*(?:EXEC|EXECUTE)\s+([A-Za-z_][\w$.]+)', re.IGNORECASE | re.MULTILINE)

RISKY = {
    'execute_immediate': re.compile(r'\bEXECUTE\s+IMMEDIATE\b', re.IGNORECASE),
    'dbms': re.compile(r'\bDBMS_[\w$]+\b', re.IGNORECASE),
    'utl': re.compile(r'\bUTL_[\w$]+\b', re.IGNORECASE),
    'autonomous_txn': re.compile(r'AUTONOMOUS_TRANSACTION', re.IGNORECASE),
    'bulk_collect': re.compile(r'\bBULK\s+COLLECT\b', re.IGNORECASE),
    'forall': re.compile(r'\bFORALL\b', re.IGNORECASE),
    'goto': re.compile(r'\bGOTO\b', re.IGNORECASE),
}

LINE_COMMENT = re.compile(r'--.*?$', re.MULTILINE)
BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
STRING_RE = re.compile(r"'(?:''|[^'])*'")


# --- column extraction (best-effort heuristic; mirrored in scan_java.py) ---
_SQL_KW = {'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'AS', 'ON', 'JOIN', 'LEFT',
           'RIGHT', 'INNER', 'OUTER', 'FULL', 'CROSS', 'GROUP', 'ORDER', 'BY',
           'HAVING', 'INTO', 'VALUES', 'SET', 'INSERT', 'UPDATE', 'DELETE',
           'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT', 'UNION', 'ALL',
           'NOT', 'NULL', 'IS', 'IN', 'LIKE', 'BETWEEN', 'EXISTS', 'WITH',
           'MERGE', 'DUAL', 'TABLE', 'SYSDATE', 'SYSTIMESTAMP',
           'CURRENT_DATE', 'ROWNUM'}
_DDL_SKIP = {'CONSTRAINT', 'PRIMARY', 'FOREIGN', 'UNIQUE', 'CHECK', 'KEY'}


def split_top_commas(s):
    parts, depth, cur = [], 0, ''
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        if ch == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return parts


def _col_refs(item):
    out = []
    for m in re.finditer(r'([A-Za-z_][\w$]*)(?:\.([A-Za-z_][\w$]*))?', item):
        a, b = m.group(1), m.group(2)
        if m.end() < len(item) and item[m.end()] == '(':
            continue
        if a.upper() in _SQL_KW:
            continue
        if b:
            if b.upper() in _SQL_KW:
                continue
            out.append((a.upper(), b.upper()))
        else:
            out.append((None, a.upper()))
    return out


def _top_level_from(sql):
    m = re.search(r'\bSELECT\b', sql, re.I)
    if not m:
        return None
    depth, i, from_at = 0, m.end(), None
    while i < len(sql):
        ch = sql[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and sql[i:i + 4].upper() == 'FROM' and \
                (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == '_')) and \
                (i + 4 >= len(sql) or not (sql[i + 4].isalnum() or sql[i + 4] == '_')):
            from_at = i
            break
        i += 1
    if from_at is None:
        return None
    rest = sql[from_at + 4:]
    end = len(rest)
    for kw in ('WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'MINUS', 'INTERSECT'):
        mm = re.search(r'\b' + kw + r'\b', rest, re.I)
        if mm:
            end = min(end, mm.start())
    return sql[m.end():from_at], sql[from_at:from_at + 4 + end]


def _subqueries(sql):
    """Inner SELECT statements inside parentheses (derived tables)."""
    out = []
    for m in re.finditer(r'\(\s*SELECT\b', sql, re.I):
        depth, i = 0, m.start()
        while i < len(sql):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
                if depth == 0:
                    out.append(sql[m.start() + 1:i])
                    break
            i += 1
    return out


def _from_tables(from_clause):
    out = []
    for m in re.finditer(
            r'\b(?:FROM|JOIN)\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)'
            r'\s*(?:AS\s+)?([A-Za-z_][\w$]*)?', from_clause, re.I):
        alias = m.group(2)
        if alias and alias.upper() in _SQL_KW:
            alias = None
        out.append((m.group(1).upper(), alias.upper() if alias else None))
    return out


def extract_table_columns(sql):
    """Best-effort per-table column usage from one SQL statement."""
    from collections import defaultdict
    cols = defaultdict(lambda: {'read': set(), 'write': set()})
    unatt = set()
    one = ' '.join(sql.split())
    for m in re.finditer(
            r'\bINSERT\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)'
            r'\s*\(([^)]*)\)', one, re.I):
        for c in m.group(2).split(','):
            c = c.strip().strip('"').upper()
            if c:
                cols[m.group(1).upper()]['write'].add(c)
    for m in re.finditer(
            r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET\s+'
            r'(.*?)(?:\bWHERE\b|;|$)', one, re.I | re.S):
        for part in split_top_commas(m.group(2)):
            cm = re.match(r'\s*"?([A-Za-z_][\w$]*)"?\s*=', part)
            if cm:
                cols[m.group(1).upper()]['write'].add(cm.group(1).upper())
    parsed = _top_level_from(one)
    if parsed:
        select_list, from_clause = parsed
        # PL/SQL SELECT ... INTO var: the target is not a column
        select_list = re.sub(r'\bINTO\s+[A-Za-z_][\w$]*', '', select_list,
                             flags=re.I)
        tables = _from_tables(from_clause)
        alias_map = {}
        for t, al in tables:
            alias_map[t] = t
            if al:
                alias_map[al] = t
        single = tables[0][0] if len(tables) == 1 else None
        for item in split_top_commas(select_list):
            item = re.sub(r'\bAS\s+[A-Za-z_][\w$]*', '', item,
                          flags=re.I).strip()
            # implicit alias: "SUM(x) E" / "BOOK b" -> "SUM(x)" / "BOOK"
            m_alias = re.match(r'^(.*\))\s+[A-Za-z_][\w$]*$', item)
            if m_alias:
                item = m_alias.group(1)
            else:
                m_alias2 = re.match(
                    r'^([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)?)\s+'
                    r'[A-Za-z_][\w$]*$', item)
                if m_alias2:
                    item = m_alias2.group(1)
            if item == '*':
                if single:
                    cols[single]['read'].add('*')
                continue
            for prefix, name in _col_refs(item):
                if prefix:
                    t = alias_map.get(prefix)
                    if t:
                        cols[t]['read'].add(name)
                    else:
                        unatt.add(f'{prefix}.{name}')
                elif single:
                    cols[single]['read'].add(name)
                else:
                    unatt.add(name)
    # recurse into derived-table subqueries (SELECT * FROM (SELECT ...))
    for sub in _subqueries(one):
        tc2, un2 = extract_table_columns(sub)
        for t, kinds in tc2.items():
            cols[t]['read'].update(kinds['read'])
            cols[t]['write'].update(kinds['write'])
        unatt.update(un2)
    return cols, unatt


def ddl_columns(code):
    """{TABLE: [columns]} from CREATE TABLE column lists."""
    out = {}
    for m in re.finditer(
            r'\bCREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+'
            r'([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s*\(', code, re.I):
        start = m.end() - 1
        depth, i = 0, start
        while i < len(code):
            if code[i] == '(':
                depth += 1
            elif code[i] == ')':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        cols = []
        for part in split_top_commas(code[start + 1:i]):
            tok = part.strip().split()
            if not tok:
                continue
            first = tok[0].strip('"').upper()
            if first in _DDL_SKIP:
                continue
            cols.append(first)
        out[m.group(1).upper()] = cols
    return out


def analyze_file(path, repo, ignore=None):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except OSError:
        return None
    code = BLOCK_COMMENT.sub('', LINE_COMMENT.sub('', text))
    code_nolit = STRING_RE.sub("''", code)

    defs = []
    for m in DEF_RE.finditer(code_nolit):
        kind = re.sub(r'\s+', ' ', m.group(1)).upper()
        schema = (m.group(2) or '').strip('".')
        name = m.group(3).strip('"')
        full = f'{schema}.{name}'.upper() if schema else name.upper()
        defs.append({'kind': kind, 'name': full})

    reads, writes = set(), set()
    for pat, kind in REF_PATTERNS:
        for m in pat.finditer(code_nolit):
            (writes if kind == 'write' else reads).add(m.group(1).upper())
    refs = reads | writes
    calls = set()
    for m in CALL_RE.finditer(code_nolit):
        calls.add(f'{m.group(1)}.{m.group(2)}'.upper())
    calls.discard('EXECUTE.IMMEDIATE')
    calls = {c for c in calls if not c.endswith('.IMMEDIATE')}
    for m in EXEC_RE.finditer(code_nolit):
        name = m.group(1).upper()
        if name != 'IMMEDIATE':  # EXECUTE IMMEDIATE tracked in risky_constructs
            calls.add(name)

    risky = {k: len(p.findall(code_nolit)) for k, p in RISKY.items()}
    risky = {k: v for k, v in risky.items() if v}

    if ignore:
        reads, ignored_reads = split_kept_ignored(reads, ignore.ignore_object)
        writes, ignored_writes = split_kept_ignored(writes, ignore.ignore_object)
        calls, ignored_calls = split_kept_ignored(calls, ignore.ignore_object)
        # DBMS_/UTL_ risky counts only count calls that are NOT ignored
        for key, pat in (('dbms', RISKY['dbms']), ('utl', RISKY['utl'])):
            kept = [m.group(0) for m in pat.finditer(code_nolit)
                    if not ignore.ignore_object(m.group(0).upper())]
            if kept:
                risky[key] = len(kept)
            else:
                risky.pop(key, None)
    else:
        ignored_reads = ignored_writes = ignored_calls = []
    refs = set(reads) | set(writes)  # after ignore filtering, when applied

    ddl = ddl_columns(code_nolit)
    table_columns = {}
    unattributed = set()
    for stmt in code_nolit.split(';'):
        tc, un = extract_table_columns(stmt)
        for t, kinds in tc.items():
            entry = table_columns.setdefault(t, {'read': set(), 'write': set()})
            entry['read'].update(kinds['read'])
            entry['write'].update(kinds['write'])
        unattributed.update(un)
    if ignore:
        ddl = {t: c for t, c in ddl.items() if not ignore.ignore_object(t)}
        table_columns = {t: v for t, v in table_columns.items()
                         if not ignore.ignore_object(t)}

    loc = sum(1 for ln in code.splitlines() if ln.strip())
    return {
        'path': path, 'repo': repo,
        'definitions': defs, 'references': sorted(refs),
        'reads': sorted(reads), 'writes': sorted(writes),
        'ignored_tables': sorted(set(ignored_reads) | set(ignored_writes)),
        'ignored_calls': ignored_calls,
        'ddl_columns': ddl,
        'table_columns': {t: {'read': sorted(v['read']), 'write': sorted(v['write'])}
                          for t, v in sorted(table_columns.items())},
        'columns_unattributed': sorted(unattributed),
        'calls': sorted(calls),
        'risky_constructs': risky,
        'metrics': {'loc': loc, 'def_count': len(defs)},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--repo', required=True)
    ap.add_argument('--exts', required=True)
    ap.add_argument('--ignore', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    ignore = load_ignore(a.ignore)
    exts = tuple(e.lower() for e in a.exts.split(','))
    records = []
    for dirpath, _, filenames in os.walk(a.root):
        for fn in filenames:
            if fn.lower().endswith(exts):
                rec = analyze_file(os.path.join(dirpath, fn), a.repo, ignore)
                if rec:
                    records.append(rec)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=1)
    print(f'scanned {len(records)} plsql files -> {a.out}')


if __name__ == '__main__':
    main()
