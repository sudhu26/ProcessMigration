-- Qualified-star regression (R5-G11): prefix.* is '*' for that
-- prefix's table, never a bare column named after the table. Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (qualified_star.sql record):
-- reads ['T1', 'T2'],
-- table_columns {'T1': {'read': ['*'], 'write': []},
--                 'T2': {'read': ['C'], 'write': []}},
-- columns_unattributed [].
SELECT t1.* FROM t1;
SELECT t1.* FROM t1 JOIN t2 ON t1.id = t2.id;
SELECT t1.*, t2.c FROM t1 JOIN t2 ON t1.id = t2.id;
