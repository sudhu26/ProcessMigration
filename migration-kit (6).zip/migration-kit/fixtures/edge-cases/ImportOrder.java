package com.risk.edge;

import zebra.Z;
import alpha.A;
import oracle.jdbc.OracleDriver;
import middle.M;

/** Import-order regression (R4-G3): imports are NOT alphabetical in
 *  source order. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases --ignore fixtures/ignore.json
 *  Expected (ImportOrder.java record): imports ['zebra.Z', 'alpha.A',
 *  'middle.M'] (source order, not sorted),
 *  ignored_imports ['oracle.jdbc.OracleDriver']. */
public class ImportOrder {
}
