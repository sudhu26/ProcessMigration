# Build a Self Verifying Claude Workflow

Replace bloated instructions and prompt micromanagement with clear goals, workflow graphs, verification loops, and selective automation.

## What you will achieve

You will convert one recurring process into a documented Claude workflow that knows the required result, checks its own work, stops at defined boundaries, and escalates decisions that need human judgment.

## Who this is for

Claude and Claude Code users who want to automate recurring research, content, operations, or development work.

**Difficulty:** Intermediate

## Short tutorial

Replace bloated instructions and prompt micromanagement with clear goals, workflow graphs, verification loops, and selective automation.

### Guide: Build a Lean, Self Verifying Claude Workflow

**Time:** 30 to 45 minutes

## What You Will Build

This tutorial shows you how to turn one recurring task into a lean, repeatable Claude workflow. Instead of prescribing every action, you will provide the business context, desired outcome, completion criteria, boundaries, and verification tests.

The implementation has five parts:

1. Remove outdated instructions through ablation.
2. Define the result rather than micromanaging the method.
3. Convert your process into a workflow graph.
4. Add self verification and stopping conditions.
5. Schedule or repeat the workflow only after it works manually.

Start with one process that already happens regularly, such as competitor research, lead qualification, content research, file organization, deal flow management, or reporting.

## 1. Choose One Suitable Workflow

A strong first workflow has:

* A clear input and output.
* Rules that can be written down.
* A result that can be checked.
* Mostly digital actions.
* A recurring cadence.
* Limited consequences if a run fails.

Avoid beginning with an entire department or a large collection of agents. Choose one useful process that currently consumes time.

### Example workflow

This tutorial will use competitor video monitoring as the example:

* Scan a defined set of competitor channels.
* identify new uploads.
* Record titles, views, views per day, and topics.
* Compare performance with each channel's median.
* Flag videos performing at three times the median.
* Explain briefly why the title or thumbnail may be working.
* Save the results to `niche-tracker.md`.

## 2. Run an Ablation Review

Ablation means removing existing instructions, testing the model with less guidance, and adding back only the rules that correct observed failures.

Do not automatically delete useful business context. Focus first on behavioral instructions that dictate how Claude must think, speak, or approach every task.

### What to retain

Keep these three categories:

1. **Context:** Who you are, what the business does, and relevant constraints.
2. **Goals:** What the workflow should accomplish.
3. **Completion criteria:** What must be true before the work is done.

### What to question

Review instructions such as:

* Always reason in a particular sequence.
* Always adopt a named persona.
* Always use a long response format.
* Follow a detailed method for every task.
* Repeat information already apparent from the task.
* Apply rules created to fix problems from an older model.

Back up your current instruction files before changing them. Then use this prompt to produce a lean candidate configuration.

```text
Review the Claude instructions, memory, skills, and workflow rules I provide below.

Your job is to perform an ablation review. Produce the smallest useful instruction set for how I currently use Claude.

Before rewriting anything, ask me concise questions about:
1. The tasks I perform most often.
2. The business context Claude genuinely needs.
3. The goals that apply across those tasks.
4. The mistakes Claude repeatedly makes.
5. The output requirements that are mandatory.
6. The decisions that require human approval.

Then classify every existing instruction as one of the following:

KEEP: Essential context, constraint, or completion requirement.
REMOVE: Redundant, outdated, overly prescriptive, or unnecessary behavioral guidance.
TEST: Possibly useful, but it should be removed temporarily and restored only if a failure appears.
TASK SPECIFIC: Useful only for a particular workflow and should not remain in global instructions.

Return:
1. A table containing each current instruction, its classification, and your reason.
2. A minimal global instruction file containing only essential context and universal constraints.
3. A separate list of task specific instructions and the workflows where they belong.
4. A test plan for comparing the current setup with the lean version.
5. A list of rules that should be restored only if a specific failure occurs.

Do not preserve an instruction merely because it already exists. Prefer subtraction unless the instruction prevents an observed failure or communicates essential context.

Here are my current instructions:

[PASTE CURRENT INSTRUCTIONS, MEMORY, SKILLS, OR CLAUDE.md CONTENT]
```

### Compare the configurations

Run the same representative task twice:

* Once with the current instructions.
* Once with the lean candidate.

Compare the results using the same criteria:

| Criterion | What to inspect |
|---|---|
| Accuracy | Are statements and calculations correct? |
| Completeness | Does the result satisfy every required condition? |
| Relevance | Is unnecessary content reduced? |
| Autonomy | Did Claude proceed without avoidable clarification? |
| Consistency | Does the output follow the required structure? |
| Efficiency | Did unnecessary instructions or steps disappear? |

Add a rule back only when you can connect it to a repeated, specific failure.

## 3. Replace Procedural Prompts With Output Specifications

Older prompts often describe every step Claude should take. The alternative is to specify the destination, evidence, constraints, and definition of done.

Use this structure:

```text
CONTEXT
[Relevant information about the business, files, tools, or audience]

GOAL
[The final result to produce]

REQUIRED OUTPUT
[Files, fields, sections, artifacts, or actions required]

SUCCESS CRITERIA
[Objective tests the result must pass]

BOUNDARIES
[Actions that are prohibited or require approval]

DEFINITION OF DONE
[Conditions that must all be true before stopping]
```

### Weak procedural prompt

```text
Open each channel, inspect the videos one at a time, copy each title, calculate views per day, place the results in a table, calculate the median, and then look for videos above the median.
```

This constrains the method even if Claude can find a more effective route.

### Strong output specification

```text
CONTEXT
We monitor competitor videos to identify unusual performance and useful content patterns. The tracker is stored in niche-tracker.md.

GOAL
Update the tracker with new competitor uploads and identify meaningful performance outliers.

REQUIRED OUTPUT
For every new upload, record:
1. Channel.
2. Video title.
3. Publication date.
4. Current views.
5. Views per day.
6. Topic.
7. Performance relative to the channel median.

Flag any video performing at three times or more than the channel median. For each flagged video, add one concise line explaining why its title or thumbnail may be effective.

SUCCESS CRITERIA
1. Existing tracker entries are not duplicated.
2. Every required field is populated or explicitly marked unavailable.
3. Calculations are internally consistent.
4. Outliers use the same threshold across the tracker.
5. The tracker remains valid Markdown.

BOUNDARIES
Do not delete historical entries.
Do not modify files outside this workflow.
Do not publish, message, purchase, install, or delete anything without approval.
If required source data is unavailable, report the gap rather than inventing it.

DEFINITION OF DONE
The tracker contains all discovered new uploads, calculations have been checked, qualifying outliers have been flagged, and any unresolved data gaps have been reported.
```

Notice that the prompt defines what success looks like without prescribing every internal action.

## 4. Extract Your Process Into a Workflow Graph

Some business processes feel intuitive because their rules exist only in your head. Graph engineering converts that intuition into explicit stages, decision points, responsibilities, and verification gates.

For each stage, document:

* Required inputs.
* Intended output.
* Decision rule.
* Responsible actor.
* Verification test.
* Next stage.

The actor can be Claude, another available model or agent, or a human.

### Workflow extraction prompt

Use this prompt while describing how you currently perform the task:

```text
Help me convert the recurring process below into an operational workflow graph.

First, interview me until you understand:
1. What triggers the process.
2. What information enters the process.
3. The final result.
4. The decisions I make from experience or intuition.
5. The rules behind those decisions.
6. The tools, files, and systems involved.
7. Common exceptions and failure conditions.
8. Which actions require human judgment or approval.

Then produce two artifacts.

ARTIFACT 1: MARKDOWN WORKFLOW SPECIFICATION
For every stage, include:
1. Stage name.
2. Purpose.
3. Required inputs.
4. Actions or decisions.
5. Responsible actor.
6. Expected output.
7. Verification test.
8. Failure response.
9. Next stage.

ARTIFACT 2: VISUAL HTML WORKFLOW
Create one self contained HTML file that displays the process as a readable graph. Show:
1. Start and completion points.
2. Processing stages.
3. Decision branches.
4. Claude or agent actions.
5. Human approval gates.
6. Verification steps.
7. Failure and retry paths.

Use clear labels and keep the HTML easy to edit.

Do not assume that every stage should be automated. Explicitly identify where human taste, authorization, or judgment remains important.

Process to map:
[DESCRIBE THE CURRENT PROCESS]
```

### Example graph specification

| Stage | Actor | Output | Verification | Next stage |
|---|---|---|---|---|
| Detect uploads | Claude | List of new videos | No duplicate URLs or titles | Collect metrics |
| Collect metrics | Claude | Views, date, views per day | Required fields present | Compare performance |
| Compare performance | Claude | Ratio to channel median | Formula checked | Classify outlier |
| Classify outlier | Claude | Standard or outlier label | Three times threshold applied | Analyze creative |
| Analyze creative | Claude | One line explanation | Explanation references title or thumbnail | Update tracker |
| Review exceptions | Human | Approved correction or decision | Missing data resolved | Complete run |

The visual HTML is primarily for human understanding. The Markdown specification provides a compact artifact that Claude can read during execution.

## 5. Add a Verification Loop

A loop should not mean repeating blindly. It should run a controlled cycle:

1. Attempt the task.
2. Compare the result with the success criteria.
3. Identify failures or missing evidence.
4. Correct the result.
5. Verify again.
6. Stop when the definition of done passes or a boundary is reached.

### Self verifying execution prompt

```text
Execute the workflow described below using a self verification loop.

GOAL
[INSERT FINAL OUTCOME]

WORKFLOW
[PASTE OR REFERENCE THE WORKFLOW SPECIFICATION]

VERIFICATION LOOP
1. Produce the required result.
2. Test it against every success criterion.
3. List any failed criteria internally and correct the work.
4. Repeat verification until all criteria pass or a stopping condition is reached.
5. Do not claim completion unless every criterion has passed.

STOPPING CONDITIONS
Stop and report the issue if:
1. Required information cannot be accessed.
2. Two correction attempts fail for the same reason.
3. Instructions conflict.
4. An action requires human approval.
5. Continuing could modify, delete, publish, purchase, install, or send something outside the approved scope.

FINAL RESPONSE
Return:
1. Completion status.
2. Output produced or files updated.
3. Verification checks performed.
4. Exceptions, missing data, or unresolved risks.
5. Any human decision required.

Definition of done:
[INSERT OBJECTIVE COMPLETION CONDITIONS]
```

### Claude Code goal and loop example

The transcript describes using `/goal` to define the result and `/loop` to define the interval. Where these commands are available in your setup, the competitor monitoring task can be expressed as:

```text
/goal Scan the specified competitor channels for new uploads. Log the channel, title, publication date, views, views per day, and topic in niche-tracker.md. Flag any video performing at three times or more than the channel's median. Add one concise line explaining why each outlier's title or thumbnail may work. Do not duplicate existing entries or delete historical data. Done means the tracker is updated, calculations are verified, outliers are flagged, and unresolved data gaps are reported. Stop after eight runs.
```

```text
/loop [INSERT DESIRED INTERVAL]
```

The interval should reflect how frequently fresh information is useful. The goal should also contain a maximum run count or another clear stopping condition.

## 6. Place Human Gates at Consequential Decisions

Autonomy does not remove the need for direction, taste, or authorization. Mark actions that Claude can prepare but should not complete without approval.

Use human gates for actions such as:

* Sending outreach or publishing content.
* Deleting or overwriting important files.
* Installing software.
* Making purchases or financial changes.
* Approving a proposal or contract.
* Acting on uncertain research.
* Changing a production system.

Add this block to workflows with consequential actions:

```text
HUMAN APPROVAL GATES
You may research, analyze, draft, organize, calculate, and prepare recommendations autonomously.

Pause before any action that:
1. Sends or publishes information externally.
2. Deletes or irreversibly overwrites data.
3. Installs software or changes system configuration.
4. Creates a financial, legal, or contractual commitment.
5. Changes a production workflow.

At an approval gate, return:
1. The proposed action.
2. Why it is needed.
3. The expected effect.
4. The main risk.
5. The exact approval requested.
```

## 7. Test Before Scheduling

Run the workflow manually before placing it on a recurring schedule. The purpose is to discover where your specification is incomplete.

### Test cases

Use at least three types of input:

1. **Normal case:** Complete and expected information.
2. **Edge case:** Missing, duplicated, ambiguous, or unusual information.
3. **Failure case:** An unavailable source, invalid file, or blocked action.

### Readiness checklist

A workflow is ready for repetition when:

* The goal has one unambiguous final result.
* Every required output is named.
* Completion can be tested objectively.
* Duplicate handling is defined.
* Missing information is reported rather than invented.
* File and system boundaries are explicit.
* Human approval gates are visible.
* Retry limits and stopping conditions exist.
* A failed run produces a useful report.
* The workflow succeeds without unnecessary procedural instructions.

If Claude fails repeatedly in one specific way, add the smallest rule that prevents that failure. Do not rebuild a large instruction file around one exception.

## 8. Store the Workflow as Reusable Files

Maintain one record for each process. The transcript suggests keeping both a Markdown specification and an HTML visualization.

A simple library can use this structure:

```text
workflows/
  competitor-monitoring/
    workflow.md
    workflow.html
    goal.md
    test-cases.md
  lead-qualification/
    workflow.md
    workflow.html
    goal.md
    test-cases.md
```

You can also maintain an index in a spreadsheet or workspace database with these fields:

| Field | Purpose |
|---|---|
| Workflow name | Human readable process name |
| Trigger | What starts the process |
| Cadence | Manual or recurring interval |
| Input sources | Files, pages, or systems used |
| Output | Artifact or action produced |
| Responsible actor | Claude, another agent, or human |
| Human gate | Approval point, if any |
| Specification file | Location of the Markdown graph |
| Visual file | Location of the HTML graph |
| Last revised | Most recent process update |

Update the workflow files whenever the underlying business process changes. This keeps the automation aligned with the current process rather than preserving outdated instructions.

## Final Implementation Pattern

For each new workflow, use the same sequence:

```text
Lean context
    ↓
Clear goal
    ↓
Required output
    ↓
Workflow graph
    ↓
Success criteria
    ↓
Verification loop
    ↓
Human approval gates
    ↓
Stopping conditions
    ↓
Manual test
    ↓
Recurring execution
```

The central shift is simple: give Claude less behavioral baggage, a clearer destination, objective verification criteria, and explicit boundaries. Let it determine the method, then add instructions only when observed failures prove they are necessary.