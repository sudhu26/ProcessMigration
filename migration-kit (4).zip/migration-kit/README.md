# Migration Analysis Kit

Machine-built inventory of the Java + Oracle estate: process dependency map, code
dependency map, database dependency map, and a DB-heavy / Java-heavy classification
per process. Built for the Risk_DB / Risk_DL / CoreWM migration to Azure Databricks.

## How it works

Three steps, in order:

1. **Deterministic scan** (no agent tokens spent on reading code). The Python
   scripts in `scripts/` walk the three repos and the Autosys export and
   extract: JDBC call sites, SQL string literals (including `+`-concatenated
   ones), stored-procedure calls, Oracle dialect features, Java imports, PL/SQL
   object definitions and references, shell/python/perl script invocations, and
   job→command→code links (following wrapper scripts through to the Java they
   invoke). Column usage is extracted too — `CREATE TABLE` column lists are
   authoritative, and `INSERT (cols)` / `UPDATE SET cols` / `SELECT` lists give
   per-table read/write columns (best-effort: see limitations). `build_graph.py`
   merges this into a dependency graph plus one evidence bundle per process;
   `classify.py` adds a first-pass DB-heavy / Java-heavy label.
   `build_graph.py` also infers **likely data-flow dependencies**: when unit A
   writes a table that unit B reads (including writes/reads that happen
   *transitively* inside a called PL/SQL procedure — recorded as
   `write_via_proc` / `read_via_proc`), it adds a `likely_depends_on` edge
   (B → A, with the shared tables in `via`) plus per-unit
   `likely_depends_on` / `likely_required_by` lists. This is a heuristic
   stand-in for the scheduler DAG when scheduler data is thin — agents
   validate the edges during review, and humans confirm before wave planning.
   Run by Muse directly — ask in chat, or run the commands yourself (see below).
2. **Agent review** (the expensive part). The saved workflow
   **`oracle-migration-review`** fans out small agents over batches of processes.
   Each agent confirms the classification, writes a 2–3 line summary, and flags
   ambiguities — following `prompts/classify_process.md`. Every unit writes its
   own checkpoint file (`state/units/<unit_id>.json`), so a re-run skips finished
   work automatically.
3. **Reports.** The per-unit results are compiled into the final catalogs and
   reports (ask Muse, or follow the report prompt pattern yourself).

Phase 1 does the heavy lifting so Phase 2 stays small: agents review evidence
bundles instead of reading 15 years of code from scratch.

## Prerequisites

- The three repos checked out locally (read-only access is enough).
- Optionally, a job scheduler export: a Control-M XML export, an Autosys CSV
  (columns `JOB_ID,JOB_NAME,JOB_DESCRIPTION,COMMAND,CONDITION,PARENT_JOB_NAME,
  TASK_NAME,PARAMETERS`), or a simple CSV with columns `job_name, command,
  depends_on, schedule` (`depends_on` semicolon-separated).
- Shell/python/perl scripts are scanned too (`scan_scripts.py`) — wrapper
  scripts are the usual reason a job's command shows no Java directly.
- Python 3.8+ (stdlib only — no pip packages needed).

## Running it

**Step 1 — point it at your code.** Fill in the repo paths (and job export path,
if you have one) in `config.yaml`.

**Step 2 — scan.** Ask Muse to run the scan, or do it yourself:

```
cd ~/workspace/migration-kit
mkdir -p state/raw state/units state/graph output
for r in Risk_DB Risk_DL CoreWM; do
  python3 scripts/scan_java.py  --root <path-to-$r> --repo $r --out state/raw/java_$r.json
  python3 scripts/scan_plsql.py --root <path-to-$r> --repo $r \
      --exts ".sql,.pls,.pks,.pkb,.fnc,.prc,.trg,.vw,.tab,.seq" --out state/raw/plsql_$r.json
  python3 scripts/scan_scripts.py --root <path-to-$r> --repo $r --out state/raw/scripts_$r.json
done
python3 scripts/scan_jobs.py --export <jobs.xml|jobs.csv> --out state/raw/jobs.json
# --format auto-detects controlm (XML/CSV) vs autosys (CSV with a JOB_ID column);
# ...or: echo '[]' > state/raw/jobs.json   (no scheduler data -> units are Java main() classes)
python3 -c "import json,glob; j=[]; [j.extend(json.load(open(f))) for f in glob.glob('state/raw/java_*.json')]; json.dump(j,open('state/raw/java_all.json','w')); p=[]; [p.extend(json.load(open(f))) for f in glob.glob('state/raw/plsql_*.json')]; json.dump(p,open('state/raw/plsql_all.json','w')); s=[]; [s.extend(json.load(open(f))) for f in glob.glob('state/raw/scripts_*.json')]; json.dump(s,open('state/raw/scripts_all.json','w'))"
python3 scripts/build_graph.py --java state/raw/java_all.json --plsql state/raw/plsql_all.json \
    --jobs state/raw/jobs.json --scripts state/raw/scripts_all.json --outdir state/graph
python3 scripts/classify.py --units state/graph/units.json \
    --db-heavy-ratio 1.6 --java-heavy-ratio 0.6 --min-evidence 3
```

### Running one process

At ~4,000 processes the full run is a firehose. To work one process at a
time, use the orchestrator — it runs the whole pipeline for the named
process(es) only:

```
python3 scripts/run_process.py --process NIGHTLY_RISK_JOB \
  --repos Risk_DB=/path/Risk_DB,Risk_DL=/path/Risk_DL,CoreWM=/path/CoreWM \
  --jobs jobs.csv [--ignore ignore.json] [--outdir runs/NIGHTLY_RISK_JOB]
```

`--process` takes a comma-separated list (Autosys job names, or
`main:<fully-qualified-class>` for a code-discovered process). The scan phase
still runs over the full repos — dependency inference needs the whole estate —
but every output is filtered to that process: `units.json`,
`dependency-graph.json`, `db-object-catalog.json`, the HTML doc,
`tables.md` (only the tables it touches), the migration tree (only its
files, mirrored 1:1), and `batches.json` for the review loop. Each downstream
script also takes `--only <unit IDs>` on its own (`build_graph.py`,
`build_process_docs.py`, `build_table_catalog.py`, `make_batches.py`,
`prepare_migration_tree.py` with `--units/--graph/--catalog`), so you can
re-run any stage filtered without re-running the rest.

**Ignore lists.** System-level Java libraries and Oracle packages that exist
on-premise but will never exist on Azure (Oracle JDBC driver classes,
WebLogic, `DBMS_*`, `UTL_*`, `V$*` views) are noise — no point tracing them
or converting them. Put regex patterns in an ignore JSON file (starter:
`fixtures/ignore.json`):

```
{"java_imports": ["^oracle\\.", "^weblogic\\."],
 "oracle_objects": ["^DBMS_.*", "^UTL_.*", "^V\\$.*"]}
```

and pass `--ignore <file>` to `scan_java.py`, `scan_plsql.py`,
`build_graph.py` (filters already-scanned data without re-scanning) and
`prepare_migration_tree.py` (the translator stops flagging calls to ignored
packages). Ignored items are excluded from the graph, units, docs and
catalog — but every scan record keeps them in `ignored_imports` /
`ignored_tables` / `ignored_procs` / `ignored_calls` fields, so the decision
stays auditable. `DBMS_`/`UTL_` risky-construct counts drop ignored calls too.
Definitions are never ignored (a file defining a package still shows up);
only *references* to ignored objects are filtered.

**Scheduler gaps.** The scheduler export is treated as possibly incomplete:
every Java `main()` class not referenced by any job automatically becomes a
`synthetic: true` unit, so code-discovered processes are never silently
dropped. Confirm during review whether each synthetic unit is live, dead code,
or invoked indirectly.

**Script-mediated entry points.** Jobs that invoke wrapper scripts (`.sh`,
`.ksh`, `.pl`, `.py`) are linked through to the Java classes and SQL files
(`sqlplus @file`) the scripts call — scripts are resolved by basename, since
production paths in job commands rarely match checkout paths (it warns if one
basename matches multiple scanned scripts). SQL invoked this way contributes
`read_via_script` / `write_via_script` table references. Jars referenced by job
commands or scripts become `jar:` nodes (`uses` edges) and are listed on the
unit — useful for spotting binary dependencies with no matching source.

**Linkage quality.** Each unit reports `linkage`: `ok` (exact class match or
script-resolved), `maybe` (class-name-only match — typical when a file has no
`package` declaration; candidates listed in `linkage_candidates` for the
reviewer to confirm), or `missing` (no code linked → `NEEDS_REVIEW`).

**Autosys CSV notes.** The expected columns are
`JOB_ID,JOB_NAME,JOB_DESCRIPTION,COMMAND,CONDITION,PARENT_JOB_NAME,TASK_NAME,PARAMETERS`.
Rows are grouped by `JOB_NAME` (one row per condition is the normal shape);
exact duplicate rows are dropped and it warns if one job has conflicting
`COMMAND` values. `CONDITION` cells are parsed into dependencies — plain names
as well as Autosys expressions like `s(JOB_A) AND s(JOB_B)`. `PARENT_JOB_NAME`
becomes a `child_of` edge (kept separate from condition-based `depends_on`
edges). If `COMMAND` yields no code linkage, `TASK_NAME` + `PARAMETERS` is tried
as a fallback.

**Step 3 — review.** Ask Muse to launch the `oracle-migration-review` workflow
with your unit batches (Muse builds the batch list from `state/graph/units.json`
and any checkpoint files already in `state/units/`).

**Step 4 — reports.** Ask Muse to compile the reports from `state/`, or run
the generators yourself:

```
# one self-contained HTML document per process (description, dependency
# chain, inputs/outputs with columns, upstream/downstream, Java-to-Java and
# Oracle-to-Oracle links, one SVG dependency diagram; uses review summaries
# from state/units/ when they exist, otherwise a marked-DRAFT auto-description)
python3 scripts/build_process_docs.py --units state/graph/units.json \
    --graph state/graph/dependency-graph.json --java state/raw/java_all.json \
    --verdicts state/units --outdir output/process-docs
# one Markdown table catalog: columns, readers and writers per table
python3 scripts/build_table_catalog.py --units state/graph/units.json \
    --plsql state/raw/plsql_all.json --out output/tables.md
```

### Learning from migrated processes

Copying Java as-is does not work when the on-prem and cloud in-house
libraries are completely different — the migration is a library/API
translation, not a file copy. The kit learns that translation from processes
you have already migrated:

1. **Point at exemplars.** Either paired files (on-prem + migrated) in
   `pairs.json`, or migrated-only code (no on-prem counterpart):
   ```
   [{"onprem": "path/OnPrem.java", "migrated": "path/Migrated.java",
     "approved": true}]
   ```
   `approved: true` means you vetted that migrated file as a correct
   migration. Migrated-only code contributes the cloud idiom inventory
   (which cloud libraries and calls the migrated code actually uses).
2. **Learn.** `learn_patterns.py` diffs each pair deterministically and
   writes `patterns.json`: `library_map` (on-prem import → cloud import),
   `call_map` (on-prem call → cloud call, or `null` = dropped, e.g.
   `Connection.commit` has no equivalent — Delta writes are atomic),
   `sql_overrides` (statement-level rewrites the mechanical translator did
   NOT produce, e.g. a MERGE a human rewrote), and `cloud_idioms`.
3. **Confirm.** Pairing a removed import with an added one is a semantic
   judgment, not a name match, so derived mappings start as `proposed` with
   their evidence attached. They become `approved` with `--approve auto`
   (only unambiguous derivations: exactly one removed + one added import in
   the pair, or the same pairing seen in ≥3 pairs; vetted SQL overrides),
   `--approve all` (you assert you vetted the exemplars), or by editing
   `"status"` in `patterns.json`. The review agent can also propose new
   patterns from its own migration work.
4. **Apply.** `prepare_migration_tree.py --patterns patterns.json` (or
   `run_process.py --patterns ...`, or `patterns_file` in `config.yaml`):
   approved library mappings rewrite imports in place; approved SQL
   overrides replace the mechanical rules; call sites are **flagged, never
   auto-rewritten** — cloud APIs differ in shape, so the agent rewrites them
   using the exemplar, with the pattern ID attached. Bundles record what was
   applied and flagged; the report has a patterns section.
5. **Grow the library.** Re-run `learn_patterns.py --base patterns.json`
   after each newly migrated process: new evidence merges in, counts bump,
   approved entries stay approved.

## Migration development (after analysis)

`prepare_migration_tree.py` builds the working tree the migration is done in:

```
python3 scripts/prepare_migration_tree.py \
    --repos Risk_DB=<path>,Risk_DL=<path>,CoreWM=<path> \
    --outdir migration-tree
```

- **Folder and file structure is kept exactly as on-premise** — the tree mirrors
  each repo's relative paths 1:1.
- **Java code and logic are copied as-is.** Only the Oracle SQL inside string
  literals is touched, by the deterministic first-pass translator
  (`translate_sql.py`): `NVL`→`COALESCE`, `SYSDATE`→`current_timestamp()`,
  `TO_DATE`/`TO_CHAR` format masks, `TRUNC`, `DECODE`→`CASE`, `FROM DUAL`
  removal, hint removal. Anything needing context (`ROWNUM`, `CONNECT BY`,
  `(+)` joins, sequences, `FOR UPDATE`, dynamic SQL, `DBMS_`/`UTL_` calls) is
  **not guessed** — the original stays in place with a
  `/* TODO-SPARK: ... */` marker.
- **PL/SQL files** get the same first-pass treatment in place, plus a header
  comment listing what changed and what still needs agent work.
- **Translation bundles** (`migration-tree/translation-bundles/<repo>/<path>.translate.json`)
  are the agent's work orders: every SQL literal/statement, its proposed Spark
  SQL, applied rules, flags and confidence. `translation-report.md` summarises
  counts and lists every file needing agent review.
- The ADLS parallel-sync data strategy applies here: tables exist on ADLS
  under the same names, so the migration is a compute-layer translation, not
  a data-movement exercise. Table names need no mapping.

## Known limitations (column extraction and translation)

- Column lists are heuristic: `INSERT`/`UPDATE` columns are exact; `SELECT`
  columns are attributed via table prefixes/aliases or to the single `FROM`
  table when unambiguous. PL/SQL variables/parameters used as values in a
  `SELECT` list (e.g. `SELECT P_ASOF, BOOK, ...`) can appear as read columns,
  and `SELECT *` is recorded as `*`. Review column lists before relying on
  them for translation.
- The first-pass translator only rewrites patterns fully contained in one
  literal/fragment. SQL split across `+`-concatenated fragments (e.g. a
  `TO_DATE` call whose format mask sits in another fragment) is left for the
  agent; the bundle's `chain_sql` shows the merged statement for context.
- `CREATE TABLE` DDL is copied as-is (not translated to Spark DDL) — the
  table catalog is the reference for the DDL work.

## Resume / quota safety — read this

- **Checkpoints are the source of truth.** Every finished unit leaves
  `state/units/<unit_id>.json`. To resume after an interruption or quota
  exhaustion, **relaunch the review workflow fresh with the same args** — batch
  agents skip units that already have checkpoints and only do the missing ones.
  (Verified behavior; do NOT use the runtime's result-cache resume for this —
  it reuses old batch results without re-checking the checkpoint files.)
- **To burn quota slower:** run a trial slice first (a few batches), review only
  the `NEEDS_REVIEW` / `UNKNOWN` units, lower `concurrency`, or raise the batch
  size. Each batch agent carries substantial input-token overhead, so fewer,
  larger batches are cheaper than many tiny ones — up to ~12 units per batch is
  a good balance for review quality.
- Deleting `state/` forces a full re-run (scan is cheap; review re-does everything).

## Why the workflow is "blind" (a runtime note)

In this environment a workflow's `agent()` calls always return empty results to
the workflow script, so the review workflow is deliberately designed to need
nothing back: batches arrive via launch args, agents coordinate through the
checkpoint files, and the final message just points at the outputs. All real
data flows through files, which is also what makes resume reliable.

## Outputs

- `state/graph/dependency-graph.json` — nodes (jobs, Java classes, DB objects)
  and edges (invokes, imports, reads, writes, calls, plus `depends_on` from
  Control-M and heuristic `likely_depends_on` from data-flow inference).
- `state/graph/units.json` — per-process evidence bundles + pre-classification
  + `likely_depends_on` / `likely_required_by` lists. `db_objects` kinds:
  `read` / `write` (direct JDBC/SQL evidence), `read_via_proc` /
  `write_via_proc` (transitive through a called PL/SQL procedure), `call`.
- Final reports (in the agreed output dir):
  - `process-catalog.csv` — one row per process: classification, key code units,
    DB objects touched, signal counts, agent summary.
  - `classification-report.md` — DB-heavy vs Java-heavy breakdown, pattern
    notes, and the explicit list of ambiguous items needing human eyes.
  - `oracle-dialect-census.csv` — counts of each Oracle-specific SQL feature
    (`ROWNUM`, `NVL`, `CONNECT BY`, sequences, …). This sizes the SQL-translation work.
  - `db-object-catalog.csv` — every Oracle object found, where it's defined,
    and which processes touch it.
  - `dependency-graph.json` — the full graph.
  - `output/process-docs/<process>.html` (+ `index.html`) — one self-contained
    HTML document per process: description, dependency chain, inputs/outputs
    with columns, upstream/downstream, Java-to-Java and Oracle-to-Oracle
    dependencies, one SVG dependency diagram.
  - `output/tables.md` — one Markdown file: every table, its columns, the
    processes that read it (inputs) and the processes that write it (outputs).
  - `migration-tree/` — mirrored source tree with first-pass Spark SQL in
    place, translation bundles per file, and `translation-report.md`.

## Layout

- `config.yaml` — repo paths, thresholds, workflow knobs.
- `scripts/` — deterministic scanners (stdlib-only Python); `run_process.py`
  runs the whole pipeline for one named process.
- `prompts/` — the agent prompt template used in review.
- `fixtures/` — tiny synthetic repos used to self-test the scanners and workflow.
- `state/` — checkpoints + intermediate scan data (created at runtime).
- `output/` — reserved for final reports (created at runtime).
- `trial-output/` — leftover from self-testing (safe to delete).
