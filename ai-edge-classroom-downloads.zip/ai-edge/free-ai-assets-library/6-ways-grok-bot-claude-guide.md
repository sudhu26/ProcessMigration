# 6 Ways to Print Insane $$$ With Grok Bot + Claude: The Full Guide

From the AI Edge video

## How to use this guide

There are six ways to make money with Grok Bot and Claude. This guide walks through each one step by step, with the prompts from the video.

- **Every prompt has [brackets].** Fill them in with your own details before you send it.
- **Some prompts build on the one before.** Run those in the same chat so Grok Bot remembers your answers.
- **Drop the whole guide into Grok Bot first** and ask it to digest it, so it knows the plan before you start.
- **Nothing gets sent without you.** Every outreach, DM and application prompt drafts first and waits for your approval.

The six ways:

1. **Grow and convert an audience on X.** The foundation for everything else.
2. **Find leads on autopilot.** The fastest path if you already sell something.
3. **Land sponsors with a small audience.** Paid deals long before you're big.
4. **Sell Grok Bot as a service.** The best place to start from zero.
5. **Build an offer from zero.** Turn the skills you already have into something to sell.
6. **Get hired.** Use X as a public hiring board.

## Before you start: Grok Bot and Claude

You need a Grok Bot subscription for everything in this guide. Grok Bot is an always-on AI agent with its own computer, so it keeps working while yours is off.

There's no model picker in Grok Bot. It chooses the model for each task itself and hands work to Claude when it sees fit, so every prompt here works as it is.

**Optional: put Claude Code inside Grok Bot.** If you've already built skills or workflows in Claude (a writing skill, for example), you can have Grok Bot install Claude Code on its own computer and send chosen tasks to Claude. Just ask Grok Bot to install it. Most people won't need this.

## Part 1: Grow and convert an audience on X

X is the best place to build an audience that pays: Grok Bot is native to it, it has less slop than LinkedIn, and the people who matter in AI are there.

Winning on X takes two jobs. First you **grow an audience** (posting and picking a niche). Then you **convert it** (the value you give and how strong your funnel is). Growing is a masterclass of its own, so this part focuses on converting.

This part is for people who already sell something. If you don't yet, Part 5 shows you how to build an offer. And even if you never start your own account, this is the same system companies hire for in head of content and growth roles.

### Step 1: Map your content funnel

Not every post should sell. Most should grow your reach and build trust, and a few should convert. Lead with reach: viral posts show you what your audience wants and earn the attention that makes your selling posts land.

- **Top of funnel (TOF), ~60% of posts: reach.** Teach what you know and share the AI systems you use.
- **Middle of funnel (MOF), ~30%: trust.** Case studies, results, behind the scenes, even your failures.
- **Bottom of funnel (BOF), ~10%: sales.** Posts that point to your offer.

The right mix shifts with your account size, so the prompt below also asks Grok Bot for yours.

**Prompt for funnel mapping:**

```
You are helping me build a content funnel on X for my existing offer.

My offer: [describe what you sell]

My audience: [who they are]

Create a clear TOF / MOF / BOF content pillar system with this mix:
- TOF ~60% (reach)
- MOF ~30% (trust)
- BOF ~10% (sales)

For each pillar, give me:
1. 5–7 specific content ideas
2. Why it fits that stage
3. Example hook
4. Soft CTA that moves people to the next stage

Also suggest the best posting ratio for my current account size.
```

### Step 2: Create content that sells

These are your core MOF and BOF pillars:

- **Case studies:** "How I helped [client] go from X to Y"
- **Results:** screenshots, numbers, before and afters
- **Behind the scenes:** how you actually fulfill or build the product
- **Frameworks:** your process, packaged so people want help applying it
- **Lessons:** mistakes you made so your audience doesn't have to

Use the funnel mapping prompt above to architect post ideas for these pillars. The ideas need your feedback before they sound like you. Miles built his brand voice over weeks with Claude: every time he changed a draft, he had Claude update his voice skill. A skill is really just a markdown file with your voice and posting style in it. Grok Bot's memory learns the same way, but a written voice file is worth having either way.

Still write a lot yourself, because it sounds better. Let the bot do the grunt work and keep the final say.

### Step 3: Make your profile convert

Your X profile is your sales page. Tell Grok Bot your offer, your voice or who you work for, and the audit gets sharper.

**Prompt for profile audit:**

```
Audit my X profile as a sales page for this offer: [your offer]

Analyze:
- Bio
- Banner
- Pinned post
- Recent posts
- Link in bio

Give me specific rewrites and changes that would increase conversion rate. Be direct and critical.
```

### Step 4: Optimize your CTAs (calls to action)

Know what you're pushing people toward, but it doesn't have to be paid: a newsletter, a free community or simply "follow" all work. In the early days of his X account, Miles used "follow" as his only CTA. It built algorithmic traction, so later posts converted better.

If you make long-form content, push people from X to YouTube. X builds the awareness, and YouTube is where a product is easiest to explain and sell.

A simple line at the end of your best posts goes a long way:

- "I break this down in more depth in my newsletter (link in bio)."
- "DM me 'system' and I'll send you the template."
- "We help brands do this. Link in bio."

**Prompt for CTAs:**

```
Study what is currently working for other creators in my niche: [niche]

Reverse-engineer the highest-converting CTAs (soft and direct) for my brand.

My offer: [offer]

My voice: [describe or paste examples]

Give me 10 CTA variations I can put at the end of posts.
```

### Step 5: Track what converts

This is where an always-on agent pays off. Set up an Analytics Bot that learns what converts for you (profile visits, link clicks, DMs) and reports back every week.

**Prompt for analytics:**

```
Train yourself on what actually converts for me.

I will share data on:
- Profile visits
- Link clicks
- DMs received
- Which posts drive the most of the above

Analyze patterns and tell me:
1. What content types convert best
2. What CTAs work
3. What I should double down on
4. What I should stop doing

Every Monday, ask me for the last 7 days of data and send me a short report on those four points.
```

### Bonus: a Researcher Bot

Have a bot send you the biggest topics in your niche every morning, including new GitHub repos that are gaining traction, so you stay a step ahead.

Don't hand everything to the bot. Keep scrolling and bookmarking yourself, because you need your finger on the pulse of what's going viral and what people complain about. Let the bot do the grunt work and keep the decisions.

**Part 1 in one line:** build a Grok Bot content team that researches, writes in your voice and learns from your data, then funnel your audience toward your offer.

## Part 2: Find leads on autopilot

If you already sell something, lead generation is the fastest way to make money on X: Grok Bot runs a qualified outreach system for you.

Grok Bot is good at finding leads because it plugs straight into X, where almost every lead you could want is posting, and it can reach LinkedIn too. You need a little platform first, even a few thousand followers in a niche.

### Step 1: Define a qualified lead

Spend a few minutes telling Grok Bot what a good lead looks like. Attach emails or prospect briefs if you have them.

**Prompt to define qualified lead:**

```
Help me define a qualified lead for my offer.

My offer: [what you sell]

Ideal customer: [who they are]

What are the clearest signals that someone is a good fit?

Include both positive signals and disqualifiers.

Also suggest 5–8 specific search queries I should use on X to find these people.
```

### Step 2: Build a Lead Scout Bot

This bot hunts your ideal customer profile (ICP) every day and brings you the leads, ready to contact.

**Prompt for Lead Scout Bot:**

```
You're my Lead Scout. Every day, search for people who match my ideal client and show buying signals.

My offer: [what you sell]

Qualified lead definition: [paste what we defined above]

Every day, search X for people posting about [the pain my offer solves] in the last 24–48 hours.

For each lead, return:
- Link to the post
- Why they fit
- A short draft message in my voice

Never DM, reply, or follow anyone. I will send everything myself. Show me the plan first.
```

### Step 3: Draft the outreach

Write the outline yourself to avoid AI slop, then let the bot polish it. Keep a version for each kind of client, and approve and send every message yourself.

### Step 4: Build a pipeline tracker

Have Grok Bot build a "pipeline tracker" to manage all your prospects in one dashboard. You can connect a CRM like Notion or HubSpot instead, but this way your lead gen runs A to Z in one place.

Tips for this part:

- Have Grok Bot look for people posting about the pain point your product or service solves
- Run outreach on more than one channel (email, X and so on)
- It works especially well for service businesses like ghostwriting

**Why always-on matters:** a chat assistant only works while you're there. An always-on agent has its own computer and browser, so your Lead Scout keeps working while you sleep. Think of it as a very smart employee that never clocks off.

## Part 3: Land sponsors with a small audience

You don't need a massive audience to earn from sponsors: grow to 5,000 to 10,000 followers and $1,000 to $5,000 a month in sponsors is realistic.

Small niche accounts get offers too. Miles had sponsors reaching out at around 1,500 followers. AI is where the bigger sponsor budgets are right now, and you can pair it with a niche you already know: finance with AI, growth marketing with AI.

To hunt deals actively, launch a Sponsorship Hunter bot. It studies your account and what you post, finds brands already paying creators like you, tracks open campaigns and drafts the outreach. You can also have it find the creator campaign websites where companies look for creators, so you can sign up to them.

Ready-made Sponsorship Hunter Bot (open it in Grok Bot, or build your own with the prompt below): https://x.ai/bot/8w67xlhpYb_vXdNfDuBbE

**Prompt for Sponsorship Hunter:**

```
You are my Sponsorship Hunter.

Study my X account and niche: [your niche / account]

Sponsorships I want: [events / video / newsletter / podcast / X articles]

Find:
1. Brands that are already paying creators similar to me
2. Open creator campaigns and marketplaces
3. Realistic sponsorship opportunities for my current size

For each opportunity, give me:
- Brand / program name
- Why it fits
- Estimated rate range if available
- Draft outreach message

Show me every draft first. Only send the ones I approve.
```

### Go through the agencies

Don't only pitch brands. Message the agencies that run creator campaigns in your niche and ask for deal flow. A big launch can involve 100 to 500 creators, and agencies need smaller accounts to amplify the big ones. With around 5,000 followers, most won't say no, and they do the outbound and carry the client risk for you.

## Part 4: Sell Grok Bot as a service

This is the best path if you're starting from zero: demand for people who can set Grok Bot up is high, and most businesses don't have the time or know-how to do it themselves.

Grok Bot is new and going viral, so the window is open now. Even a business owner who knows AI may not have time to run it, and agents still make mistakes. Most people also won't let AI make the final call, like posting on its own or updating a live website. Being the person who sets it up, checks its work and keeps improving it is the job you're selling.

What you can sell:

- **Content teams** for founders, personal brands and companies
- **X account audits** with a specialized Grok Bot team: come to a creator with real fixes instead of a cold DM
- **Templates and skills** you've dialed in (this works best once you have some distribution)
- **Lead gen and sales agents** for agencies, service businesses and local businesses, most of which have never heard of always-on agents
- **Setup workshops** or 1-on-1 calls

### Step 1: Build useful systems for yourself first

Get in the trenches: set up workflows for your own content, research or coding, then document them publicly on X. If you have a useful bot, people will engage.

**Prompt to turn your bot into a resellable template:**

```
I want to turn this Bot (and its skills/workflows) into a resellable template.

Document:
1. What this Bot does
2. Who it is for
3. How to set it up
4. The key skills and instructions it uses
5. Any required connections

Format it so I can package and sell it as a Grok Bot template.
```

### Step 2: Package the offer

Give it a name, say who it's for, what setup, training and retainer include, and how you price it. Put it on a website, or record a quick VSL (video sales letter).

### Step 3: Find clients

Use the Lead Scout Bot from Part 2, tuned for this offer.

**Prompt to find clients:**

```
Use Lead Scout logic for this offer:

Offer: Grok Bot setup / content team / lead gen agents for [founders / agencies / personal brands]

Find people on X who are:
- Talking about needing help with content, AI, or systems
- Founders or agency owners
- Clearly struggling with time or consistency

For each, give post link + why they fit + draft DM.
```

Once you land a couple of clients, ask for a testimonial. That's what makes the next clients come to you, and local businesses are a great place to land the first ones.

### Step 4: Deliver

Fulfillment is simple: weekly check-ins, bot tune-ups and keeping their skills up to date, usually on a shared company account. Add-ons like a Grok Bot second brain in Obsidian or Notion work well too.

The more reporting and ideas you bring each week, the more value you add, and the more value you add, the harder you are to replace.

## Part 5: Build an offer from zero

If you don't know what to sell yet, Grok Bot can uncover your skills, match them to real demand and package them into an offer. Run Steps 1 to 3 in the same chat, since each prompt builds on the last.

### Step 1: Uncover your skills

Grok Bot runs a deep interview to understand what you're good at.

Optional: paste in the transcript of the AI Edge video this guide comes with (on the video's YouTube page, open the description and click Show transcript). If it misspells Grok Bot, tell Grok Bot.

**Prompt to uncover skills:**

```
Conduct a deep interview with me to uncover my monetizable skills.

Ask me questions until you understand:
- What I'm unusually good at
- What people already ask me for help with
- What results I've produced before
- What I enjoy doing

Then summarize my top 3–5 skills that could become an offer.
```

### Step 2: Find market demand

Point Grok Bot at X to learn what your ideal customers struggle with. Are they stuck on setting things up, or on delivering? A marketing agency needs something very different from a content agency.

**Prompt to find market demand:**

```
Using the skills above, search X for what my ideal customers are struggling with.

Look for:
- Complaints
- Questions
- "How do I…" posts
- People saying they need help

Summarize the top pain points and which of my skills match them best.
```

### Step 3: Package the offer

Grok Bot walks you through pricing, low- and high-ticket options, format and outcomes. Start with a low price, then raise it as demand comes in. Once the offer is proven, you can charge a lot more.

**Prompt to package the offer:**

```
Help me package an offer from the skills + demand we found.

Cover:
- Offer name
- Who it's for
- What they get
- Pricing (low-ticket and high-ticket options)
- Clear outcome
- How to validate it quickly
```

### Step 4: Validate, then sell

Test demand before you put effort into finding customers:

- Posts and polls
- Long-form content
- Replying to bigger accounts in your niche
- A free or discounted offer

Once the offer is validated, build bots to bring in clients with Parts 1 and 2.

## Part 6: Get hired

X is basically a public hiring board, and companies everywhere are hiring for content roles, so even a small account can put you in front of the biggest teams.

Building your brand with Part 1 helps any application, and results with local businesses from Part 4 give you real things to talk about in an interview. You still need to be personable: not everything happens behind a screen.

Grok Bot can research a company, break down the role, tailor your CV and write your application. Stay involved, and approve everything before it goes out.

**Prompt for hiring:**

```
Help me land a job using Grok Bot.

Target role: [job title]

Target company: [company]

1. Research the company and the specific role
2. Build a custom resume/CV tailored to this job
3. Draft a short, personalized application message or cover note
4. Identify the best place to apply (and any relevant people to reach out to on X or LinkedIn)

Show me everything before anything is submitted.
```

Once you've approved everything, your hiring bot can also apply on LinkedIn and Indeed and tailor your resume to each job. Boardy, an AI connector that makes introductions between people and companies, can also put you in front of teams hiring for your role.

Then treat X like the hiring board it is: have Grok Bot send you posts every day from the founders, CMOs and hiring managers at the companies you want to work for, and leave thoughtful replies. What do you have to lose by leaving ten good comments a day? Throw enough darts and you hit the bullseye.

## Your next step

Pick one part, run its prompts today and keep going. You don't get good at riding a bike by watching videos of people riding bikes: consume, act, repeat.

Built something with this guide? Share it in the AI Edge Skool community. Help each other, share your accounts and grow together.
