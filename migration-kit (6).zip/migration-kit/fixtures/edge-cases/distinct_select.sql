-- DISTINCT/ALL/UNIQUE select-list regression (R7-G4, new assertion 44):
-- a leading DISTINCT/ALL/UNIQUE/DISTINCTROW must be stripped before
-- alias handling, or m_alias2 treats the keyword as a column name
-- and the first real column as its alias, silently eating it; UNIQUE
-- (not previously in _SQL_KW) was recorded as a bogus column.
-- Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (distinct_select.sql record): reads ['T1'],
-- table_columns {'T1': {'read': ['A', 'B'], 'write': []}},
-- columns_unattributed [].
SELECT DISTINCT a, b FROM t1;
SELECT ALL a FROM t1;
SELECT UNIQUE a FROM t1;
SELECT DISTINCTROW a FROM t1;
SELECT DISTINCT t1.a FROM t1;
