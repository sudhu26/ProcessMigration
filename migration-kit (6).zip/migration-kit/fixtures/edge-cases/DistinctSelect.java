package com.risk.edge;

/** DISTINCT/ALL/UNIQUE select-list regression (R7-G4, new assertion 44):
 *  a leading DISTINCT/ALL/UNIQUE/DISTINCTROW must be stripped before
 *  alias handling, or m_alias2 treats the keyword as a column name
 *  and the first real column as its alias, silently eating it; UNIQUE
 *  (not previously in _SQL_KW) was recorded as a bogus column.
 *  Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (DistinctSelect.java record): tables_read ['T1'],
 *  table_columns {'T1': {'read': ['A', 'B'], 'write': []}},
 *  columns_unattributed [] */
public class DistinctSelect {

    public void run(java.sql.Statement st) throws Exception {
        String distinctTwo =
                "SELECT DISTINCT a, b FROM t1";
        st.executeQuery(distinctTwo);

        String allOne =
                "SELECT ALL a FROM t1";
        st.executeQuery(allOne);

        String uniqueOne =
                "SELECT UNIQUE a FROM t1";
        st.executeQuery(uniqueOne);

        String distinctRowOne =
                "SELECT DISTINCTROW a FROM t1";
        st.executeQuery(distinctRowOne);

        String distinctQualified =
                "SELECT DISTINCT t1.a FROM t1";
        st.executeQuery(distinctQualified);
    }
}
