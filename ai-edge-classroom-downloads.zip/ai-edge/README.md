# AI Edge — Classroom Downloads
Downloaded 2026-11-09 from https://www.skool.com/milesdeutscher/classroom (signed in as Sks Sin; joined the free group the same day to enable downloads).
All three courses, every lesson opened.

## Contents
- free-ai-assets-library/ — one guide per lesson (40 lessons): Markdown guides and PDF playbooks/cheat sheets.
- personal-ai-os-7-days/ — the 7-file Build Kit for "Build Your Personal AI OS in 7 Days" (requirements CSV, architecture prompt, Supabase schema SQL, task-classification prompt, acceptance tests CSV, security/backup checklist, daily review prompts).
- side-hustle-7-days/ — the 7-file Validation Kit for "Choose and Validate One AI Side Hustle in 7 Days" (scorecard, selection worksheet, workflow audit, offer brief, proof checklist, distribution calendar, outreach scripts).
- github-repos.txt — every GitHub repo linked from the Free AI Assets Library lessons (the lessons link repos rather than attaching them).

## Notes
- One lesson title, "Find Your ONE AI Side Hustle (Using AI)", appeared in the course sidebar early on but vanished before it could be opened — it looks removed or renamed by the community. All 40 lessons the course lists were swept.
- The Day 1–7 lessons in both 7-day courses carry no attachments of their own; they point at the kit files above.
