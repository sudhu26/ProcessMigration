#!/usr/bin/env python3
"""Deterministic first-pass Oracle SQL -> Spark SQL translation.

Mechanical, local patterns only (NVL, SYSDATE, DUAL, hints, TO_DATE/TO_CHAR
format masks, TRUNC, DECODE). Anything needing context — ROWNUM, CONNECT BY,
old-style (+) joins, sequences, FOR UPDATE, dynamic SQL — is flagged for
human/agent review instead of guessed at.

translate(sql) -> {'original', 'translated', 'applied': [rule names],
                   'flags': [messages], 'confidence': 'high'|'medium'|'needs-review'}
Stdlib only.
"""
import re

_FMT_MAP = {'YYYY': 'yyyy', 'YY': 'yy', 'MM': 'MM', 'DD': 'dd', 'HH24': 'HH',
            'HH12': 'hh', 'MI': 'mm', 'SS': 'ss', 'MON': 'MMM', 'MONTH': 'MMMM',
            'DY': 'EEE', 'DAY': 'EEEE'}
_DBMS_UTL_PAT = re.compile(r'\b(DBMS_|UTL_)[\w$]+\b', re.I)
_FLAG_PATTERNS = [
    (re.compile(r'\bROWNUM\b', re.I),
     'ROWNUM: rewrite with ROW_NUMBER() OVER (ORDER BY ...) — needs ORDER BY context'),
    (re.compile(r'\b(CONNECT\s+BY|START\s+WITH)\b', re.I),
     'CONNECT BY: rewrite as a recursive CTE'),
    (re.compile(r'\(\+\)'),
     '(+) outer join: rewrite as LEFT/RIGHT JOIN'),
    (re.compile(r'\b(NEXTVAL|CURRVAL)\b', re.I),
     'sequence (NEXTVAL/CURRVAL): no Spark equivalent — use monotonically_increasing_id or a lookup table'),
    (re.compile(r'\bFOR\s+UPDATE\b', re.I),
     'FOR UPDATE: no row locking in Spark — check transaction semantics'),
    (re.compile(r'\bEXECUTE\s+IMMEDIATE\b', re.I),
     'EXECUTE IMMEDIATE: dynamic SQL must be resolved before translation'),
    (re.compile(r'\bMODEL\b', re.I),
     'MODEL clause: no Spark equivalent — rewrite'),
    (re.compile(r'\bPIVOT\b', re.I),
     'PIVOT: rewrite with conditional aggregation'),
    (_DBMS_UTL_PAT,
     'DBMS_/UTL_ call: no Spark equivalent — rewrite in Java/Spark'),
    (re.compile(r'\bMERGE\s+INTO\b', re.I),
     'MERGE: review — Spark MERGE syntax differs in places'),
    (re.compile(r'\bBULK\s+COLLECT\b|\bFORALL\b', re.I),
     'BULK COLLECT / FORALL: procedural construct — rewrite as set-based Spark ops'),
]


def split_top_commas(s):
    """Split on top-level commas: paren-aware AND string-aware (a comma
    inside a quoted literal, e.g. DECODE(a,'x,y',1,...), is not a split)."""
    parts, depth, cur = [], 0, ''
    in_str, i = False, 0
    while i < len(s):
        ch = s[i]
        if in_str:
            cur += ch
            if ch == "'":
                if s[i + 1:i + 2] == "'":  # '' is an escaped quote
                    cur += "'"
                    i += 2
                    continue
                in_str = False
            i += 1
            continue
        if ch == "'":
            in_str = True
            cur += ch
        elif ch == '(':
            depth += 1
            cur += ch
        elif ch == ')':
            depth = max(0, depth - 1)
            cur += ch
        elif ch == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += ch
        i += 1
    if cur.strip():
        parts.append(cur)
    return parts


_SEG_RE = re.compile(r"'(?:''|[^'])*'|/\*.*?\*/|--[^\n]*", re.DOTALL)


def _protected_spans(sql):
    """(start, end) spans of string literals and comments — function
    rewrites must not fire inside them."""
    return [(m.start(), m.end()) for m in _SEG_RE.finditer(sql)]


def _strip_terminator(s):
    """The statement without a single trailing ';' (and surrounding
    whitespace). Overrides are stored and compared WITHOUT the statement
    terminator; the terminator is preserved from the original chunk by
    the caller (see prepare_migration_tree.py)."""
    t = s.strip()
    if t.endswith(';'):
        t = t[:-1].strip()
    return t


def split_statements(text):
    """Split text into ;-terminated chunks, string/comment-aware: a ';'
    inside a string literal or a -- / /* */ comment does NOT split.
    Reuses the protected spans (_SEG_RE) above, so a ';' inside
    'a;b' or inside a comment stays inside its statement."""
    spans = _protected_spans(text)
    parts, start = [], 0
    for m in re.finditer(r';', text):
        if any(s <= m.start() < e for s, e in spans):
            continue
        parts.append(text[start:m.end()])
        start = m.end()
    if start < len(text):
        parts.append(text[start:])
    return parts


def _split_leading_comments(stmt):
    """Split a ;-terminated chunk into (prefix, rest), where prefix is
    the leading whitespace plus any leading `--...` / `/*...*/`
    comments and rest is the statement itself. Overrides are compared
    against rest (see R5-G2); the prefix is preserved verbatim in the
    mirrored body, so the comment survives.

    SINGLE SHARED COPY — do not fork it. prepare_migration_tree.py
    imports this to strip comments before the override compare, and
    learn_patterns.py imports it to strip comments when LEARNING an
    override's `from`/`to` (R6-G1): a learned `from` that still carries
    the leading comment can never match at the tree end, and a `to`
    that carries one would be injected verbatim into mirrored bodies."""
    i, n = 0, len(stmt)
    while True:
        j = i
        while j < n and stmt[j] in ' \t\r\n':
            j += 1
        if stmt.startswith('--', j):
            k = stmt.find('\n', j)
            i = n if k == -1 else k + 1
            continue
        if stmt.startswith('/*', j):
            k = stmt.find('*/', j + 2)
            i = n if k == -1 else k + 2
            continue
        i = j
        break
    return stmt[:i], stmt[i:]


def _find_calls(sql, name, protected=()):
    """Yield (start, end, [args]) for name(...) calls, balanced parens.
    Calls whose name sits inside a string literal or comment are skipped,
    and parens inside string literals in the arguments do not count."""
    for m in re.finditer(r'\b' + name + r'\s*\(', sql, re.I):
        if any(s <= m.start() < e for s, e in protected):
            continue
        i, depth = m.end(), 1
        while i < len(sql) and depth > 0:
            c = sql[i]
            if c == "'":
                i += 1  # skip the string literal, '' is an escaped quote
                while i < len(sql):
                    if sql[i] == "'":
                        if sql[i + 1:i + 2] == "'":
                            i += 2
                            continue
                        i += 1
                        break
                    i += 1
                continue
            if c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
            i += 1
        yield m.start(), i, split_top_commas(sql[m.end():i - 1])


def _replace_calls(sql, name, fn, applied, flags, rule, protected=()):
    """Apply fn(args) -> replacement (or None to leave unchanged) to every
    name(...) call outside string literals/comments, right-to-left so
    offsets stay valid. `rule` is the applied-rule name recorded when any
    call changes, or a callable (name, args) -> name for per-form names:
    TO_CHAR records 'TO_CHAR->CAST' for the 1-arg form and
    'TO_CHAR->date_format' for the 2-arg form (F-N2)."""
    calls = list(_find_calls(sql, name, protected))
    if not calls:
        return sql
    changed = False
    for start, end, args in reversed(calls):
        stripped = [a.strip() for a in args]
        rep = fn(stripped)
        if rep is not None:
            sql = sql[:start] + rep + sql[end:]
            changed = True
            if callable(rule):
                applied.append(rule(name, stripped))
    if changed and not callable(rule):
        applied.append(rule)
    return sql


def _map_fmt(mask):
    """Map an Oracle date-format mask to a Spark/Java mask, or None if it
    contains tokens we do not know."""
    raw = mask.strip().strip("'")
    out, i, known = '', 0, True
    toks = sorted(_FMT_MAP, key=len, reverse=True)
    while i < len(raw):
        if not raw[i].isalpha():
            out += raw[i]
            i += 1
            continue
        hit = None
        for t in toks:
            if raw[i:i + len(t)].upper() == t:
                hit = t
                break
        if hit:
            out += _FMT_MAP[hit]
            i += len(hit)
        else:
            known = False
            break
    return out if known else None


def _unquote(s):
    return s.strip().strip("'")


def translate(sql, ignored=None, overrides=None):
    """ignored: an ignore_lists.IgnoreList (or None). Calls to ignored
    Oracle packages are not flagged — they are out of migration scope.
    overrides: approved learned SQL overrides, [{"from", "to", "id"}] —
    a statement match (whitespace-normalized, case-insensitive, and
    WITHOUT the statement terminator on either side — a single trailing
    ';' is stripped from both before comparing) wins over the mechanical
    rules, and is reported as applied rule "pattern:<id>". The stored
    `to` is returned as-is; the mechanical path keeps the statement
    (including any terminator) intact."""
    original = sql
    applied, flags = [], []
    if overrides:
        nsql = ' '.join(_strip_terminator(sql).split()).lower()
        for ov in overrides:
            if ' '.join(_strip_terminator(ov['from']).split()).lower() == nsql:
                return {'original': original, 'translated': ov['to'],
                        'applied': [f"pattern:{ov.get('id', 'sql-override')}"],
                        'flags': [], 'confidence': 'high'}
    # --- keyword-level rules, applied outside string literals/comments ---
    segments = re.split(r"('(?:''|[^'])*'|/\*.*?\*/|--[^\n]*)", sql,
                        flags=re.DOTALL)
    for i in range(0, len(segments), 2):
        seg = segments[i]
        new = re.sub(r'\bSYSDATE\b', 'current_timestamp()', seg, flags=re.I)
        if new != seg:
            applied.append('SYSDATE->current_timestamp()')
            seg = new
        new = re.sub(r'\bSYSTIMESTAMP\b', 'current_timestamp()', seg,
                     flags=re.I)
        if new != seg:
            applied.append('SYSTIMESTAMP->current_timestamp()')
            seg = new
        new = re.sub(r'\s+FROM\s+DUAL\b', '', seg, flags=re.I)
        if new != seg:
            applied.append('FROM DUAL removed')
            seg = new
        for pat, msg in _FLAG_PATTERNS:
            matches = list(pat.finditer(seg))
            if not matches:
                continue
            if ignored and pat is _DBMS_UTL_PAT:
                # ignored packages (e.g. DBMS_OUTPUT) are out of scope:
                # only flag the ones that are NOT ignored
                matches = [m for m in matches
                           if not ignored.ignore_object(m.group(0).upper())]
                if not matches:
                    continue
            flags.append(msg)
        segments[i] = seg
    # optimizer hints are comments, so the split above always puts them in
    # odd segments (a /*+ */ inside a string literal is a different segment
    # and is left alone) — strip them here, not on the code segments
    for i in range(1, len(segments), 2):
        if segments[i].startswith('/*+'):
            segments[i] = ''
            applied.append('optimizer hint removed')
    sql = ''.join(segments)

    # --- function-level rewrites, scoped like the keyword rules: never
    # inside a string literal or comment. Spans are recomputed before each
    # call because a rewrite changes the offsets of everything after it. ---
    def nvl(args):
        return f'COALESCE({args[0]}, {args[1]})' if len(args) == 2 else None

    def nvl2(args):
        if len(args) == 3:
            return (f'CASE WHEN {args[0]} IS NOT NULL THEN {args[1]} '
                    f'ELSE {args[2]} END')
        return None

    def to_date(args):
        if len(args) == 2:
            m = _map_fmt(args[1])
            if m is None:
                flags.append(f"TO_DATE format mask {args[1]}: unmapped tokens")
                return None
            return f"to_date({args[0]}, '{m}')"
        if len(args) == 1:
            return f'to_date({args[0]})'
        return None

    def to_char(args):
        if len(args) == 2:
            m = _map_fmt(args[1])
            if m is None:
                flags.append(f"TO_CHAR format mask {args[1]}: unmapped tokens")
                return None
            return f"date_format({args[0]}, '{m}')"
        if len(args) == 1:
            return f'CAST({args[0]} AS STRING)'
        return None

    def trunc(args):
        if len(args) == 1:
            return f'to_date({args[0]})'
        if len(args) == 2:
            unit = _unquote(args[1]).upper()
            if unit in ('DD', 'D'):
                return f'to_date({args[0]})'
            if unit in ('MM', 'MON', 'MONTH'):
                return f"date_trunc('month', {args[0]})"
            if unit in ('YYYY', 'YY', 'YEAR'):
                return f"date_trunc('year', {args[0]})"
            if unit in ('HH', 'HH24'):
                return f"date_trunc('hour', {args[0]})"
            flags.append(f'TRUNC unit {args[1]}: no direct mapping')
            return None
        return None

    def decode(args):
        if len(args) < 3:
            return None
        expr, rest = args[0], args[1:]
        default = None
        if len(rest) % 2 == 1:
            default = rest[-1]
            rest = rest[:-1]
        parts = [f'CASE {expr}']
        for j in range(0, len(rest), 2):
            parts.append(f'WHEN {rest[j]} THEN {rest[j + 1]}')
        if default is not None:
            parts.append(f'ELSE {default}')
        parts.append('END')
        return ' '.join(parts)

    for name, fn, rule in (
            ('NVL2', nvl2, 'NVL2->CASE'),
            ('NVL', nvl, 'NVL->COALESCE'),
            ('TO_DATE', to_date, 'TO_DATE->to_date'),
            ('TO_CHAR', to_char,
             lambda name, args: 'TO_CHAR->CAST' if len(args) == 1
             else 'TO_CHAR->date_format'),
            ('TRUNC', trunc, 'TRUNC->date_trunc/to_date'),
            ('DECODE', decode, 'DECODE->CASE')):
        sql = _replace_calls(sql, name, fn, applied, flags, rule,
                             _protected_spans(sql))

    flags = sorted(set(flags))
    applied = sorted(set(applied))
    if flags:
        confidence = 'needs-review'
    elif ('DECODE->CASE' in applied
          or any('->to_date' in a or '->date_format' in a or '->CAST' in a
                 for a in applied)):
        confidence = 'medium'
    else:
        confidence = 'high'
    return {'original': original, 'translated': sql,
            'applied': applied, 'flags': flags, 'confidence': confidence}


def translate_statement(sql, ignored=None, overrides=None):
    """translate() with the original preserved for the caller."""
    return translate(sql, ignored, overrides)
