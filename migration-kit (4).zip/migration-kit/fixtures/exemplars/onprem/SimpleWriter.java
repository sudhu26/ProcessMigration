package com.risk.jobs;

import com.risk.db.OracleWriter;

public class SimpleWriter {
    public void run() {
        OracleWriter writer = new OracleWriter("RISK_RESULTS");
        writer.write("INSERT INTO RISK_RESULTS (AS_OF_DATE) VALUES (SYSDATE)");
        writer.commit();
    }
}
