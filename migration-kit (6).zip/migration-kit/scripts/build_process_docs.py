#!/usr/bin/env python3
"""Build one self-contained HTML document per process from units.json.

Each document shows: what the process does (review summary if a verdict
checkpoint exists, else an auto-drafted description marked DRAFT), the
dependency chain (Autosys job -> script -> jar/Java -> Oracle), inputs and
outputs with columns, upstream/downstream dependencies, Java-to-Java and
Oracle-to-Oracle links, and one inline SVG dependency diagram. No external
assets: CSS and SVG are inlined, so each file is self-contained.

Usage: build_process_docs.py --units units.json [--graph dependency-graph.json]
       [--java java_all.json] [--verdicts state/units] --outdir output/process-docs
"""
import argparse, html, json, os, re, sys
from collections import defaultdict

CSS = """
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0 auto;
max-width:1000px;padding:24px;color:#1a1a1a;line-height:1.5}
h1{font-size:24px;border-bottom:3px solid #2563eb;padding-bottom:8px}
h2{font-size:18px;margin-top:28px;border-bottom:1px solid #ddd;padding-bottom:4px}
h3{font-size:15px;margin-top:18px}
.badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;
font-weight:600;margin-right:6px;color:#fff}
.b-db{background:#b45309}.b-java{background:#166534}.b-bal{background:#6d28d9}
.b-review{background:#9d174d}.b-unknown{background:#6b7280}
.b-ok{background:#15803d}.b-maybe{background:#b45309}.b-missing{background:#b91c1c}
.b-synth{background:#0e7490}
table{border-collapse:collapse;width:100%;margin:8px 0}
th,td{border:1px solid #ddd;padding:6px 10px;text-align:left;font-size:13px;vertical-align:top}
th{background:#f3f4f6}
code{font-size:12px;background:#f3f4f6;padding:1px 4px;border-radius:3px}
.chain{font-family:ui-monospace,Menlo,monospace;font-size:13px;background:#f8fafc;
border:1px solid #e2e8f0;border-radius:6px;padding:12px}
.chain .arr{color:#2563eb;font-weight:700}
.draft{background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:10px}
.note{color:#6b7280;font-size:12px}
svg{border:1px solid #e2e8f0;border-radius:6px;background:#fff;max-width:100%}
ul{margin:6px 0}
"""


def sanitize(name):
    return re.sub(r'[^A-Za-z0-9_.-]', '_', name)


def esc(x):
    return html.escape(str(x))


def load(p, default):
    if p and os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    return default


def load_verdicts(d):
    out = {}
    if d and os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            if fn.endswith('.json'):
                p = os.path.join(d, fn)
                try:
                    v = json.load(open(p, encoding='utf-8'))
                    out[v.get('unit_id') or fn[:-5]] = v
                except Exception:
                    # R7-N5: a corrupt checkpoint must not vanish
                    # silently as "no verdict" — name the file on stderr.
                    print(f'warning: corrupt verdict checkpoint {p}; '
                          f'ignoring', file=sys.stderr)
    return out


def short(name, n=34):
    return name if len(name) <= n else name[:n - 1] + '…'


def _is_read(d):
    return d['kind'] in ('read', 'read_via_proc', 'read_via_script') or \
        bool(d.get('columns_read'))


def _is_write(d):
    return d['kind'] in ('write', 'write_via_proc', 'write_via_script') or \
        bool(d.get('columns_written'))


def describe(unit, verdict):
    """(summary_lines, is_draft) — verdict summary when reviewed, else an
    auto-draft built from evidence, clearly marked as such."""
    if verdict and verdict.get('summary'):
        return [verdict['summary']], False
    m = unit.get('metrics', {})
    reads = [d['name'] for d in unit.get('db_objects', []) if _is_read(d)]
    writes = [d['name'] for d in unit.get('db_objects', []) if _is_write(d)]
    calls = [d['name'] for d in unit.get('db_objects', []) if d['kind'] == 'call']
    entry = [os.path.basename(p)[:-5] if p.endswith('.java') else p
             for p in (unit.get('entry_points') or ['(no code linked)'])]
    s = (f"Runs {', '.join(entry)}"
         f"{' on schedule ' + unit['schedule'] if unit.get('schedule') else ''}. "
         f"Reads {len(reads)} table(s) ({', '.join(reads) or 'none'}) and writes "
         f"{len(writes)} table(s) ({', '.join(writes) or 'none'})"
         f"{'; calls ' + ', '.join(calls) if calls else ''}. "
         f"Implementation spans {unit.get('java_file_count', 0)} Java file(s), "
         f"{m.get('loc', 0)} lines, {m.get('sql_literals', 0)} SQL literals, "
         f"{m.get('oracle_ism_total', 0)} Oracle-dialect features.")
    return [s], True


def unit_scripts(jid, out_e, in_e):
    """Scripts for a unit: the job's own scripts plus wrapper scripts that
    invoke the unit's entry Java files (a job command often calls Java
    directly while a wrapper script invokes the same main)."""
    job_scripts = {e['dst'] for e in out_e.get(jid, [])
                   if e['dst'].startswith('script:')}
    # R7-G6: BFS over script->script out-edges to a fixpoint first, so
    # chained wrapper scripts (job -> s1.sh -> s2.sh -> java) are all
    # included — the old code followed only one script hop.
    _stack = list(job_scripts)
    while _stack:
        _s = _stack.pop()
        for e in out_e.get(_s, []):
            if e['dst'].startswith('script:') and e['dst'] not in job_scripts:
                job_scripts.add(e['dst'])
                _stack.append(e['dst'])
    entry_java = {e['dst'] for e in out_e.get(jid, [])
                  if e['dst'].startswith('java:')}
    for s in job_scripts:
        entry_java |= {e['dst'] for e in out_e.get(s, [])
                       if e['dst'].startswith('java:')}
    for j in entry_java:
        for e in in_e.get(j, []):
            if e['src'].startswith('script:'):
                job_scripts.add(e['src'])
    return sorted(job_scripts)


def build_svg(unit, edges_by_src):
    """Layered dependency diagram: upstream jobs | this job | scripts/jars |
    Java files | DB objects | downstream jobs."""
    uid = unit['unit_id']
    jid = f'job:{uid}'
    out_e = defaultdict(list)
    in_e = defaultdict(list)
    for e in edges_by_src:
        out_e[e['src']].append(e)
        in_e[e['dst']].append(e)

    # F-G1: derive the layers from the unit's own (already pruned)
    # depends_on / likely_depends_on / likely_required_by lists — the
    # same lists the text sections use — not from graph edges. In --only
    # mode the pruned graph keeps 3-hop neighbourhood edges from pruned
    # units, so the edge-derived Downstream layer contradicted the doc's
    # own text section ("Downstream dependents: None"). Edges point
    # dependent -> dependency, so in the full graph these lists
    # correspond to the job's OUT-edges / IN-edges of kinds depends_on /
    # likely_depends_on.
    up = sorted(set(unit.get('depends_on', [])) |
                set(unit.get('likely_depends_on', [])))
    down = sorted(unit.get('likely_required_by', []))
    scripts = unit_scripts(jid, out_e, in_e)
    # R4-G7: jars shown are the unit's jars per §4.5 (job-command jars plus
    # jars from reachable scripts), not just job->jar graph edges — a jar
    # that comes only from a wrapper script (e.g. risk-dl.jar) has no
    # job->jar edge and would otherwise be omitted from this layer.
    jars = sorted(unit.get('jars', []))
    javas = [os.path.basename(p) for p in unit.get('entry_points', [])]
    dbs = unit.get('db_objects', [])

    def cap(items, n, label):
        items = list(items)
        if len(items) > n:
            return items[:n] + [f'+{len(items) - n} more {label}']
        return items

    # R5-G13: the Oracle layer used to render "NAME (kind)" and then
    # truncate the whole string to 26 chars, cutting off the kind — the
    # load-bearing part (e.g. RISK_CALC_PKG.CALC_EXPOSURE lost "(call)"
    # entirely). Kinds are abbreviated for the SVG, and the NAME part is
    # truncated to leave room for the abbreviated kind, so the kind is
    # always visible within the 26-char box width. The 26-char truncation
    # rule still applies as-is to every other layer.
    KIND_ABBR = {'write': 'w', 'read': 'r',
                 'write_via_script': 'w_vs', 'write_via_proc': 'w_vp',
                 'read_via_script': 'r_vs', 'read_via_proc': 'r_vp',
                 'call': 'call'}

    def _base_oracle_label(name, kind):
        suffix = f" ({KIND_ABBR.get(kind, kind)})"
        if len(name) + len(suffix) > 26:
            name = name[:26 - len(suffix) - 1] + '…'
        return name + suffix

    # R6-N3: two distinct (name, kind) pairs can truncate to the same
    # label (same prefix + same kind), which rendered two identical
    # Oracle boxes and misrouted the second table's java->db edge to
    # the first box. Labels are therefore computed once over the
    # rendered (first 10) db_objects; a colliding group is re-rendered
    # with a distinguishing tail — the head is shortened to fit the
    # last t characters of the name (t grows from 4 until the labels
    # in the group are distinct, head never below 1 char) — so each
    # box, and each edge, maps to the right object. Non-colliding
    # labels keep the base form above, unchanged.
    def _oracle_labels_for(objs):
        base = {}
        for d in objs:
            base.setdefault((d['name'], d['kind']),
                            _base_oracle_label(d['name'], d['kind']))
        groups = defaultdict(list)
        for key, lab in base.items():
            groups[lab].append(key)
        out = dict(base)
        for lab, keys in groups.items():
            if len(keys) < 2:
                continue
            # Same label implies the same kind suffix (the suffix is
            # never truncated), so one suffix serves the whole group.
            kind = keys[0][1]
            suffix = f" ({KIND_ABBR.get(kind, kind)})"
            budget = 26 - len(suffix)  # chars available for the name part
            chosen = None
            if budget >= 6:
                for t in range(4, budget - 1):
                    cand = {k: k[0][:budget - 1 - t] + '…' + k[0][-t:]
                            + suffix for k in keys}
                    if len(set(cand.values())) == len(keys):
                        chosen = cand
                        break
                if chosen is None:
                    # No tail length separates the group; keep the
                    # longest tail (1-char head) as the best effort.
                    t = budget - 2
                    chosen = {k: k[0][:budget - 1 - t] + '…' + k[0][-t:]
                              + suffix for k in keys}
            if chosen:
                out.update(chosen)
        return out

    _oracle_label_by_key = _oracle_labels_for(dbs[:10])

    def oracle_label(d):
        return _oracle_label_by_key.get(
            (d['name'], d['kind']),
            _base_oracle_label(d['name'], d['kind']))

    # R7-G13: the R6-N3 tail-distinguishing re-render existed only for
    # Oracle, but every other layer truncates the same way (short(item,
    # 26)) and find() matched on the truncated label, so two entry
    # points (or two upstream jobs) sharing their first 25 chars
    # rendered identical boxes and both edges targeted the first box.
    # _distinct_labels applies the same re-render to any layer's items:
    # non-colliding labels keep short(item, 26) unchanged; a colliding
    # group is re-rendered with a distinguishing tail — the head is
    # shortened to fit the last t characters of the item (t grows from
    # 4 until the labels in the group are distinct, head never below
    # 1 char). Oracle labels are already distinct (see above), so
    # passing them through here is a no-op. find() below keys on item
    # identity via display_for (full item -> its display label), never
    # on a truncated label.
    def _distinct_labels(items):
        base = [short(it, 26) for it in items]
        groups = defaultdict(list)
        for idx, lab in enumerate(base):
            groups[lab].append(idx)
        out = list(base)
        for lab, idxs in groups.items():
            if len(idxs) < 2:
                continue
            budget = 26
            chosen = None
            if budget >= 6:
                for t in range(4, budget - 1):
                    cand = {i: items[i][:budget - 1 - t] + '…'
                            + items[i][-t:] for i in idxs}
                    if len(set(cand.values())) == len(idxs):
                        chosen = cand
                        break
                if chosen is None:
                    # No tail length separates the group; keep the
                    # longest tail (1-char head) as the best effort.
                    t = budget - 2
                    chosen = {i: items[i][:budget - 1 - t] + '…'
                              + items[i][-t:] for i in idxs}
            if chosen:
                for i, lab2 in chosen.items():
                    out[i] = lab2
        return out

    _raw_layers = [
        ('Upstream', cap(up, 5, 'jobs'), '#dbeafe', '#1e40af'),
        ('This job', [uid], '#bfdbfe', '#1e3a8a'),
        ('Scripts / jars', cap([s.split(':')[-1].split('/')[-1] for s in scripts] +
                               [j.split(':')[-1] for j in jars], 6, 'items'),
         '#f3f4f6', '#374151'),
        ('Java', cap(javas, 6, 'files'), '#dcfce7', '#166534'),
        ('Oracle', cap([oracle_label(d) for d in dbs], 10, 'objects'),
         '#ffedd5', '#9a3412'),
        ('Downstream', cap(down, 5, 'jobs'), '#dbeafe', '#1e40af'),
    ]
    display_for = {}  # (layer title, full item) -> display label
    layers = []
    for _title, _items, _bg, _fg in _raw_layers:
        if not _items:
            continue
        _disp = _distinct_labels(_items)
        for _full, _lab in zip(_items, _disp):
            display_for.setdefault((_title, _full), _lab)
        layers.append((_title, _disp, _bg, _fg))
    if not layers:
        return ''
    W, NW, NH, GAP = 190, 172, 30, 12
    width = 20 + len(layers) * W
    height = 20 + max(len(items) for _, items, _, _ in layers) * (NH + GAP) + 30
    has_oracle = any(t == 'Oracle' for t, _, _, _ in layers)
    if has_oracle:
        height += 20  # room for the kind legend line below the boxes
    boxes = {}  # (layer_idx, item_idx) -> (x, y)
    parts = [f'<svg width="{width}" height="{height}" '
             f'viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg">',
             '<defs><marker id="ar" markerWidth="8" markerHeight="8" refX="7" '
             'refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="#64748b"/>'
             '</marker></defs>']
    for li, (title, items, bg, fg) in enumerate(layers):
        x = 20 + li * W
        parts.append(f'<text x="{x}" y="14" font-size="11" font-weight="700" '
                     f'fill="#64748b">{esc(title)}</text>')
        for ii, item in enumerate(items):
            y = 24 + ii * (NH + GAP)
            boxes[(li, ii)] = (x, y)
            parts.append(f'<rect x="{x}" y="{y}" width="{NW}" height="{NH}" '
                         f'rx="5" fill="{bg}" stroke="{fg}" stroke-opacity="0.4"/>')
            parts.append(f'<text x="{x + 8}" y="{y + 19}" font-size="11" '
                         f'fill="{fg}">{esc(short(item, 26))}</text>')
    # edges: upstream->job, job->scripts, job->jars, job->java,
    # script->java, java->db, job->downstream — every box in the
    # Scripts / jars layer and every Java box has at least one
    # incoming edge (R6-N2: the jar box used to be an unconnected
    # orphan and script->java was never drawn, although the old
    # comment claimed it). Loops run in the order above, over
    # already-sorted lists, so the SVG is deterministic.
    def line(a, b):
        ax, ay = boxes[a]
        bx, by = boxes[b]
        return (f'<line x1="{ax + NW}" y1="{ay + NH // 2}" x2="{bx}" '
                f'y2="{by + NH // 2}" stroke="#64748b" stroke-width="1.2" '
                f'marker-end="url(#ar)"/>')

    def find(layer_title, item):
        # R7-G13: key on item identity, never on a truncated label —
        # resolve the full item to its (distinct) display label first,
        # then match that label exactly. An item already given as its
        # display label (Oracle) matches via the identity default.
        disp = display_for.get((layer_title, item), item)
        for li, (title, items, _, _) in enumerate(layers):
            if title == layer_title:
                for ii, it in enumerate(items):
                    if it == disp:
                        return (li, ii)
        return None
    edges_svg = []
    for u in up[:5]:
        a, b = find('Upstream', u), find('This job', uid)
        if a and b:
            edges_svg.append(line(a, b))
    for s in scripts:
        a, b = find('This job', uid), find('Scripts / jars', s.split(':')[-1].split('/')[-1])
        if a and b:
            edges_svg.append(line(a, b))
    for j in jars:
        # R6-N2: job->jar — jars share the Scripts / jars layer with
        # the scripts, displayed as j.split(':')[-1] (same expression
        # as the layer construction above).
        a, b = find('This job', uid), find('Scripts / jars', j.split(':')[-1])
        if a and b:
            edges_svg.append(line(a, b))
    for j in javas[:6]:
        a = find('This job', uid)
        b = find('Java', j)
        if a and b:
            edges_svg.append(line(a, b))
    # R6-N2: script->java — from each script box to every Java class
    # the script invokes (graph script->java edges), resolved to the
    # Java layer by class basename + '.java'. Deduplicated: one line
    # per (script box, Java box) pair.
    _seen_script_java = set()
    for s in scripts:
        s_box = find('Scripts / jars', s.split(':')[-1].split('/')[-1])
        if not s_box:
            continue
        for e in sorted(out_e.get(s, []), key=lambda e: e['dst']):
            if not e['dst'].startswith('java:'):
                continue
            j_box = find('Java', e['dst'][len('java:'):].rsplit('.', 1)[-1]
                         + '.java')
            if j_box and (s_box, j_box) not in _seen_script_java:
                _seen_script_java.add((s_box, j_box))
                edges_svg.append(line(s_box, j_box))
    for d in dbs[:10]:
        a = find('Java', javas[0]) if javas else find('This job', uid)
        b = find('Oracle', oracle_label(d))
        if a and b:
            edges_svg.append(line(a, b))
    for dn in down[:5]:
        a, b = find('This job', uid), find('Downstream', dn)
        if a and b:
            edges_svg.append(line(a, b))
    parts = parts[:2] + edges_svg + parts[2:]
    if has_oracle:
        parts.append(f'<text x="20" y="{height - 8}" font-size="11" '
                     f'fill="#64748b">Oracle kinds: w=write, r=read, '
                     f'w_vs=write_via_script, w_vp=write_via_proc, '
                     f'r_vs=read_via_script, r_vp=read_via_proc, '
                     f'call=call</text>')
    parts.append('</svg>')
    return ''.join(parts)


def render(unit, verdict, graph, java_recs, units=None):
    uid = unit['unit_id']
    pre = unit.get('preclassification') or {}
    label = pre.get('label', 'UNLABELLED')
    label_cls = {'DB_HEAVY': 'b-db', 'JAVA_HEAVY': 'b-java',
                 'BALANCED': 'b-bal', 'NEEDS_REVIEW': 'b-review'}.get(label, 'b-unknown')
    link = unit.get('linkage', 'missing')
    link_cls = {'ok': 'b-ok', 'maybe': 'b-maybe', 'missing': 'b-missing'}[link]
    badges = [f'<span class="badge {label_cls}">{esc(label)}</span>',
              f'<span class="badge {link_cls}">linkage: {esc(link)}</span>']
    if unit.get('synthetic'):
        badges.append('<span class="badge b-synth">synthetic — in code, not in Autosys</span>')
    if verdict:
        badges.append(f'<span class="badge b-bal">reviewed: '
                      f'{esc(verdict.get("verdict", "?"))} '
                      f'({esc(verdict.get("confidence", "?"))})</span>')

    summary, is_draft = describe(unit, verdict)
    desc_html = ''.join(f'<p>{esc(s)}</p>' for s in summary)
    if is_draft:
        desc_html = ('<div class="draft"><strong>DRAFT description</strong> — '
                     'auto-generated from code evidence; not yet human-reviewed.'
                     '</div>' + desc_html)
    m = unit.get('metrics', {})
    facts = [
        f"Command: <code>{esc(unit.get('command') or '(none)')}</code>",
        f"Schedule: {esc(unit.get('schedule') or '(none)')}",
        f"Entry points: {esc(', '.join(unit.get('entry_points') or ['(none)']))}",
        f"Java files: {unit.get('java_file_count', 0)} "
        f"({m.get('loc', 0)} LOC, {m.get('branches', 0)} branches, "
        f"{m.get('methods', 0)} methods, {m.get('sql_literals', 0)} SQL literals, "
        f"{m.get('jdbc_sites', 0)} JDBC sites, {m.get('proc_calls', 0)} proc calls)",
        f"Repos: {esc(', '.join(unit.get('repos', [])) or '(none)')}",
        f"Jars: {esc(', '.join(unit.get('jars', [])) or '(none)')}",
        f"Oracle dialect features: {esc(', '.join(f'{k}×{v}' for k, v in unit.get('oracle_isms', {}).items())) or '(none)'}",
    ]
    if unit.get('linkage_candidates'):
        facts.append(f"Linkage candidates (confirm during review): "
                     f"{esc(', '.join(unit['linkage_candidates']))}")
    facts_html = ''.join(f'<li>{f}</li>' for f in facts)

    # dependency chain: job -> scripts/jars -> java -> oracle
    g_edges = graph.get('edges', []) if graph else []
    out_e = defaultdict(list)
    in_e = defaultdict(list)
    for e in g_edges:
        out_e[e['src']].append(e)
        in_e[e['dst']].append(e)
    jid = f'job:{uid}'
    chain = [f'Autosys job <strong>{esc(uid)}</strong>']
    scripts = unit_scripts(jid, out_e, in_e)
    # R4-G7: same source as the SVG layer — unit['jars'] per §4.5
    # (job-command jars plus jars from reachable scripts).
    jars = sorted(unit.get('jars', []))
    for s in scripts:
        chain.append(f'script <code>{esc(s.split(":", 1)[1])}</code>')
    for j in jars:
        chain.append(f'jar <code>{esc(j)}</code>')
    for p in unit.get('entry_points', []):
        chain.append(f'Java <code>{esc(p)}</code>')
    for d in unit.get('db_objects', []):
        chain.append(f"Oracle {esc(d['kind'])} <code>{esc(d['name'])}</code>")
    chain_html = (' <span class="arr">→</span> '.join(chain) if len(chain) > 1
                  else chain[0])

    def io_table(pred):
        rows = []
        for d in unit.get('db_objects', []):
            if pred(d):
                cols_r = ', '.join(d.get('columns_read', []))
                cols_w = ', '.join(d.get('columns_written', []))
                rows.append(f"<tr><td><code>{esc(d['name'])}</code></td>"
                            f"<td>{esc(d['kind'])}</td>"
                            f"<td>{esc(cols_r) or '—'}</td>"
                            f"<td>{esc(cols_w) or '—'}</td></tr>")
        if not rows:
            return '<p class="note">None.</p>'
        return ('<table><tr><th>Table</th><th>Kind</th><th>Columns read</th>'
                '<th>Columns written</th></tr>' + ''.join(rows) + '</table>')

    reads = io_table(_is_read)
    writes = io_table(_is_write)
    calls = [d['name'] for d in unit.get('db_objects', []) if d['kind'] == 'call']
    calls_html = ('<ul>' + ''.join(f'<li><code>{esc(c)}</code></li>' for c in calls) + '</ul>'
                  if calls else '<p class="note">None.</p>')

    up = sorted(set(unit.get('depends_on', [])) |
                set(unit.get('likely_depends_on', [])))
    if up:
        items = []
        for u in up:
            tags = []
            if u in unit.get('depends_on', []):
                tags.append('scheduler')
            if u in unit.get('likely_depends_on', []):
                via = sorted({t for e in g_edges
                              if e['kind'] == 'likely_depends_on'
                              and e['src'] == jid
                              and e['dst'] == 'job:' + u
                              for t in e.get('via', [])})
                # R4-N2: with no --graph there are no edges, so via is
                # empty — render '(inferred)' alone, never '(inferred via )'.
                tags.append('inferred via ' + ', '.join(via) if via
                            else 'inferred')
            items.append(f"<li><code>{esc(u)}</code>"
                         + (f" ({'; '.join(tags)})" if tags else '') + '</li>')
        up_html = '<ul>' + ''.join(items) + '</ul>'
    else:
        up_html = '<p class="note">None.</p>'
    down = unit.get('likely_required_by', [])
    down_html = ('<ul>' + ''.join(f'<li><code>{esc(d)}</code> (inferred)</li>'
                                  for d in down) + '</ul>'
                 if down else '<p class="note">None.</p>')
    parents = unit.get('parent_jobs', [])
    parent_html = (f"<p>Parent job(s): {esc(', '.join(parents))}</p>"
                   if parents else '')

    # Java-to-Java: imports of entry files that resolve to other units
    java_html = '<p class="note">No Java import data available.</p>'
    if java_recs:
        fqn_index = {}
        for rec in java_recs:
            for cls in rec['classes']:
                fqn = f"{rec['package']}.{cls}" if rec['package'] else cls
                fqn_index[fqn] = rec
        path_to_unit = {}
        # R-G1: a file shared by several units (e.g. DbUtil.java in both
        # the nightly job and its wrapper script's job) resolves to the
        # CURRENT unit first — populating in list order misattributed the
        # doc's own file to whichever unit came last in units.json.
        for u in (units if units is not None else [unit]):
            if u.get('unit_id') == unit.get('unit_id'):
                continue
            for jf in u.get('java_files', []):
                path_to_unit[jf['path']] = u['unit_id']
        for jf in unit.get('java_files', []):
            path_to_unit[jf['path']] = unit['unit_id']
        rows = []
        for p in unit.get('entry_points', []):
            rec = next((r for r in java_recs if r['path'] == p), None)
            if not rec:
                continue
            for imp in rec.get('imports', []):
                owner = None
                if imp in fqn_index:
                    owner = path_to_unit.get(fqn_index[imp]['path'])
                rows.append(f"<tr><td><code>{esc(p.split('/')[-1])}</code></td>"
                            f"<td><code>{esc(imp)}</code></td>"
                            f"<td>{esc(owner) if owner else '(external / shared lib)'}</td></tr>")
        if rows:
            java_html = ('<table><tr><th>From file</th><th>Imports</th>'
                         '<th>Owning process</th></tr>' + ''.join(rows) + '</table>')

    # Oracle-to-Oracle: what the called procs themselves call / touch
    ora_rows = []
    db_edges = defaultdict(list)
    for e in g_edges:
        if e['src'].startswith('db:'):
            db_edges[e['src']].append(e)
    for c in calls:
        # proc edges are keyed by package (db:RISK_CALC_PKG) as well as by
        # the full procedure name; try both
        keys = [f'db:{c}']
        if '.' in c:
            keys.append(f"db:{c.rsplit('.', 1)[0]}")
        for key in keys:
            for e in db_edges.get(key, []):
                ora_rows.append(f"<tr><td><code>{esc(c)}</code></td>"
                                f"<td>{esc(e['kind'])}</td>"
                                f"<td><code>{esc(e['dst'][3:])}</code></td></tr>")
    ora_html = ('<table><tr><th>Procedure</th><th>Relation</th><th>Target</th></tr>'
                + ''.join(ora_rows) + '</table>') if ora_rows else \
        '<p class="note">No Oracle-to-Oracle edges found for the called procedures.</p>'

    review_html = ''
    if verdict:
        review_html = f"""
<h2>Review</h2>
<p>Verdict: <strong>{esc(verdict.get('verdict', '?'))}</strong>
(confidence: {esc(verdict.get('confidence', '?'))},
agrees with pre-classification: {esc(verdict.get('agree_with_preclassification', '?'))})</p>
<h3>Migration notes</h3>
<ul>{''.join(f'<li>{esc(n)}</li>' for n in verdict.get('migration_notes', [])) or '<li>(none)</li>'}</ul>
<h3>Human review flags</h3>
<ul>{''.join(f'<li>{esc(n)}</li>' for n in verdict.get('human_review_flags', [])) or '<li>(none)</li>'}</ul>
<h3>Evidence gaps</h3>
<ul>{''.join(f'<li>{esc(n)}</li>' for n in verdict.get('evidence_gaps', [])) or '<li>(none)</li>'}</ul>"""
    elif unit.get('columns_unattributed'):
        review_html = (f"<h2>Review</h2><p class=\"note\">Not yet reviewed. "
                       f"Unattributed columns (heuristic extraction could not "
                       f"assign them to a table): "
                       f"{esc(', '.join(unit['columns_unattributed']))}</p>")
    else:
        review_html = '<h2>Review</h2><p class="note">Not yet reviewed.</p>'

    svg = build_svg(unit, g_edges)
    svg_html = f'<h2>Dependency diagram</h2>{svg}' if svg else ''

    files_html = ''.join(
        f"<li><code>{esc(f['path'])}</code> ({esc(f['repo'])}): "
        f"{esc(', '.join(f['classes']))}</li>"
        for f in unit.get('java_files', []))

    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<title>{esc(uid)} — process dependency document</title>
<style>{CSS}</style></head>
<body>
<h1>{esc(uid)}</h1>
<p>{''.join(badges)}</p>
<h2>What this process does</h2>
{desc_html}
<ul>{facts_html}</ul>
<h2>Dependency chain</h2>
<div class="chain">{chain_html}</div>
<h2>Inputs</h2>
{reads}
<h2>Outputs</h2>
{writes}
<h2>Stored procedures called</h2>
{calls_html}
<h2>Upstream dependencies</h2>
{parent_html}
{up_html}
<h2>Downstream dependents</h2>
{down_html}
<h2>Java-to-Java dependencies</h2>
{java_html}
<h2>Oracle-to-Oracle dependencies</h2>
{ora_html}
{svg_html}
{review_html}
<h2>Source files in this process</h2>
<ul>{files_html or '<li>(none)</li>'}</ul>
<p class="note">Generated by the migration analysis kit. Column lists are
best-effort heuristic extraction; review before relying on them for
translation. Dependency edges marked "inferred" are writer→reader
heuristics, not scheduler facts.</p>
</body></html>"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--units', required=True)
    ap.add_argument('--graph', default='')
    ap.add_argument('--java', default='')
    ap.add_argument('--verdicts', default='')
    ap.add_argument('--only', default='',
                    help='comma-separated unit IDs to document (default: all)')
    ap.add_argument('--outdir', required=True)
    a = ap.parse_args()
    units = load(a.units, [])
    graph = load(a.graph, {})
    java_recs = load(a.java, [])
    verdicts = load_verdicts(a.verdicts)
    only = {s.strip() for s in a.only.split(',') if s.strip()}
    all_units = units  # G15: Java-to-Java owning processes resolve against
    # ALL units, even when --only documents a subset
    if only:
        units = [u for u in units if u['unit_id'] in only]
        # F-G1/F-N6: the rendered units' likely_* lists are pruned to the
        # selected set (the same pruning build_graph.py --only applies), so
        # the doc — text sections and SVG alike — reflects the run's scope
        # even when --units is the UNFILTERED file (as run_process.py
        # passes it, so Java-to-Java resolution still sees every unit).
        # depends_on is NOT pruned: scheduler deps (FEED_LANDED, ...)
        # are conditions, not units, and belong in the Upstream layer.
        for u in units:
            u['likely_depends_on'] = [d for d in
                                      u.get('likely_depends_on', [])
                                      if d in only]
            u['likely_required_by'] = [d for d in
                                       u.get('likely_required_by', [])
                                       if d in only]
    os.makedirs(a.outdir, exist_ok=True)
    index_rows = []
    for unit in units:
        uid = unit['unit_id']
        v = verdicts.get(uid)
        out = os.path.join(a.outdir, sanitize(uid) + '.html')
        with open(out, 'w', encoding='utf-8') as f:
            f.write(render(unit, v, graph, java_recs, all_units))
        pre = (unit.get('preclassification') or {}).get('label', '')
        index_rows.append(
            f'<tr><td><a href="{sanitize(uid)}.html">{esc(uid)}</a></td>'
            f'<td>{esc(pre)}</td>'
            f'<td>{esc(v.get("verdict", "") if v else "")}</td>'
            f'<td>{esc(unit.get("linkage", ""))}</td></tr>')
    with open(os.path.join(a.outdir, 'index.html'), 'w', encoding='utf-8') as f:
        f.write(f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>Process dependency documents</title><style>{CSS}</style></head>
<body><h1>Process dependency documents</h1>
<p>{len(units)} processes.</p>
<table><tr><th>Process</th><th>Pre-classification</th><th>Review verdict</th>
<th>Linkage</th></tr>{''.join(index_rows)}</table></body></html>""")
    print(f'wrote {len(units)} process documents + index -> {a.outdir}')


if __name__ == '__main__':
    main()
