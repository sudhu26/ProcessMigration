#!/usr/bin/env python3
"""Shared ignore-list handling for the migration kit.

System-level Java libraries and Oracle packages that exist on-premise but
will never exist on Azure are noise: no point tracing their dependencies or
converting their calls. An ignore file is JSON:

    {"java_imports": ["^oracle\\.", "^weblogic\\."],
     "oracle_objects": ["^DBMS_.*", "^UTL_.*", "^V\\$.*"]}

Patterns are regexes, matched with re.search against the full name
(imports as written, Oracle names uppercased). Ignored items are excluded
from dependency tracing and from conversion flagging, but every script
records what it ignored (ignored_* fields) so the decision stays auditable.
Stdlib only.
"""
import json, os, re


class IgnoreList:
    def __init__(self, java_imports=(), oracle_objects=()):
        self.java_imports = [re.compile(p, re.IGNORECASE) for p in java_imports]
        self.oracle_objects = [re.compile(p, re.IGNORECASE)
                               for p in oracle_objects]

    def __bool__(self):
        return bool(self.java_imports or self.oracle_objects)

    def ignore_import(self, name):
        return any(p.search(name) for p in self.java_imports)

    def ignore_object(self, name):
        return any(p.search(name) for p in self.oracle_objects)


def load_ignore(path):
    """Load an ignore JSON file; missing/empty path -> empty IgnoreList."""
    if not path or not os.path.exists(path):
        return IgnoreList()
    with open(path, encoding='utf-8') as f:
        data = json.load(f)
    return IgnoreList(data.get('java_imports', []),
                      data.get('oracle_objects', []))


def split_kept_ignored(names, predicate):
    """Partition an iterable of names into (kept, ignored) sorted lists."""
    kept, ignored = [], []
    for n in names:
        (ignored if predicate(n) else kept).append(n)
    return sorted(kept), sorted(ignored)


def split_kept_ignored_ordered(names, predicate):
    """Partition an iterable of names into (kept, ignored), each in input
    order (no sorting). Used where source order is part of the output
    contract (Java imports, R4-G3); tables/procs stay sorted via
    split_kept_ignored."""
    kept, ignored = [], []
    for n in names:
        (ignored if predicate(n) else kept).append(n)
    return kept, ignored
