package com.risk.edge;

/** Nested-WHERE / scalar-subquery `*` rule (R7-G1 output-tables rule,
 *  new assertion 43): a derived table's output tables are its
 *  FROM-clause tables (recursed) PLUS, for each parenthesised
 *  subquery in its SELECT list, that subquery's output tables; a
 *  WHERE subquery's tables NEVER count, at any depth. Kept in its
 *  own file (not folded into StarRule.java): StarRule's first
 *  statement already puts `*` under T1, which would mask the
 *  nested-WHERE outcome, and the scalar shape's T2 'C' is already
 *  present there via the subquery recursion — neither shape would
 *  discriminate the old rule from the new one in that file.
 *  Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (StarRuleNested.java record): tables_read ['T1', 'T2'],
 *  table_columns {'T1': {'read': ['*', 'A'], 'write': []},
 *                   'T2': {'read': ['C', 'Y'], 'write': []}},
 *  columns_unattributed [] — the first statement keeps `*` under T1
 *  (the WHERE subquery nested inside the derived table does not
 *  count); the second drops `*` (its output column comes from T2
 *  via the SELECT-list scalar subquery), leaving only T2 'C'. */
public class StarRuleNested {

    public void run(java.sql.Statement st) throws Exception {
        String nestedWhereInDerived =
                "SELECT * FROM (SELECT a FROM t1 WHERE x IN (SELECT y FROM t2)) x";
        st.executeQuery(nestedWhereInDerived);

        String scalarInDerived =
                "SELECT * FROM (SELECT (SELECT MAX(c) FROM t2) FROM t1) x";
        st.executeQuery(scalarInDerived);
    }
}
