package com.risk.jobs;

import com.bank.cloud.AdlsWriter;

public class SimpleWriter {
    public void run() {
        AdlsWriter writer = new AdlsWriter("risk_results");
        writer.write("INSERT INTO risk_results (as_of_date) VALUES (current_timestamp())");
    }
}
