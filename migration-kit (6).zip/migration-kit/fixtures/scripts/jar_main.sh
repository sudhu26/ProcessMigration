#!/bin/ksh
# -jar terminal regression (R7-G9): a class after `-jar <jar>` is an
# argument to the jar's main(), not the main class; a real main on a
# later line is still kept.
# Scanned with: scan_scripts.py --root fixtures/scripts --repo Scripts
# Expected (jar_main.sh record): java_mains ['com.foo.Real'],
# jars ['app.jar', 'lib.jar'].
java -jar app.jar com.foo.Bar
java -cp lib.jar com.foo.Real
