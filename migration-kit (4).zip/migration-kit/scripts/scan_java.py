#!/usr/bin/env python3
"""Scan Java sources for JDBC usage, embedded SQL, stored-proc calls,
Oracle-dialect features, and inter-file dependencies. Stdlib only.

Usage: scan_java.py --root <repo_root> --repo <repo_name> --out <out.json>
"""
import argparse, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ignore_lists import load_ignore, split_kept_ignored  # noqa: E402

SQL_KEYWORDS = re.compile(
    r'\b(SELECT|INSERT\s+INTO|INSERT|UPDATE|DELETE\s+FROM|DELETE|MERGE\s+INTO|MERGE|'
    r'WITH|TRUNCATE|CALL|CREATE|DROP|ALTER)\b', re.IGNORECASE)

TABLE_PATTERNS = [
    (re.compile(r'\bFROM\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
    (re.compile(r'\bJOIN\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
    (re.compile(r'\bINTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
    (re.compile(r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET', re.IGNORECASE), 'write'),
    (re.compile(r'\bMERGE\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
    (re.compile(r'\bTABLE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'read'),
]

PROC_CALL = re.compile(r'\{\s*call\s+([A-Za-z_][\w$.]*)\s*\(?', re.IGNORECASE)
PREPCALL = re.compile(r'prepareCall\s*\(\s*"([^"]+)"', re.IGNORECASE)

JDBC_SIGNALS = {
    'getConnection': re.compile(r'\bgetConnection\s*\('),
    'prepareStatement': re.compile(r'\bprepareStatement\s*\('),
    'prepareCall': re.compile(r'\bprepareCall\s*\('),
    'createStatement': re.compile(r'\bcreateStatement\s*\('),
    'executeQuery': re.compile(r'\bexecuteQuery\s*\('),
    'executeUpdate': re.compile(r'\bexecuteUpdate\s*\('),
    'executeBatch': re.compile(r'\bexecuteBatch\s*\('),
    'addBatch': re.compile(r'\baddBatch\s*\('),
    'setAutoCommit': re.compile(r'\bsetAutoCommit\s*\('),
    'commit': re.compile(r'\bcommit\s*\(\s*\)'),
    'rollback': re.compile(r'\brollback\s*\('),
    'setSavepoint': re.compile(r'\b(SetSavepoint|setSavepoint)\s*\('),
}

ORACLE_ISMS = {
    'ROWNUM': re.compile(r'\bROWNUM\b', re.IGNORECASE),
    'SYSDATE_SYSTIMESTAMP': re.compile(r'\b(SYSDATE|SYSTIMESTAMP|CURRENT_DATE)\b', re.IGNORECASE),
    'DUAL': re.compile(r'\bFROM\s+DUAL\b', re.IGNORECASE),
    'NVL': re.compile(r'\bNVL[2]?\s*\(', re.IGNORECASE),
    'DECODE': re.compile(r'\bDECODE\s*\(', re.IGNORECASE),
    'OLD_JOIN_OP': re.compile(r'\(\+\)'),
    'CONNECT_BY': re.compile(r'\b(CONNECT\s+BY|START\s+WITH)\b', re.IGNORECASE),
    'SEQUENCE': re.compile(r'\bNEXTVAL\b|\bCURRVAL\b', re.IGNORECASE),
    'FOR_UPDATE': re.compile(r'\bFOR\s+UPDATE\b', re.IGNORECASE),
    'HINT': re.compile(r'/\*\+'),
    'MODEL_CLAUSE': re.compile(r'\bMODEL\b', re.IGNORECASE),
    'PIVOT': re.compile(r'\bPIVOT\b', re.IGNORECASE),
}

STRING_RE = re.compile(r'"(?:\\.|[^"\\])*"')
TEXTBLOCK_RE = re.compile(r'"""(.*?)"""', re.DOTALL)
LINE_COMMENT = re.compile(r'//.*?$', re.MULTILINE)
BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
PACKAGE_RE = re.compile(r'^\s*package\s+([\w.]+)\s*;', re.MULTILINE)
IMPORT_RE = re.compile(r'^\s*import\s+(static\s+)?([\w.*]+)\s*;', re.MULTILINE)
CLASS_RE = re.compile(r'\b(public\s+|protected\s+|private\s+)?(class|interface|enum|record)\s+(\w+)')
METHOD_RE = re.compile(r'\b(public|protected|private|static|\s)+\s*[\w<>\[\]]+\s+(\w+)\s*\([^;{}]*\)\s*(throws\s+[\w,\s]+)?\{')
BRANCH_RE = re.compile(r'\b(if|for|while|switch|catch|case)\b')


def strip_comments(text):
    text = BLOCK_COMMENT.sub('', text)
    text = LINE_COMMENT.sub('', text)
    return text


# --- column extraction (best-effort heuristic; mirrored in scan_plsql.py) ---
_SQL_KW = {'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'AS', 'ON', 'JOIN', 'LEFT',
           'RIGHT', 'INNER', 'OUTER', 'FULL', 'CROSS', 'GROUP', 'ORDER', 'BY',
           'HAVING', 'INTO', 'VALUES', 'SET', 'INSERT', 'UPDATE', 'DELETE',
           'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT', 'UNION', 'ALL',
           'NOT', 'NULL', 'IS', 'IN', 'LIKE', 'BETWEEN', 'EXISTS', 'WITH',
           'MERGE', 'DUAL', 'TABLE', 'SYSDATE', 'SYSTIMESTAMP',
           'CURRENT_DATE', 'ROWNUM'}


def split_top_commas(s):
    parts, depth, cur = [], 0, ''
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        if ch == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return parts


def _col_refs(item):
    """Column refs in a SELECT-list item: [(prefix|None, name)].
    Function names (identifier directly followed by '(') and keywords skipped."""
    out = []
    for m in re.finditer(r'([A-Za-z_][\w$]*)(?:\.([A-Za-z_][\w$]*))?', item):
        a, b = m.group(1), m.group(2)
        if m.end() < len(item) and item[m.end()] == '(':
            continue
        if a.upper() in _SQL_KW:
            continue
        if b:
            if b.upper() in _SQL_KW:
                continue
            out.append((a.upper(), b.upper()))
        else:
            out.append((None, a.upper()))
    return out


def _top_level_from(sql):
    """(select_list, from_clause) for a SELECT, using the first top-level
    FROM; None when no SELECT...FROM found."""
    m = re.search(r'\bSELECT\b', sql, re.I)
    if not m:
        return None
    depth, i, from_at = 0, m.end(), None
    while i < len(sql):
        ch = sql[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and sql[i:i + 4].upper() == 'FROM' and \
                (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == '_')) and \
                (i + 4 >= len(sql) or not (sql[i + 4].isalnum() or sql[i + 4] == '_')):
            from_at = i
            break
        i += 1
    if from_at is None:
        return None
    rest = sql[from_at + 4:]
    end = len(rest)
    for kw in ('WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'MINUS', 'INTERSECT'):
        mm = re.search(r'\b' + kw + r'\b', rest, re.I)
        if mm:
            end = min(end, mm.start())
    return sql[m.end():from_at], sql[from_at:from_at + 4 + end]


def _subqueries(sql):
    """Inner SELECT statements inside parentheses (derived tables)."""
    out = []
    for m in re.finditer(r'\(\s*SELECT\b', sql, re.I):
        depth, i = 0, m.start()
        while i < len(sql):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
                if depth == 0:
                    out.append(sql[m.start() + 1:i])
                    break
            i += 1
    return out


def _from_tables(from_clause):
    """[(table, alias|None)] from a FROM/JOIN clause."""
    out = []
    for m in re.finditer(
            r'\b(?:FROM|JOIN)\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)'
            r'\s*(?:AS\s+)?([A-Za-z_][\w$]*)?', from_clause, re.I):
        alias = m.group(2)
        if alias and alias.upper() in _SQL_KW:
            alias = None
        out.append((m.group(1).upper(), alias.upper() if alias else None))
    return out


def extract_table_columns(sql):
    """Best-effort per-table column usage from one SQL statement.
    Returns ({table: {'read': set, 'write': set}}, unattributed set).
    INSERT/UPDATE columns are exact; SELECT columns are attributed via
    table prefixes/aliases, or to the single FROM table when unambiguous."""
    from collections import defaultdict
    cols = defaultdict(lambda: {'read': set(), 'write': set()})
    unatt = set()
    one = ' '.join(sql.split())
    for m in re.finditer(
            r'\bINSERT\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)'
            r'\s*\(([^)]*)\)', one, re.I):
        for c in m.group(2).split(','):
            c = c.strip().strip('"').upper()
            if c:
                cols[m.group(1).upper()]['write'].add(c)
    for m in re.finditer(
            r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET\s+'
            r'(.*?)(?:\bWHERE\b|;|$)', one, re.I | re.S):
        for part in split_top_commas(m.group(2)):
            cm = re.match(r'\s*"?([A-Za-z_][\w$]*)"?\s*=', part)
            if cm:
                cols[m.group(1).upper()]['write'].add(cm.group(1).upper())
    parsed = _top_level_from(one)
    if parsed:
        select_list, from_clause = parsed
        # PL/SQL SELECT ... INTO var: the target is not a column
        select_list = re.sub(r'\bINTO\s+[A-Za-z_][\w$]*', '', select_list,
                             flags=re.I)
        tables = _from_tables(from_clause)
        alias_map = {}
        for t, al in tables:
            alias_map[t] = t
            if al:
                alias_map[al] = t
        single = tables[0][0] if len(tables) == 1 else None
        for item in split_top_commas(select_list):
            item = re.sub(r'\bAS\s+[A-Za-z_][\w$]*', '', item,
                          flags=re.I).strip()
            # implicit alias: "SUM(x) E" / "BOOK b" -> "SUM(x)" / "BOOK"
            m_alias = re.match(r'^(.*\))\s+[A-Za-z_][\w$]*$', item)
            if m_alias:
                item = m_alias.group(1)
            else:
                m_alias2 = re.match(
                    r'^([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)?)\s+'
                    r'[A-Za-z_][\w$]*$', item)
                if m_alias2:
                    item = m_alias2.group(1)
            if item == '*':
                if single:
                    cols[single]['read'].add('*')
                continue
            for prefix, name in _col_refs(item):
                if prefix:
                    t = alias_map.get(prefix)
                    if t:
                        cols[t]['read'].add(name)
                    else:
                        unatt.add(f'{prefix}.{name}')
                elif single:
                    cols[single]['read'].add(name)
                else:
                    unatt.add(name)
    # recurse into derived-table subqueries (SELECT * FROM (SELECT ...))
    for sub in _subqueries(one):
        tc2, un2 = extract_table_columns(sub)
        for t, kinds in tc2.items():
            cols[t]['read'].update(kinds['read'])
            cols[t]['write'].update(kinds['write'])
        unatt.update(un2)
    return cols, unatt


def extract_literals(text):
    """Extract string literals, merging ones concatenated with + (the usual
    Java SQL-building pattern), replacing injected variables with ?."""
    spans = []
    for m in TEXTBLOCK_RE.finditer(text):
        spans.append((m.start(), m.end(), m.group(1)))
    tmp = TEXTBLOCK_RE.sub('""', text)
    for m in STRING_RE.finditer(tmp):
        raw = m.group(0)[1:-1]
        try:
            val = bytes(raw, 'utf-8').decode('unicode_escape')
        except Exception:
            val = raw
        spans.append((m.start(), m.end(), val))
    spans.sort()
    between = re.compile(r'^\s*\+\s*(?:[A-Za-z_][\w$.]*(?:\([^)]*\))?\s*\+\s*)?$')
    merged, cur = [], None
    for s, e, val in spans:
        if cur and between.match(text[cur[1]:s]):
            cur = (cur[0], e, cur[2] + ' ? ' + val)
        else:
            if cur:
                merged.append(cur[2])
            cur = (s, e, val)
    if cur:
        merged.append(cur[2])
    return merged


def analyze_file(path, repo, ignore=None):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except OSError:
        return None
    literals = extract_literals(text)
    code = strip_comments(TEXTBLOCK_RE.sub('""', STRING_RE.sub('""', text)))

    pkg = PACKAGE_RE.search(code)
    package = pkg.group(1) if pkg else ''
    imports, ignored_imports = split_kept_ignored(
        [m.group(2) for m in IMPORT_RE.finditer(code)],
        ignore.ignore_import) if ignore else (
        [m.group(2) for m in IMPORT_RE.finditer(code)], [])
    classes = [m.group(3) for m in CLASS_RE.finditer(code)]

    jdbc = {name: len(pat.findall(code)) for name, pat in JDBC_SIGNALS.items()}

    sql_lits = [l for l in literals if SQL_KEYWORDS.search(l)]
    reads, writes, procs = set(), set(), set()
    for lit in sql_lits:
        one = ' '.join(lit.split())
        for pat, kind in TABLE_PATTERNS:
            for m in pat.finditer(one):
                name = m.group(1).upper()
                if name in ('DUAL',):
                    continue
                (writes if kind == 'write' else reads).add(name)
        for m in PROC_CALL.finditer(one):
            procs.add(m.group(1).upper())
    for m in PREPCALL.finditer(code):
        procs.add(re.sub(r'[\s{(]', '', m.group(1)).upper().rstrip(')'))
    if ignore:
        reads, ignored_reads = split_kept_ignored(reads, ignore.ignore_object)
        writes, ignored_writes = split_kept_ignored(writes, ignore.ignore_object)
        procs, ignored_procs = split_kept_ignored(procs, ignore.ignore_object)
    else:
        ignored_reads = ignored_writes = ignored_procs = []

    isms = {name: len(pat.findall(' '.join(sql_lits))) for name, pat in ORACLE_ISMS.items()}
    isms = {k: v for k, v in isms.items() if v}

    table_columns = {}
    unattributed = set()
    for lit in sql_lits:
        tc, un = extract_table_columns(lit)
        for t, kinds in tc.items():
            entry = table_columns.setdefault(t, {'read': set(), 'write': set()})
            entry['read'].update(kinds['read'])
            entry['write'].update(kinds['write'])
        unattributed.update(un)
    if ignore:
        ignored_cols = {t: v for t, v in table_columns.items()
                        if ignore.ignore_object(t)}
        table_columns = {t: v for t, v in table_columns.items()
                         if not ignore.ignore_object(t)}
    else:
        ignored_cols = {}

    loc = sum(1 for ln in code.splitlines() if ln.strip())
    branches = len(BRANCH_RE.findall(code))
    methods = len(METHOD_RE.findall(code))
    has_main = bool(re.search(r'public\s+static\s+void\s+main\s*\(', code))

    return {
        'path': path, 'repo': repo, 'package': package,
        'classes': classes, 'imports': imports,
        'jdbc': {k: v for k, v in jdbc.items() if v},
        'sql_literal_count': len(sql_lits),
        'sql_sample': [' '.join(l.split())[:300] for l in sql_lits[:10]],
        'tables_read': sorted(reads), 'tables_written': sorted(writes),
        'ignored_tables': sorted(set(ignored_reads) | set(ignored_writes)),
        'ignored_procs': ignored_procs,
        'ignored_imports': ignored_imports,
        'ignored_table_columns': {t: {'read': sorted(v['read']),
                                      'write': sorted(v['write'])}
                                  for t, v in sorted(ignored_cols.items())},
        'table_columns': {t: {'read': sorted(v['read']), 'write': sorted(v['write'])}
                          for t, v in sorted(table_columns.items())},
        'columns_unattributed': sorted(unattributed),
        'procs_called': sorted(procs),
        'oracle_isms': isms,
        'metrics': {'loc': loc, 'branches': branches,
                    'methods_rough': methods, 'has_main': has_main},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--repo', required=True)
    ap.add_argument('--ignore', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    ignore = load_ignore(a.ignore)
    records = []
    for dirpath, _, filenames in os.walk(a.root):
        for fn in filenames:
            if fn.endswith('.java'):
                rec = analyze_file(os.path.join(dirpath, fn), a.repo, ignore)
                if rec:
                    records.append(rec)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=1)
    print(f'scanned {len(records)} java files -> {a.out}')


if __name__ == '__main__':
    main()
