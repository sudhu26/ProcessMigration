#!/usr/bin/env python3
"""Compile the final reports from the review state (build-prompt §5, step 4).

Inputs: state/graph/units.json (+ state/units/ verdict checkpoints) and the
graph outputs (dependency-graph.json, db-object-catalog.json), plus the raw
scanner outputs for the dialect census. No LLM, no re-scan: everything is
read from files the earlier steps already wrote.

Usage:
  compile_reports.py --units state/graph/units.json
      [--graph state/graph/dependency-graph.json]
      [--catalog state/graph/db-object-catalog.json]
      [--checkpoints state/units]
      [--java state/raw/java_all.json] [--plsql state/raw/plsql_all.json]
      --outdir output

Writes into --outdir:
  process-catalog.csv — one row per process:
      unit_id, preclassification, verdict, confidence,
      summary (<=300 chars, one line), key_db_objects (semicolon-joined),
      java_file_count, repos (semicolon-joined), linkage
  classification-report.md — counts by label and verdict; what each class
      means for migration planning; explicit UNKNOWN / NEEDS_REVIEW lists;
      units with no verdict file; human-review flags aggregated with counts;
      a note on shared-library (Risk_DL) usage
  oracle-dialect-census.csv — feature, occurrences, aggregated over
      oracle_isms (Java scanner records) + risky_constructs (PL/SQL scanner
      records), sorted by occurrences descending (ties: feature name).
      Without --java/--plsql it falls back to the units' summed oracle_isms
      (Java side only) and notes the gap on stderr.
  db-object-catalog.csv — object, kind, defined_in (semicolon-joined),
      used_by_units (semicolon-joined). An empty defined_in flags an object
      that is referenced but has no definition in the scanned repos.
      A unit touching PKG.PROC counts as using the PKG catalog entry.
      Without --catalog the rows are derived from the units' db_objects
      (kind UNKNOWN, defined_in empty), including a synthesized row for
      the package of any dotted PKG.PROC name a unit touches (R6-N5:
      otherwise the PKG row the rule above promises is silently
      missing from the fallback).

Stdlib only.
"""
import argparse, csv, json, os, sys
from collections import Counter, defaultdict


def load(p, default):
    if p and os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    return default


def load_verdicts(d):
    """unit_id -> verdict JSON, keyed the same way make_batches.py
    sanitizes checkpoint basenames."""
    out = {}
    if d and os.path.isdir(d):
        for fn in sorted(os.listdir(d)):
            if fn.endswith('.json'):
                p = os.path.join(d, fn)
                try:
                    with open(p, encoding='utf-8') as f:
                        v = json.load(f)
                    out[v.get('unit_id') or fn[:-5]] = v
                except Exception:
                    # R7-N5: a corrupt checkpoint must not vanish
                    # silently as "no verdict" — name the file on stderr.
                    print(f'warning: corrupt verdict checkpoint {p}; '
                          f'ignoring', file=sys.stderr)
    return out


def one_line(text, limit=300):
    return ' '.join(str(text or '').split())[:limit]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--units', required=True,
                    help='state/graph/units.json')
    ap.add_argument('--graph', default='',
                    help='state/graph/dependency-graph.json (node/edge '
                         'counts are reported in classification-report.md)')
    ap.add_argument('--catalog', default='',
                    help='state/graph/db-object-catalog.json')
    ap.add_argument('--checkpoints', default='',
                    help='state/units/ verdict checkpoint directory')
    ap.add_argument('--java', default='',
                    help='state/raw/java_all.json (oracle_isms source)')
    ap.add_argument('--plsql', default='',
                    help='state/raw/plsql_all.json (risky_constructs source)')
    ap.add_argument('--outdir', required=True)
    a = ap.parse_args()

    units = load(a.units, [])
    graph = load(a.graph, {})
    catalog = load(a.catalog, [])
    verdicts = load_verdicts(a.checkpoints)
    os.makedirs(a.outdir, exist_ok=True)

    # --- process-catalog.csv ---
    cat_path = os.path.join(a.outdir, 'process-catalog.csv')
    with open(cat_path, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['unit_id', 'preclassification', 'verdict', 'confidence',
                    'summary', 'key_db_objects', 'java_file_count', 'repos',
                    'linkage'])
        for u in units:
            v = verdicts.get(u['unit_id'], {})
            key_objs = ';'.join(o.get('object', '') for o in
                                v.get('key_db_objects', [])
                                if isinstance(o, dict))
            w.writerow([
                u['unit_id'],
                (u.get('preclassification') or {}).get('label', 'UNLABELLED'),
                v.get('verdict', ''),
                v.get('confidence', ''),
                one_line(v.get('summary', '')),
                key_objs,
                u.get('java_file_count', 0),
                ';'.join(u.get('repos', [])),
                u.get('linkage', ''),
            ])

    # --- classification-report.md ---
    labels = Counter((u.get('preclassification') or {}).get('label',
                                                            'UNLABELLED')
                     for u in units)
    verdict_counts = Counter(verdicts.get(u['unit_id'], {}).get('verdict')
                             for u in units)
    needs_review = sorted(u['unit_id'] for u in units
                          if (u.get('preclassification') or {}).get('label')
                          == 'NEEDS_REVIEW')
    unknown = sorted(u['unit_id'] for u in units
                     if verdicts.get(u['unit_id'], {}).get('verdict')
                     == 'UNKNOWN')
    no_verdict = sorted(u['unit_id'] for u in units
                        if u['unit_id'] not in verdicts)
    flags = Counter()
    for u in units:
        for fl in verdicts.get(u['unit_id'], {}).get('human_review_flags', []):
            flags[fl] += 1
    dl_units = sorted(u['unit_id'] for u in units if 'Risk_DL' in u.get('repos', []))
    n_dl_files = sum(1 for u in units for jf in u.get('java_files', [])
                     if jf.get('repo') == 'Risk_DL')
    lines = ['# Classification report', '',
             f"{len(units)} processes; {len(verdicts)} reviewed "
             f"({len(no_verdict)} with no verdict file)."]
    # F-N5: conditioned on --graph being given, not on the loaded dict's
    # truthiness — a missing/empty graph file still yields the line, with
    # 0 nodes, 0 edges.
    if a.graph:
        lines.append(f"Dependency graph: {len(graph.get('nodes', []))} nodes, "
                     f"{len(graph.get('edges', []))} edges.")
    lines += ['', '## Counts by pre-classification label', '',
              '| Label | Units |', '|---|---|']
    for label in ('DB_HEAVY', 'JAVA_HEAVY', 'BALANCED', 'NEEDS_REVIEW',
                  'UNLABELLED'):
        if labels.get(label):
            lines.append(f'| {label} | {labels[label]} |')
    lines += ['', '## Counts by review verdict', '',
              '| Verdict | Units |', '|---|---|']
    for verdict in ('DB_HEAVY', 'JAVA_HEAVY', 'BALANCED', 'UNKNOWN'):
        if verdict_counts.get(verdict):
            lines.append(f'| {verdict} | {verdict_counts[verdict]} |')
    if verdict_counts.get(None):
        lines.append(f'| (no verdict) | {verdict_counts[None]} |')
    lines += ['',
              '## What the classes mean for migration planning', '',
              '- **DB_HEAVY**: behaviour is dominated by SQL, stored '
              'procedures, and set transforms. Migration effort concentrates '
              'in SQL translation and procedure conversion; budget for Spark '
              'SQL equivalence work and pre/post result comparison per '
              'process.',
              '- **JAVA_HEAVY**: behaviour is dominated by Java logic with '
              'the database as mostly dumb storage. Migration effort '
              'concentrates in the Java / data-access translation; the SQL '
              'surface is small.',
              '- **BALANCED**: mixed Java and SQL work — plan both tracks '
              'for these processes.',
              '- **NEEDS_REVIEW**: evidence was too thin, or no code could '
              'be linked to the job, to classify. A human must confirm what '
              'the process is before it can be planned.',
              '- **UNKNOWN**: the reviewer could not decide from the '
              'evidence. Treat like NEEDS_REVIEW — needs human eyes before '
              'planning.',
              '',
              '## Units needing human review', '',
              '### NEEDS_REVIEW (pre-classification)', '']
    lines += ([f'- `{u}`' for u in needs_review] or ['*(none)*'])
    lines += ['', '### UNKNOWN verdict', '']
    lines += ([f'- `{u}`' for u in unknown] or ['*(none)*'])
    lines += ['', '## Units with no verdict file', '']
    lines += ([f'- `{u}`' for u in no_verdict] or ['*(none)*'])
    lines += ['', '## Human-review flags (aggregated)', '',
              '| Flag | Units |', '|---|---|']
    for fl, n in sorted(flags.items(), key=lambda kv: (-kv[1], kv[0])):
        lines.append(f'| {fl} | {n} |')
    if not flags:
        lines.append('| *(none)* | 0 |')
    lines += ['', '## Shared-library (Risk_DL) usage', '',
              f'{len(dl_units)} process(es) include files from the shared '
              f'Risk_DL repo ({n_dl_files} Java file(s) in total). Shared '
              f'code is migrated once and reused: changes to Risk_DL ripple '
              f'to every process that imports it, so migrate the shared '
              f'library before (or with the first wave of) its consumers.']
    if dl_units:
        lines.append('')
        lines += [f'- `{u}`' for u in dl_units]
    lines.append('')
    with open(os.path.join(a.outdir, 'classification-report.md'), 'w',
              encoding='utf-8') as f:
        f.write('\n'.join(lines))

    # --- oracle-dialect-census.csv ---
    census = Counter()
    java_recs = load(a.java, [])
    plsql_recs = load(a.plsql, [])
    if java_recs:
        for r in java_recs:
            census.update(r.get('oracle_isms', {}))
    else:
        for u in units:
            census.update(u.get('oracle_isms', {}))
        print('note: no --java given; census Java side is the units\' '
              'summed oracle_isms (shared files counted once per unit)',
              file=sys.stderr)
    if plsql_recs:
        for r in plsql_recs:
            census.update(r.get('risky_constructs', {}))
    else:
        print('note: no --plsql given; census omits PL/SQL risky_constructs',
              file=sys.stderr)
    with open(os.path.join(a.outdir, 'oracle-dialect-census.csv'), 'w',
              encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['feature', 'occurrences'])
        for feat, n in sorted(census.items(), key=lambda kv: (-kv[1], kv[0])):
            w.writerow([feat, n])

    # --- db-object-catalog.csv ---
    if not catalog:
        # fall back to the objects the units touch (kind unknown, no defs)
        touched = {d['name'] for u in units
                   for d in u.get('db_objects', [])}
        # R6-N5: synthesize the PKG row for any dotted PKG.PROC name —
        # the used_by rule below counts such a unit as using the PKG
        # entry, so the fallback must list that entry too (kind
        # UNKNOWN), matching the with---catalog CSV.
        touched |= {name.split('.')[0] for name in touched
                    if '.' in name}
        # R7-N2: fill defined_in from the --plsql definitions already
        # loaded for the census above (plsql_recs) — same rule as
        # build_graph.py _defined_in: the object's own definition
        # file(s), else the owning package's file(s) for a PKG.MEMBER
        # name. Without --plsql there is nothing to fill from and
        # defined_in stays empty.
        def _fallback_defined_in(name):
            paths = [r['path'] for r in plsql_recs
                     if any(x['name'] == name
                            for x in r.get('definitions', []))]
            if not paths and '.' in name:
                owner = name.split('.')[0]
                paths = [r['path'] for r in plsql_recs
                         if any(x['name'] == owner
                                for x in r.get('definitions', []))]
            return paths
        catalog = [{'object': name, 'kind': 'UNKNOWN',
                    'defined_in': _fallback_defined_in(name)}
                   for name in sorted(touched)]
        print('note: no --catalog given; db-object-catalog.csv lists only '
              'objects touched by units (kind UNKNOWN)', file=sys.stderr)
    used_by = defaultdict(set)
    for u in units:
        for d in u.get('db_objects', []):
            used_by[d['name']].add(u['unit_id'])
            # a unit touching PKG.PROC counts as using the PKG entry
            if '.' in d['name']:
                used_by[d['name'].split('.')[0]].add(u['unit_id'])
    with open(os.path.join(a.outdir, 'db-object-catalog.csv'), 'w',
              encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(['object', 'kind', 'defined_in', 'used_by_units'])
        for c in sorted(catalog, key=lambda c: c['object']):
            w.writerow([c['object'], c.get('kind', ''),
                        ';'.join(c.get('defined_in', [])),
                        ';'.join(sorted(used_by.get(c['object'], [])))])

    print(f'{len(units)} units, {len(verdicts)} verdicts, '
          f'{len(census)} dialect features, {len(catalog)} catalog objects '
          f'-> {a.outdir}')


if __name__ == '__main__':
    main()
