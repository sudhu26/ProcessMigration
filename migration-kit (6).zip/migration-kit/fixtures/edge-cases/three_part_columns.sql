-- Three-part column refs regression (R7-G7, new assertion 46):
-- schema.table.col resolves through alias_map on the full name,
-- then the short table name, and records only the column; a
-- genuinely unknown prefix stays unattributed.
-- Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (three_part_columns.sql record):
-- reads ['SCHEMA1.T1', 'T1'],
-- table_columns {'SCHEMA1.T1': {'read': ['A', 'B'], 'write': []}},
-- columns_unattributed ['FOO.BAR.A'].
SELECT schema1.t1.a, schema1.t1.b FROM schema1.t1;
SELECT s1.t1.a FROM schema1.t1 s1;
SELECT foo.bar.a FROM t1;
