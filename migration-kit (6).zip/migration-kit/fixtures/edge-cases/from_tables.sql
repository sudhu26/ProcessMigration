-- _from_tables regression (R4-G4): same three shapes as FromTables.java.
-- Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (from_tables.sql record): reads ['T1', 'T2'],
-- table_columns {'T1': {'read': ['D']}, 'T2': {'read': ['C']}},
-- columns_unattributed ['A', 'B'].
SELECT a, b FROM t1, t2;
SELECT t2.c, t1.d FROM t1, t2;
SELECT a FROM t1 JOIN t2 ON t1.id = t2.id;
