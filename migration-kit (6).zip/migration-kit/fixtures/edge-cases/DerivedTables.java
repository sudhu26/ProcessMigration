package com.risk.edge;

/** Depth-aware FROM terminator regression (R5-G7): a WHERE/GROUP inside
 *  a derived table must not truncate the outer FROM clause. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (DerivedTables.java record):
 *  tables_read ['T1', 'T2'],
 *  table_columns {'T1': {'read': ['A', 'B'], 'write': []},
 *                   'T2': {'read': ['A'], 'write': []}},
 *  columns_unattributed [] — the outer 'a' of the first statement is
 *  attributed to T2 (the only outer table), 'b' to T1 via the subquery,
 *  and the '*' of the second statement is dropped (T1 + T2 is
 *  multi-table), leaving only T1 'A' from its subquery. */
public class DerivedTables {

    public void run(java.sql.Statement st) throws Exception {
        String whereInSubquery =
                "SELECT a FROM (SELECT b FROM t1 WHERE b>0) x JOIN t2 ON x.b=t2.b";
        st.executeQuery(whereInSubquery);

        String groupInSubquery =
                "SELECT * FROM (SELECT a FROM t1 GROUP BY a) x, t2";
        st.executeQuery(groupInSubquery);
    }
}
