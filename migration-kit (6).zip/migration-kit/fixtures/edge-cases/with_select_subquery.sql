-- WITH-subquery in the SELECT list regression (R7-G8): the strip
-- must cover parenthesised WITH subqueries as well as SELECT, or
-- the CTE name leaks as a bare column of the outer table.
-- Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (with_select_subquery.sql record):
-- reads ['T1', 'T2'],
-- table_columns {'T1': {'read': ['A'], 'write': []},
--                 'T2': {'read': ['A', 'B'], 'write': []}},
-- columns_unattributed [] — the CTE name C never leaks. The bare
-- subquery shape alone attributes nothing to T1 (same as the R6-G5
-- SELECT analogue, which yields only T2:{C}); T1:{A} here comes
-- from the second statement's bare 'a'. NOTE: review 7's stated
-- expectation for the bare shape alone ("T1:{A}, T2:{A}") does not
-- reproduce — probed, it yields T2:{A} only, no T1 entry.
SELECT (WITH c AS (SELECT a FROM t2) SELECT a FROM c) FROM t1;
SELECT a, (WITH c AS (SELECT b FROM t2) SELECT b FROM c) FROM t1;
