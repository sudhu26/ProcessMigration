# Claude 2.0 Cheat Sheet

Every new feature, where to find it, and exactly how to use it.

---

## First: Chat tab vs Code tab

The Claude desktop app now has **two tabs**:

- **Chat**: where most people work. Cowork has been merged into it, so Chat can now do everything Cowork could.
- **Code**: where most of the big upgrades live. **It's not just for coders.** You type in plain English like any chat. It can also work with files on your computer.

Each feature below is tagged **[Chat]**, **[Code]** or **[Separate app]**.

---

## Which feature do I use when?

| If you want to… | Use |
|---|---|
| Ask a quick question without interrupting Claude | **Side chat** |
| Run a few jobs at once and steer each one | **Helpers** |
| Run a big job while your laptop is closed | **Projects** |
| Start a task when you're away from your desk | **Dispatch** |
| Keep track of lots of chats | **Manager chat** |
| Have Claude come to you with what needs attention | **Claude Duet** |
| Write a real document with Claude | **Claude Docs** |
| Have Claude edit your Google Sheets, Docs or Slides | **Google Workspace connectors** |
| See what's eating your usage limits | **Side panel + /skill-doctor** |
| Change how the Claude app itself works | **Mods** |

---

## The features

### 1. Helpers (nested sessions) [Code]
One chat starts other chats that work **at the same time**, then report back. Each helper is a real chat in your sidebar that you can click into and talk to directly.

**How:** just ask for them.
```
I'm launching a $49 AI prompt pack next week. Start three helper sessions at the same time:
1. Find 5 competing prompt packs and what they charge.
2. Write 3 launch tweets.
3. Write a sales page headline and 3 bullet points.
Each one reports back to you with a 3-line summary. Don't ask me questions.
```
**Helpers vs subagents:** you can click into helpers and talk to them. Subagents do one job, report back and disappear, and you can't chat with them.

---

### 2. Side chat [Code]
A small window for questions that **doesn't interrupt** the main chat. It can read the whole chat but adds nothing to it.

**How:** click into a chat, then:
- press **Cmd + ;** (Mac) / **Ctrl + ;** (Windows), or
- type **/btw** followed by your question, or
- click **⋯** (top right) → **Side chat**
```
/btw In plain English, what's happened so far and what's still running?
```
**Note:** only works in sessions on your computer (not cloud sessions). Side chats close when you quit the app.

---

### 3. Split view [Code]
Several chats on one screen.

**How:**
- **Option + click** (Mac) / **Alt + click** (Windows) a chat in the sidebar: opens it side by side
- **Cmd + click** / **Ctrl + click**: opens it in its own window
- **Cmd + Ctrl + W** / **Ctrl + Alt + W**: takes the focused chat out of split view

**Tip:** 2–3 chats max. More than that is hard to follow.

---

### 4. Chats talk to each other [Code]
One chat can send messages to your other chats. Change your mind once, and every helper hears it. No more copy-pasting the same instruction into three chats.

**How:** tell the main chat to pass it on.
```
Change of plan: this product is for complete beginners, not experienced users. Tell the tweet helper and the sales page helper to rewrite their work for beginners, then show me the before and after.
```
**Tip:** type **@** and the start of a chat's name to point at a specific chat.

---

### 5. Manager chat [Code]
Not a button, a habit: one pinned chat that checks on all your other chats and tidies your sidebar.

**How:**
```
Pin this chat to the top of my sidebar. Then look at my recent chats and give me three lists: needs my decision, finished, stuck. One line each. Then put everything about the prompt pack launch into a new sidebar section called "Launch".
```
**Sections** are folders for your chats. Claude can create them for you, or click **⋯** next to any chat → **Move to new section**.

---

### 6. Claude Docs [Chat + Code]
Claude's own document editor, like Google Docs built into Claude. In the Code tab, it opens in the side panel and you watch Claude type.

**How:** start a message with **/docs**, or just ask for a doc.
```
/docs Turn the launch work into one doc called "Prompt Pack Launch" with two tabs: Sales Page and Launch Tweets.
```
- **Edit with Claude:** highlight text, leave a comment with **@Claude** and what you want changed.
- **Export:** Word, PDF, Markdown or Google Docs.
- **Share:** with a link (people need a Claude account).
- **Plans:** all plans, including Free. All your docs are saved in the **Artifacts** tab.

---

### 7. Google Sheets, Docs & Slides [Chat + Code]
Claude can open and edit your real Google files.

**Two ways:**
- **From Claude:** turn on the Google connectors, then paste a file link into your chat.
- **From Google:** install Claude from the Google Workspace Marketplace, then in your file go to **Extensions → Claude → Open Claude**.
```
Here's my Google Sheet: [paste link]. Fill it with the 5 competitor prompt packs from the research: name, price, what's included. Add a column that shows how our $49 compares, then add a chart of the prices.
```
- By default Claude **asks before each change** (approval cards). Switch to **Accept all edits** to let it just go.
- **Plans:** paid plans, in beta. On Team/Enterprise, an admin must turn the connectors on first.

---

### 8. Claude Design [Chat + Code]
Design is now inside Claude: social posts, web pages, anything visual.

**How:** ask for a design in Chat, or type **/design** in the Code tab.
```
/design Make a simple, clean sales page for the prompt pack using the headline and bullets from the launch doc.
```
⚠️ **The old standalone Claude Design website closes on December 14.** Export anything you made there before then.

---

### 9. Side panel: see what's eating your limits [Code]
A panel on the right of every chat showing where it's running, what changed, and how full the chat's memory is.

**How:** click **Show session rail** at the top right if you can't see it.
- **Environment card:** shows whether the chat is on your computer or in the cloud. Has the **Remote Control** switch, so you can continue the chat from your phone.
- **Context card:** how full the chat's memory is. Type **/context** for a full breakdown.

**Why it matters:** before you type anything, Claude loads your instructions file, every skill you've installed, your connected apps and your memory into every chat, and rereads them with every message. More stuff = you hit your limits faster.

**Check yours:**
```
/skill-doctor
```
It shows which skills you never use and how much space each one takes. Then:
```
Based on that report, which skills should I switch off? Biggest first, one line why. Don't switch anything off yet.
```

---

### 10. Customize [Code]
One place to manage your **connectors, skills and plugins**.

**How:** click **Customize** in the left sidebar. This is where you switch off skills you don't use.

---

### 11. Projects (new version) [Code]
Like helpers, but they run in **Anthropic's cloud**, so they keep working with your laptop closed. All the helpers in a project share one memory.

- **Plans:** Pro and Max, in beta with a waitlist (claude.com/form/projects). Not on Team/Enterprise yet.
- **Heads up:** files you add go to the cloud, and Anthropic says Projects can use your limits faster.
- Anthropic says a version that runs on your own computer is "coming very soon."

**Where:** look for **Projects** in the sidebar (or under **More**).

---

### 12. Dispatch [Chat]
Send Claude a task **from your phone**. It runs on your computer and notifies you when it's done or needs you.

- **How:** open Dispatch in the Claude desktop app and pair your phone, then message tasks from the Claude phone app.
- **Needs:** your computer on with the Claude app open. Pro or Max.
```
Summarise the launch doc into 5 bullet points I can send to my team.
```

---

### 13. Mods [Code]
Change how the Claude app itself works by describing what you want. Claude builds it.
```
Build me a mod: when Claude finishes a reply that took longer than a minute, pop up a small notification with a one-line summary of what it did.
```
**Tip:** people are already sharing free mods online. Only install ones you trust.

---

### 14. Claude Duet [Separate app]
A new app where Claude comes to **you**: a morning brief, checks on your connected apps every few hours, and alerts when something needs you. It runs in its own cloud computer, so it keeps working when you close everything. It asks before sending messages, paying, signing or deleting anything.

- **Status:** early research preview, waitlist, Pro and Max, **US only** for now.

---

## Handy shortcuts (Code tab, Mac)
Windows: use **Ctrl** instead of **Cmd** and **Alt** instead of **Option**.

| Shortcut | Does |
|---|---|
| **Cmd + /** | Show every shortcut |
| **Cmd + N** | New chat |
| **Cmd + ;** | Side chat |
| **Option + click** a chat | Split view |
| **Ctrl + Tab** | Switch between chats |
| **Esc, Esc** | Rewind to an earlier point in the chat |

## Handy commands (Code tab)

| Type | Does |
|---|---|
| **/btw** | Side chat question |
| **/docs** | Start a Claude Doc |
| **/design** | Start a Claude Design |
| **/context** | See what's using the chat's memory |
| **/skill-doctor** | Find skills you never use |
| **/doctor** | Health check of your setup |
| **/advisor** | Let a cheaper model ask a smarter one for help on big decisions |
| **/recap** | Quick summary of where a chat is up to |
| **/insights** | Report on how you use Claude |
| **/output-style** | Change how Claude talks to you (e.g. shorter, simpler) |

---

## Who gets what

| Feature | Free | Pro / Max | Team / Enterprise |
|---|---|---|---|
| Claude Docs | ✅ | ✅ | ✅ |
| Helpers, side chat, split view, mods (Code tab) | ❌* | ✅ | ✅ |
| Google Sheets/Docs/Slides | ❌ | ✅ beta | ✅ beta (admin turns on) |
| Projects (new) | ❌ | ✅ beta, waitlist | ❌ not yet |
| Dispatch | ❌ | ✅ | ❌ |
| Claude Duet | ❌ | ✅ US waitlist | ❌ not yet |

*The Code tab (Claude Code) is included with paid plans. If you're on Free, check what your app shows.

*Features change fast. Last checked: October 28, 2026.*
