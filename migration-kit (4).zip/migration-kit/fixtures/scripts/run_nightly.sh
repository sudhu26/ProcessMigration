#!/bin/ksh
# Nightly wrapper: sets env, runs the java job, then post-load audit SQL.
. /opt/risk/bin/env.sh
$JAVA_HOME/bin/java -Xmx4g -cp /opt/risk/lib/risk-dl.jar:/opt/risk/lib/* com.risk.wm.jobs.NightlyRiskJob $1
sqlplus risk_batch/$DB_PASS@RISKDB @/opt/risk/sql/post_load.sql
