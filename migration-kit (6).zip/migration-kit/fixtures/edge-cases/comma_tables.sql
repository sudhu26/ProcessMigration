-- Comma-only FROM regression (R5-G6): a single comma-joined statement
-- with NO JOIN statement in the same file to mask it. Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (comma_tables.sql record): reads ['T1', 'T2'],
-- table_columns {} (a and b are multi-table bare columns),
-- columns_unattributed ['A', 'B'].
SELECT a, b FROM t1, t2;
