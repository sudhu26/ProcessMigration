#!/usr/bin/env python3
"""Scan Java sources for JDBC usage, embedded SQL, stored-proc calls,
Oracle-dialect features, and inter-file dependencies. Stdlib only.

Usage: scan_java.py --root <repo_root> --repo <repo_name> --out <out.json>
"""
import argparse, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ignore_lists import load_ignore, split_kept_ignored, split_kept_ignored_ordered  # noqa: E402

SQL_KEYWORDS = re.compile(
    r'\b(SELECT|INSERT\s+INTO|INSERT|UPDATE|DELETE\s+FROM|DELETE|MERGE\s+INTO|MERGE|'
    r'WITH|TRUNCATE|CALL|CREATE|DROP|ALTER)\b', re.IGNORECASE)

# TABLE_PATTERNS carries write patterns only (R6-N6): the FROM/JOIN/
# TABLE( read entries were dead — reads come only from _read_tables
# (R5-G6) — and keeping them invited reintroducing the comma-joined
# table bug. The TABLE( function name is still read via _TABLE_FUNC_RE.
TABLE_PATTERNS = [
    # INTO counts as a write only when preceded by INSERT: PL/SQL
    # SELECT ... INTO var must NOT record the variable as a table.
    (re.compile(r'\bINSERT\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
    (re.compile(r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET', re.IGNORECASE), 'write'),
    (re.compile(r'\bMERGE\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)', re.IGNORECASE), 'write'),
]

PROC_CALL = re.compile(r'\{\s*call\s+([A-Za-z_][\w$.]*)\s*\(?', re.IGNORECASE)
PREPCALL = re.compile(r'prepareCall\s*\(\s*"([^"]+)"', re.IGNORECASE)

JDBC_SIGNALS = {
    'getConnection': re.compile(r'\bgetConnection\s*\('),
    'prepareStatement': re.compile(r'\bprepareStatement\s*\('),
    'prepareCall': re.compile(r'\bprepareCall\s*\('),
    'createStatement': re.compile(r'\bcreateStatement\s*\('),
    'executeQuery': re.compile(r'\bexecuteQuery\s*\('),
    'executeUpdate': re.compile(r'\bexecuteUpdate\s*\('),
    'executeBatch': re.compile(r'\bexecuteBatch\s*\('),
    'addBatch': re.compile(r'\baddBatch\s*\('),
    'setAutoCommit': re.compile(r'\bsetAutoCommit\s*\('),
    'commit': re.compile(r'\bcommit\s*\(\s*\)'),
    'rollback': re.compile(r'\brollback\s*\('),
    'setSavepoint': re.compile(r'\b(SetSavepoint|setSavepoint)\s*\('),
}

ORACLE_ISMS = {
    'ROWNUM': re.compile(r'\bROWNUM\b', re.IGNORECASE),
    'SYSDATE_SYSTIMESTAMP': re.compile(r'\b(SYSDATE|SYSTIMESTAMP|CURRENT_DATE)\b', re.IGNORECASE),
    'DUAL': re.compile(r'\bFROM\s+DUAL\b', re.IGNORECASE),
    'NVL': re.compile(r'\bNVL[2]?\s*\(', re.IGNORECASE),
    'DECODE': re.compile(r'\bDECODE\s*\(', re.IGNORECASE),
    'OLD_JOIN_OP': re.compile(r'\(\+\)'),
    'CONNECT_BY': re.compile(r'\b(CONNECT\s+BY|START\s+WITH)\b', re.IGNORECASE),
    'SEQUENCE': re.compile(r'\bNEXTVAL\b|\bCURRVAL\b', re.IGNORECASE),
    'FOR_UPDATE': re.compile(r'\bFOR\s+UPDATE\b', re.IGNORECASE),
    'HINT': re.compile(r'/\*\+'),
    'MODEL_CLAUSE': re.compile(r'\bMODEL\b', re.IGNORECASE),
    'PIVOT': re.compile(r'\bPIVOT\b', re.IGNORECASE),
}

STRING_RE = re.compile(r'"(?:\\.|[^"\\])*"')
TEXTBLOCK_RE = re.compile(r'"""(.*?)"""', re.DOTALL)
# One combined literal matcher, so text blocks and "..." strings share a
# single coordinate space (spans from a text-block-replaced copy would be
# shifted and could never merge with a following concatenated fragment).
LITERAL_RE = re.compile(r'"""(.*?)"""|"(?:\\.|[^"\\])*"', re.DOTALL)
# R6-B1 / R7-G2: the `+`-concatenation separator between SQL string
# fragments. ONE shared constant: prepare_migration_tree.py imports
# BETWEEN_RE from here instead of keeping its own copy, so the tree
# and the scanner can never drift apart again (when they differed, an
# args[0]- / (var)-joined fragment was silently dropped from the tree
# while the scanner counted it). Do not hand-rewrite it in either file.
BETWEEN_RE = re.compile(r'^\s*\+\s*(?:(?:[A-Za-z_][\w$.]*(?:\[[^\]]*\]|\([^)]*\))?|\([^)]*\))\s*\+\s*)?$')
LINE_COMMENT = re.compile(r'//.*?$', re.MULTILINE)
BLOCK_COMMENT = re.compile(r'/\*.*?\*/', re.DOTALL)
PACKAGE_RE = re.compile(r'^\s*package\s+([\w.]+)\s*;', re.MULTILINE)
IMPORT_RE = re.compile(r'^\s*import\s+(static\s+)?([\w.*]+)\s*;', re.MULTILINE)
CLASS_RE = re.compile(r'\b(public\s+|protected\s+|private\s+)?(class|interface|enum|record)\s+(\w+)')
METHOD_RE = re.compile(r'\b(public|protected|private|static|\s)+\s*[\w<>\[\]]+\s+(\w+)\s*\([^;{}]*\)\s*(throws\s+[\w,\s]+)?\{')
BRANCH_RE = re.compile(r'\b(if|for|while|switch|catch|case)\b')


def strip_comments(text):
    text = BLOCK_COMMENT.sub('', text)
    text = LINE_COMMENT.sub('', text)
    return text


# --- column extraction (best-effort heuristic; mirrored in scan_plsql.py) ---
_SQL_KW = {'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'AS', 'ON', 'JOIN', 'LEFT',
           'RIGHT', 'INNER', 'OUTER', 'FULL', 'CROSS', 'GROUP', 'ORDER', 'BY',
           'HAVING', 'INTO', 'VALUES', 'SET', 'INSERT', 'UPDATE', 'DELETE',
           'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'DISTINCT', 'UNION', 'ALL',
           'NOT', 'NULL', 'IS', 'IN', 'LIKE', 'BETWEEN', 'EXISTS', 'WITH',
           'MERGE', 'DUAL', 'TABLE', 'SYSDATE', 'SYSTIMESTAMP',
           'CURRENT_DATE', 'ROWNUM', 'UNIQUE', 'DISTINCTROW'}


def split_top_commas(s):
    parts, depth, cur = [], 0, ''
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        if ch == ',' and depth == 0:
            parts.append(cur)
            cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return parts


def _col_refs(item):
    """Column refs in a SELECT-list item: [(prefix|None, name)].
    Function names (identifier directly followed by '(') and keywords skipped.
    Up to three segments (R7-G7): schema.table.col yields prefix
    'SCHEMA.TABLE' (resolved through alias_map on the full name, then
    the short table name, in extract_table_columns); a bare or
    table.col ref behaves as before."""
    out = []
    for m in re.finditer(r'([A-Za-z_][\w$]*)(?:\.([A-Za-z_][\w$]*)(?:\.([A-Za-z_][\w$]*))?)?', item):
        a, b, c = m.group(1), m.group(2), m.group(3)
        if m.end() < len(item) and item[m.end()] == '(':
            continue
        if a.upper() in _SQL_KW:
            continue
        if c is not None:
            if b.upper() in _SQL_KW or c.upper() in _SQL_KW:
                continue
            out.append((f'{a.upper()}.{b.upper()}', c.upper()))
        elif b:
            if b.upper() in _SQL_KW:
                continue
            out.append((a.upper(), b.upper()))
        else:
            out.append((None, a.upper()))
    return out


def _top_level_from(sql):
    """(select_list, from_clause) for a SELECT, using the first top-level
    FROM; None when no SELECT...FROM found."""
    m = re.search(r'\bSELECT\b', sql, re.I)
    if not m:
        return None
    depth, i, from_at = 0, m.end(), None
    while i < len(sql):
        ch = sql[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and sql[i:i + 4].upper() == 'FROM' and \
                (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == '_')) and \
                (i + 4 >= len(sql) or not (sql[i + 4].isalnum() or sql[i + 4] == '_')):
            from_at = i
            break
        i += 1
    if from_at is None:
        return None
    rest = sql[from_at + 4:]
    # R5-G7: terminator scan is depth-aware — a WHERE/GROUP/ORDER/HAVING/
    # UNION/MINUS/INTERSECT inside a derived table (depth > 0) must not
    # truncate the outer FROM clause.
    end, depth, i = len(rest), 0, 0
    while i < len(rest):
        ch = rest[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0:
            hit = False
            for kw in ('WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'MINUS', 'INTERSECT'):
                if rest[i:i + len(kw)].upper() == kw and \
                        (i == 0 or not (rest[i - 1].isalnum() or rest[i - 1] == '_')) and \
                        (i + len(kw) >= len(rest) or not (rest[i + len(kw)].isalnum() or rest[i + len(kw)] == '_')):
                    end, hit = i, True
                    break
            if hit:
                break
        i += 1
    return sql[m.end():from_at], sql[from_at:from_at + 4 + end]


def _subqueries(sql):
    """Inner SELECT statements inside parentheses (derived tables)."""
    out = []
    for m in re.finditer(r'\(\s*(?:SELECT|WITH)\b', sql, re.I):
        depth, i = 0, m.start()
        while i < len(sql):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
                if depth == 0:
                    out.append(sql[m.start() + 1:i])
                    break
            i += 1
    return out


def _set_op_branches(sql):
    """Top-level (depth-0) UNION/MINUS/INTERSECT split: [branch, ...],
    or None when no set operator occurs at depth 0. A trailing ALL
    stays attached to the following branch (its SELECT is found by
    _top_level_from / _read_tables anyway)."""
    branches, depth, i, start = [], 0, 0, 0
    while i < len(sql):
        ch = sql[i]
        if ch == '(':
            depth += 1
            i += 1
        elif ch == ')':
            depth = max(0, depth - 1)
            i += 1
        elif depth == 0:
            hit = None
            for kw in ('UNION', 'MINUS', 'INTERSECT'):
                if sql[i:i + len(kw)].upper() == kw and \
                        (i == 0 or not (sql[i - 1].isalnum() or sql[i - 1] == '_')) and \
                        (i + len(kw) >= len(sql) or not (sql[i + len(kw)].isalnum() or sql[i + len(kw)] == '_')):
                    hit = kw
                    break
            if hit:
                branches.append(sql[start:i])
                i += len(hit)
                start = i
            else:
                i += 1
        else:
            i += 1
    if not branches:
        return None
    branches.append(sql[start:])
    return branches


def _parse_with(sql):
    """Leading WITH ... AS (...) definitions: ({name: inner_sql}, main_sql)
    or None. Names are upper-cased; inner_sql is the parenthesised
    SELECT text without the outer parens. Handles WITH RECURSIVE and
    comma-separated CTEs, each optionally with a column list."""
    m = re.match(r'\s*WITH\s+(?:RECURSIVE\s+)?', sql, re.I)
    if not m:
        return None
    i, ctes = m.end(), {}
    while True:
        while i < len(sql) and sql[i].isspace():
            i += 1
        nm = re.match(r'([A-Za-z_][\w$]*)', sql[i:])
        if not nm:
            return None
        name = nm.group(1).upper()
        i += nm.end()
        while i < len(sql) and sql[i].isspace():
            i += 1
        if i < len(sql) and sql[i] == '(':
            # A parenthesised group here is a column list only when it
            # is followed by AS; otherwise the '(' belongs to AS (...).
            depth, j = 0, i
            while j < len(sql):
                if sql[j] == '(':
                    depth += 1
                elif sql[j] == ')':
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            if sql[j + 1:].lstrip().upper().startswith('AS'):
                i = j + 1
                while i < len(sql) and sql[i].isspace():
                    i += 1
        if sql[i:i + 2].upper() != 'AS':
            return None
        i += 2
        while i < len(sql) and sql[i].isspace():
            i += 1
        if i >= len(sql) or sql[i] != '(':
            return None
        depth, j = 0, i
        while j < len(sql):
            if sql[j] == '(':
                depth += 1
            elif sql[j] == ')':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        if depth != 0:
            return None
        ctes[name] = sql[i + 1:j]
        i = j + 1
        while i < len(sql) and sql[i].isspace():
            i += 1
        if i < len(sql) and sql[i] == ',':
            i += 1
            continue
        break
    return ctes, sql[i:]


def _paren_subqueries(sql):
    """[(start, inner_sql)] for parenthesised SELECT/WITH subqueries
    whose opening paren is at depth 0 in sql (the outermost ones
    only). A subquery nested inside another one is NOT returned — the
    outer one's own recursion accounts for it. Needed by
    _output_tables (R7-G1): counting a WHERE-nested subquery of a
    derived table as an output table of the outer query would wrongly
    drop '*'."""
    out = []
    depth, i = 0, 0
    while i < len(sql):
        ch = sql[i]
        if ch == '(':
            if depth == 0 and re.match(r'\(\s*(?:SELECT|WITH)\b', sql[i:], re.I):
                d, j = 0, i
                while j < len(sql):
                    if sql[j] == '(':
                        d += 1
                    elif sql[j] == ')':
                        d -= 1
                        if d == 0:
                            break
                    j += 1
                out.append((i, sql[i + 1:j]))
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        i += 1
    return out


def _from_subqueries(sql):
    """Parenthesised SELECTs occurring in the FROM clause only (the
    derived tables). Unlike _subqueries over the whole statement, this
    never sees WHERE- or SELECT-list subqueries. Only the outermost
    derived tables are returned (R7-G1): a subquery nested inside a
    derived table's WHERE clause belongs to that derived table, and
    _output_tables recurses into it. A parenthesised SELECT counts
    only where a table reference is expected — after FROM/JOIN or a
    top-level comma — not inside an ON condition."""
    parsed = _top_level_from(sql)
    if not parsed:
        return []
    from_clause = parsed[1]
    out = []
    for start, inner in _paren_subqueries(from_clause):
        head = from_clause[:start].rstrip()
        if re.search(r'\b(?:FROM|JOIN)\s*$', head, re.I) or head.endswith(','):
            out.append(inner)
    return out


def _output_tables(sql, _cte_map=None):
    """Output-column source tables of a SELECT statement (R7-G1): its
    FROM-clause tables (recursing into derived tables nested in its
    FROM clause and into UNION/MINUS/INTERSECT branches), PLUS for
    each parenthesised subquery in its SELECT list, that subquery's
    output tables (recursively). A WHERE subquery's tables contribute
    no output columns, so they NEVER count at any depth — unlike
    _read_tables, which deliberately recurses all subqueries (correct
    for reads, wrong for the '*' candidate set). Used only for the '*'
    candidate set in extract_table_columns."""
    one = ' '.join(sql.split())
    out = set()
    parsed_with = _parse_with(one)
    if parsed_with:
        ctes, main_sql = parsed_with
        resolved = {}
        for name, inner in ctes.items():
            resolved[name] = _output_tables(inner, _cte_map=resolved)
        return _output_tables(main_sql, _cte_map=resolved)
    branches = _set_op_branches(one)
    if branches:
        for b in branches:
            out |= _output_tables(b, _cte_map=_cte_map)
        return out
    parsed = _top_level_from(one)
    if not parsed:
        return out
    select_list, from_clause = parsed
    for t, _al in _from_tables(from_clause):
        if _is_dual(t):
            continue
        if _cte_map and t in _cte_map:
            out |= _cte_map[t]
        else:
            out.add(t)
    for sub in _from_subqueries(one):
        out |= _output_tables(sub, _cte_map=_cte_map)
    for _st, sub in _paren_subqueries(select_list):
        out |= _output_tables(sub, _cte_map=_cte_map)
    return out


def _strip_select_subqueries(s):
    """Remove parenthesised SELECT/WITH subqueries (and an optional alias
    following each) from a SELECT list; columns inside them are
    attributed by the subquery recursion, so leaving them in would
    leak the subquery's table name as a column (R6-G5). The WITH form
    (R7-G8) must be stripped too, or the CTE name leaks as a bare
    column of the outer table."""
    out, i = [], 0
    while i < len(s):
        if re.match(r'\(\s*(?:SELECT|WITH)\b', s[i:], re.I):
            depth, j = 0, i
            while j < len(s):
                if s[j] == '(':
                    depth += 1
                elif s[j] == ')':
                    depth -= 1
                    if depth == 0:
                        break
                j += 1
            i = j + 1
            am = re.match(r'\s*(?:AS\s+)?[A-Za-z_][\w$]*', s[i:])
            if am:
                rest = s[i + am.end():]
                if rest.lstrip().startswith(',') or not rest.strip():
                    i += am.end()
            out.append(' ')
        else:
            out.append(s[i])
            i += 1
    return ''.join(out)

# Keywords that may follow a table name in a FROM clause and must never be
# consumed as that table's alias (R4-G4: a bare JOIN after a table is a
# join, not an alias).
_FROM_CLAUSE_KW = (r'JOIN|LEFT|RIGHT|INNER|OUTER|FULL|CROSS|NATURAL|ON|'
                   r'USING|WHERE|GROUP|ORDER|HAVING|UNION|MINUS|INTERSECT|'
                   r'LIMIT|FETCH|FOR|CONNECT|START|AS')
_TABLE_NAME_RE = r'[A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*'
# Optional alias after a table name: "t1 x" or "t1 AS x", but never a
# clause keyword.
_TABLE_ALIAS_RE = (r'(?:\s+(?:AS\s+)?(?!' + _FROM_CLAUSE_KW + r'\b)'
                   r'([A-Za-z_][\w$]*))?')


def _from_tables(from_clause):
    """[(table, alias|None)] from a FROM/JOIN clause.

    Registers comma-separated tables after the first FROM table
    (FROM t1, t2) and every JOINed table, including a bare JOIN ... ON
    with no AS aliases; a clause keyword is never consumed as an alias."""
    out = []

    def _alias(m):
        alias = m.group(2)
        if alias and alias.upper() in _SQL_KW:
            return None
        return alias.upper() if alias else None

    def _depth_at(pos):
        d = 0
        for ch in from_clause[:pos]:
            if ch == '(':
                d += 1
            elif ch == ')':
                d = max(0, d - 1)
        return d

    # R5-G7: only FROM/JOIN at depth 0 register an outer table — a FROM
    # inside a derived table (SELECT ... FROM (SELECT ... FROM t1) x ...)
    # belongs to the subquery, which extract_table_columns/_read_tables
    # handle by recursing into _subqueries.
    for m in re.finditer(
            r'\b(?:FROM|JOIN)\s+(' + _TABLE_NAME_RE + ')' + _TABLE_ALIAS_RE,
            from_clause, re.I):
        if _depth_at(m.start()) != 0:
            continue
        out.append((m.group(1).upper(), _alias(m)))
        # comma-joined followers: FROM t1, t2 [AS] x, t3 ...
        rest = from_clause[m.end():]
        while True:
            cm = re.match(r'\s*,\s*(' + _TABLE_NAME_RE + ')' + _TABLE_ALIAS_RE,
                          rest, re.I)
            if not cm:
                break
            out.append((cm.group(1).upper(), _alias(cm)))
            rest = rest[cm.end():]
    # R5-G6: comma-separated followers not immediately after a FROM/JOIN
    # match — a comma after an ON clause ("JOIN t2 ON ..., t3") or after a
    # derived table ("FROM (SELECT ...) x, t2"). Depth-0 commas only, so
    # commas inside function calls / subqueries never register a table.
    seen = {t for t, _ in out}
    depth, i = 0, 0
    while i < len(from_clause):
        ch = from_clause[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif ch == ',' and depth == 0:
            cm = re.match(r'\s*(' + _TABLE_NAME_RE + ')' + _TABLE_ALIAS_RE,
                          from_clause[i + 1:], re.I)
            if cm and cm.group(1).upper() not in seen:
                out.append((cm.group(1).upper(), _alias(cm)))
                seen.add(cm.group(1).upper())
        i += 1
    return out


def _is_dual(name):
    """R5-G8: the pseudo-table DUAL, optionally schema-qualified."""
    return name == 'DUAL' or name.endswith('.DUAL')


_TABLE_FUNC_RE = re.compile(
    r'\bTABLE\s*\(\s*([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)',
    re.IGNORECASE)


def _read_tables(sql):
    """R5-G6: read tables for one SQL statement, reusing _from_tables —
    the same parse extract_table_columns uses for column attribution, so
    tables_read/reads can never disagree with table_columns about the
    FROM clause. Covers comma-joined tables, bare JOINs, derived tables
    (via _subqueries recursion) and UNION/MINUS/INTERSECT branches; the
    TABLE( function and a non-SELECT FROM (e.g. DELETE FROM t) are
    handled explicitly. DUAL is skipped (R5-G8); a bare table named
    TABLE from FROM TABLE( is skipped here — the TABLE( pattern supplies
    the function name instead (table_columns keeps the TABLE artifact)."""
    reads = set()
    one = ' '.join(sql.split())
    # R6-G3: leading WITH ... AS (...): CTE names are not real tables.
    # Reads are the main query's tables plus each inner query's tables,
    # with every CTE name removed.
    parsed_with = _parse_with(one)
    if parsed_with:
        ctes, main_sql = parsed_with
        for inner in ctes.values():
            reads |= _read_tables(inner)
        reads |= _read_tables(main_sql)
        return {r for r in reads if r not in ctes}
    for m in _TABLE_FUNC_RE.finditer(one):
        name = m.group(1).upper()
        if not _is_dual(name):
            reads.add(name)
    parsed = _top_level_from(one)
    if parsed:
        _, from_clause = parsed
        for t, _al in _from_tables(from_clause):
            if t == 'TABLE' or _is_dual(t):
                continue
            reads.add(t)
        # UNION/MINUS/INTERSECT branches: _top_level_from truncates the
        # FROM clause at the set operator, so recurse on each branch.
        depth, i = 0, 0
        while i < len(one):
            ch = one[i]
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth = max(0, depth - 1)
            elif depth == 0:
                for kw in ('UNION', 'MINUS', 'INTERSECT'):
                    if one[i:i + len(kw)].upper() == kw and \
                            (i == 0 or not (one[i - 1].isalnum() or one[i - 1] == '_')) and \
                            (i + len(kw) >= len(one) or not (one[i + len(kw)].isalnum() or one[i + len(kw)] == '_')):
                        reads |= _read_tables(one[i + len(kw):])
                        i = len(one)
                        break
            i += 1
    else:
        for t, _al in _from_tables(one):
            if t == 'TABLE' or _is_dual(t):
                continue
            reads.add(t)
    for sub in _subqueries(one):
        reads |= _read_tables(sub)
    return reads


def extract_table_columns(sql, _cte_map=None):
    """Best-effort per-table column usage from one SQL statement.
    Returns ({table: {'read': set, 'write': set}}, unattributed set).
    INSERT/UPDATE columns are exact; SELECT columns are attributed via
    table prefixes/aliases, or to the single FROM table when unambiguous.
    _cte_map (internal): {CTE name: {real tables}} for WITH queries, so
    references to a CTE resolve against its inner query's tables."""
    from collections import defaultdict
    cols = defaultdict(lambda: {'read': set(), 'write': set()})
    unatt = set()
    one = ' '.join(sql.split())
    for m in re.finditer(
            r'\bINSERT\s+INTO\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)'
            r'\s*\(([^)]*)\)', one, re.I):
        if _is_dual(m.group(1).upper()):
            continue
        for c in m.group(2).split(','):
            c = c.strip().strip('"').upper()
            if c:
                cols[m.group(1).upper()]['write'].add(c)
    for m in re.finditer(
            r'\bUPDATE\s+([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)\s+SET\s+'
            r'(.*?)(?:\bWHERE\b|;|$)', one, re.I | re.S):
        if _is_dual(m.group(1).upper()):
            continue
        for part in split_top_commas(m.group(2)):
            cm = re.match(r'\s*"?([A-Za-z_][\w$]*)"?\s*=', part)
            if cm:
                cols[m.group(1).upper()]['write'].add(cm.group(1).upper())
    # R6-G3: leading WITH ... AS (...): extract each CTE's inner query
    # (resolving earlier CTEs), then the main query with CTE names
    # mapped to the real tables their inner queries read — no phantom
    # db:CTE node, and no CTE name in reads.
    parsed_with = _parse_with(one)
    if parsed_with:
        ctes, main_sql = parsed_with
        resolved = {}
        for name, inner in ctes.items():
            tc_in, un_in = extract_table_columns(inner, _cte_map=resolved)
            for t, kinds in tc_in.items():
                cols[t]['read'].update(kinds['read'])
                cols[t]['write'].update(kinds['write'])
            unatt.update(un_in)
            rt = set()
            for t in _read_tables(inner):
                if t in resolved:
                    rt |= resolved[t]
                elif t not in ctes:
                    rt.add(t)
            resolved[name] = rt
        tc_main, un_main = extract_table_columns(main_sql, _cte_map=resolved)
        for t, kinds in tc_main.items():
            cols[t]['read'].update(kinds['read'])
            cols[t]['write'].update(kinds['write'])
        unatt.update(un_main)
        if not _read_tables(one):
            unatt = set()
        return cols, unatt
    # R6-G2: UNION/MINUS/INTERSECT branches are extracted per branch
    # (like _read_tables does); a bare '*' is kept only when all
    # branches together name exactly one table.
    branches = _set_op_branches(one)
    if branches:
        branch_tables = set()
        for b in branches:
            branch_tables |= _read_tables(b)
            tc_b, un_b = extract_table_columns(b, _cte_map=_cte_map)
            for t, kinds in tc_b.items():
                cols[t]['read'].update(kinds['read'])
                cols[t]['write'].update(kinds['write'])
            unatt.update(un_b)
        if len(branch_tables) > 1:
            for kinds in cols.values():
                kinds['read'].discard('*')
        cols = defaultdict(lambda: {'read': set(), 'write': set()},
                           {t: k for t, k in cols.items()
                            if k['read'] or k['write']})
        if not branch_tables:
            unatt = set()
        return cols, unatt
    # R6-B2/R7-G1: recurse first — the subquery tables are needed to
    # decide '*' attribution below. Columns come from every
    # parenthesised subquery, but the '*' candidate set counts only the
    # FROM-clause derived tables' OUTPUT tables (see _output_tables),
    # not WHERE- or SELECT-list subqueries as tables read anywhere.
    sub_results = [extract_table_columns(sub, _cte_map=_cte_map)
                   for sub in _subqueries(one)]
    sub_tables = set()
    for sub in _from_subqueries(one):
        sub_tables |= _output_tables(sub, _cte_map=_cte_map)
    parsed = _top_level_from(one)
    if parsed:
        select_list, from_clause = parsed
        # PL/SQL SELECT ... INTO var[, var...]: the targets are not
        # columns (R6-G6: the full comma-separated target list).
        select_list = re.sub(
            r'\bINTO\s+[A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*'
            r'(?:\s*,\s*[A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*)*)*',
            '', select_list, flags=re.I)
        # R7-G4: strip a leading DISTINCT/ALL/UNIQUE/DISTINCTROW from
        # the select list before alias handling — otherwise m_alias2
        # treats the keyword as a column name and the first real
        # column as its alias, silently eating it (UNIQUE, not in
        # _SQL_KW before this fix, was recorded as a bogus column).
        select_list = re.sub(
            r'^\s*(?:DISTINCT|ALL|UNIQUE|DISTINCTROW)\b\s*', '',
            select_list, flags=re.I)
        # R6-G5: strip parenthesised SELECT subqueries from the select
        # list before _col_refs (their columns are attributed by the
        # recursion above); otherwise the subquery's table name leaks
        # in as a column of the outer table.
        select_list = _strip_select_subqueries(select_list)
        tables = []
        cte_extra = set()
        multi_cte = False
        for t, al in _from_tables(from_clause):
            if _is_dual(t):
                continue  # R5-G8
            if _cte_map and t in _cte_map:
                rt = set(_cte_map[t])
                if len(rt) == 1:
                    tables.append((next(iter(rt)), al if al else t))
                elif len(rt) > 1:
                    multi_cte = True
                    cte_extra |= rt
                continue
            tables.append((t, al))
        alias_map = {}
        for t, al in tables:
            alias_map[t] = t
            if al:
                alias_map[al] = t
        # R6-G4: also map the unqualified last segment of each
        # schema-qualified table name, unless it collides with another
        # table/alias (a collision is ambiguous, so the short name is
        # dropped and the column stays unattributed).
        for t, _al in tables:
            short = t.rsplit('.', 1)[-1]
            if short not in alias_map:
                alias_map[short] = t
            elif alias_map[short] != t:
                del alias_map[short]
        single = tables[0][0] if len(tables) == 1 and not multi_cte else None
        for item in split_top_commas(select_list):
            item = re.sub(r'\bAS\s+[A-Za-z_][\w$]*', '', item,
                          flags=re.I).strip()
            # implicit alias: "SUM(x) E" / "BOOK b" -> "SUM(x)" / "BOOK"
            m_alias = re.match(r'^(.*\))\s+[A-Za-z_][\w$]*$', item)
            if m_alias:
                item = m_alias.group(1)
            else:
                # R7-G7: up to three segments, so a 3-part ref with an
                # alias ("schema1.t1.a b") strips the alias too.
                m_alias2 = re.match(
                    r'^([A-Za-z_][\w$]*(?:\.[A-Za-z_][\w$]*){0,2})\s+'
                    r'[A-Za-z_][\w$]*$', item)
                if m_alias2:
                    item = m_alias2.group(1)
            if item == '*':
                # R7-G1: '*' is recorded only when the outer FROM tables
                # plus the FROM-clause derived tables' OUTPUT tables
                # (FROM-clause tables recursed, UNION/MINUS/INTERSECT
                # branches, SELECT-list subquery outputs; WHERE
                # subqueries never count) name exactly one table.
                candidates = {t for t, _ in tables} | cte_extra | sub_tables
                if len(candidates) == 1:
                    cols[next(iter(candidates))]['read'].add('*')
                continue
            for pm in re.finditer(r'([A-Za-z_][\w$]*)\s*\.\s*\*', item):
                prefix = pm.group(1).upper()
                t = alias_map.get(prefix)
                if t:
                    cols[t]['read'].add('*')
                else:
                    unatt.add(prefix)
            item = re.sub(r'[A-Za-z_][\w$]*\s*\.\s*\*', '', item)
            for prefix, name in _col_refs(item):
                if prefix:
                    t = alias_map.get(prefix)
                    if t is None and '.' in prefix:
                        # R7-G7: a 3-part ref schema.table.col (or
                        # alias.table.col) also resolves through the
                        # short table name; a genuinely unknown prefix
                        # stays unattributed.
                        t = alias_map.get(prefix.rsplit('.', 1)[-1])
                    if t:
                        cols[t]['read'].add(name)
                    else:
                        unatt.add(f'{prefix}.{name}')
                elif single:
                    cols[single]['read'].add(name)
                else:
                    unatt.add(name)
    # merge the derived-table subquery results computed above
    for tc2, un2 in sub_results:
        for t, kinds in tc2.items():
            cols[t]['read'].update(kinds['read'])
            cols[t]['write'].update(kinds['write'])
        unatt.update(un2)
    # R6-G9: when the statement names no tables at all (DUAL-only),
    # unattributed columns are dropped, not reported.
    if not _read_tables(one):
        unatt = set()
    return cols, unatt

def _mask_comments(text):
    """R7-G11: blank out // and /* */ comment spans so commented-out
    SQL strings are not counted as live SQL. Single left-to-right pass:
    a string literal / text block is skipped whole, so '//' or '/*'
    inside it never starts a comment, and a '"' inside a comment never
    starts a string (the comment is consumed first); char literals are
    skipped the same way. Newlines are preserved so positions still
    line up with the original text."""
    chars = list(text)
    i, n = 0, len(text)
    while i < n:
        ch = text[i]
        if ch == '"':
            if text.startswith('"""', i):
                j = text.find('"""', i + 3)
                i = n if j == -1 else j + 3
            else:
                j = i + 1
                while j < n:
                    if text[j] == '\\':
                        j += 2
                        continue
                    if text[j] == '"' or text[j] == '\n':
                        break
                    j += 1
                i = min(j + 1, n)
        elif ch == "'":
            # char literal: 'x' or '\e' — skip it whole so a '"' or '/'
            # inside it never starts a string or a comment.
            j = i + 1
            if j < n and text[j] == '\\':
                j += 2
            else:
                j += 1
            if j < n and text[j] == "'":
                i = j + 1
            else:
                i += 1
        elif text.startswith('//', i):
            j = text.find('\n', i)
            if j == -1:
                j = n
            for k in range(i, j):
                chars[k] = ' '
            i = j
        elif text.startswith('/*', i):
            j = text.find('*/', i + 2)
            j = n if j == -1 else j + 2
            for k in range(i, j):
                if chars[k] != '\n':
                    chars[k] = ' '
            i = j
        else:
            i += 1
    return ''.join(chars)


def extract_literals(text):
    """Extract string literals, merging ones concatenated with + (the usual
    Java SQL-building pattern), replacing injected variables with ?.
    Text blocks and "..." strings are matched by one regex over the
    original text, so their spans share one coordinate space and a text
    block followed by + "..." merges like any other concatenation.
    Comment spans are masked first (R7-G11), so a SQL string inside a
    comment is dead code, not a live literal."""
    # R7-G11: mask comment spans before extracting (string spans are
    # protected by the masker's left-to-right pass); positions are
    # preserved, so the merge logic below still works on the same
    # coordinates.
    text = _mask_comments(text)
    spans = []
    for m in LITERAL_RE.finditer(text):
        if m.group(1) is not None:
            spans.append((m.start(), m.end(), m.group(1)))
        else:
            raw = m.group(0)[1:-1]
            try:
                val = bytes(raw, 'utf-8').decode('unicode_escape')
            except Exception:
                val = raw
            spans.append((m.start(), m.end(), val))
    spans.sort()
    # R5-G12: one bracketed index (args[0]) or parenthesised expression
    # may sit between fragments, as well as a plain identifier/call.
    # The separator regex is the shared module-level BETWEEN_RE (see
    # above); the tree imports the same constant.
    merged, cur = [], None
    for s, e, val in spans:
        if cur and BETWEEN_RE.match(text[cur[1]:s]):
            cur = (cur[0], e, cur[2] + ' ? ' + val)
        else:
            if cur:
                merged.append(cur[2])
            cur = (s, e, val)
    if cur:
        merged.append(cur[2])
    return merged


def analyze_file(path, repo, ignore=None):
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            text = f.read()
    except OSError:
        return None
    literals = extract_literals(text)
    code = strip_comments(TEXTBLOCK_RE.sub('""', STRING_RE.sub('""', text)))
    # prepareCall extraction must run on text with literals still intact:
    # PREPCALL needs 1+ chars inside the quotes, so on the stripped code
    # (all literals "") it could never match. Comments are stripped so a
    # commented-out call is not counted.
    code_pre_strip = strip_comments(text)

    pkg = PACKAGE_RE.search(code)
    package = pkg.group(1) if pkg else ''
    imports, ignored_imports = split_kept_ignored_ordered(
        [m.group(2) for m in IMPORT_RE.finditer(code)],
        ignore.ignore_import) if ignore else (
        [m.group(2) for m in IMPORT_RE.finditer(code)], [])
    classes = [m.group(3) for m in CLASS_RE.finditer(code)]

    jdbc = {name: len(pat.findall(code)) for name, pat in JDBC_SIGNALS.items()}

    sql_lits = [l for l in literals if SQL_KEYWORDS.search(l)]
    reads, writes, procs = set(), set(), set()
    for lit in sql_lits:
        # R5-G6: reads come from _read_tables (the same _from_tables
        # parse extract_table_columns uses); writes keep the
        # TABLE_PATTERNS patterns (INSERT INTO / UPDATE..SET / MERGE INTO).
        reads |= _read_tables(lit)
        one = ' '.join(lit.split())
        for pat, kind in TABLE_PATTERNS:
            if kind != 'write':
                continue
            for m in pat.finditer(one):
                name = m.group(1).upper()
                if _is_dual(name):
                    continue
                writes.add(name)
        for m in PROC_CALL.finditer(one):
            procs.add(m.group(1).upper())
    for m in PREPCALL.finditer(code_pre_strip):
        arg = m.group(1)
        if arg.lstrip().startswith('{'):
            # "{call ...}" form: already extracted by PROC_CALL from the
            # literal itself; re-adding it here would mangle the name.
            continue
        procs.add(re.sub(r'[\s{(]', '', arg).upper().rstrip(')'))
    if ignore:
        reads, ignored_reads = split_kept_ignored(reads, ignore.ignore_object)
        writes, ignored_writes = split_kept_ignored(writes, ignore.ignore_object)
        procs, ignored_procs = split_kept_ignored(procs, ignore.ignore_object)
    else:
        ignored_reads = ignored_writes = ignored_procs = []

    isms = {name: len(pat.findall(' '.join(sql_lits))) for name, pat in ORACLE_ISMS.items()}
    isms = {k: v for k, v in isms.items() if v}

    table_columns = {}
    unattributed = set()
    for lit in sql_lits:
        tc, un = extract_table_columns(lit)
        for t, kinds in tc.items():
            entry = table_columns.setdefault(t, {'read': set(), 'write': set()})
            entry['read'].update(kinds['read'])
            entry['write'].update(kinds['write'])
        unattributed.update(un)
    if ignore:
        ignored_cols = {t: v for t, v in table_columns.items()
                        if ignore.ignore_object(t)}
        table_columns = {t: v for t, v in table_columns.items()
                         if not ignore.ignore_object(t)}
        # Unattributed columns from ignored objects leak through unless
        # filtered too: PREFIX.NAME is filtered on its prefix, a bare
        # name on the name itself.
        unattributed = {u for u in unattributed
                        if not ignore.ignore_object(u.split('.')[0])}
    else:
        ignored_cols = {}

    loc = sum(1 for ln in code.splitlines() if ln.strip())
    branches = len(BRANCH_RE.findall(code))
    methods = len(METHOD_RE.findall(code))
    has_main = bool(re.search(r'public\s+static\s+void\s+main\s*\(', code))

    return {
        'path': path, 'repo': repo, 'package': package,
        'classes': classes, 'imports': imports,
        'jdbc': {k: v for k, v in jdbc.items() if v},
        'sql_literal_count': len(sql_lits),
        'sql_sample': [' '.join(l.split())[:300] for l in sql_lits[:10]],
        'tables_read': sorted(reads), 'tables_written': sorted(writes),
        'ignored_tables': sorted(set(ignored_reads) | set(ignored_writes)),
        'ignored_procs': ignored_procs,
        'ignored_imports': ignored_imports,
        'ignored_table_columns': {t: {'read': sorted(v['read']),
                                      'write': sorted(v['write'])}
                                  for t, v in sorted(ignored_cols.items())},
        'table_columns': {t: {'read': sorted(v['read']), 'write': sorted(v['write'])}
                          for t, v in sorted(table_columns.items())},
        'columns_unattributed': sorted(unattributed),
        'procs_called': sorted(procs),
        'oracle_isms': isms,
        'metrics': {'loc': loc, 'branches': branches,
                    'methods_rough': methods, 'has_main': has_main},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--repo', required=True)
    ap.add_argument('--ignore', default='')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    ignore = load_ignore(a.ignore)
    records = []
    for dirpath, _, filenames in os.walk(a.root):
        for fn in filenames:
            if fn.endswith('.java'):
                rec = analyze_file(os.path.join(dirpath, fn), a.repo, ignore)
                if rec:
                    records.append(rec)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(records, f, indent=1)
    print(f'scanned {len(records)} java files -> {a.out}')


if __name__ == '__main__':
    main()
