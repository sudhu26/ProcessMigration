#!/usr/bin/env python3
"""Merge scanner outputs into dependency graphs and per-process units.
Stdlib only.

Usage: build_graph.py --java java.json --plsql plsql.json --jobs jobs.json
                      [--scripts scripts.json] --outdir <dir>
Writes: dependency-graph.json, units.json, db-object-catalog.json
"""
import argparse, json, os, sys
from collections import defaultdict

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ignore_lists import load_ignore  # noqa: E402


def load(p, default):
    if p and os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    return default


def apply_ignore(java_files, plsql_files, ignore):
    """Filter already-scanned records by an ignore list (same effect as
    scanning with --ignore, for data scanned before the list existed).
    Returns (java_files, plsql_files) with ignored items removed."""
    if not ignore:
        return java_files, plsql_files
    for rec in java_files:
        rec['imports'] = [i for i in rec.get('imports', [])
                          if not ignore.ignore_import(i)]
        rec['tables_read'] = [t for t in rec.get('tables_read', [])
                              if not ignore.ignore_object(t)]
        rec['tables_written'] = [t for t in rec.get('tables_written', [])
                                 if not ignore.ignore_object(t)]
        rec['procs_called'] = [p for p in rec.get('procs_called', [])
                               if not ignore.ignore_object(p)]
        rec['table_columns'] = {t: v for t, v in
                                rec.get('table_columns', {}).items()
                                if not ignore.ignore_object(t)}
        # R7-G5: columns_unattributed leaks ignored names unless filtered
        # too — same rule as the scanners (scan_java.py / scan_plsql.py):
        # a dotted entry is filtered on its first segment (the object
        # prefix), a bare entry on the name itself.
        if 'columns_unattributed' in rec:
            rec['columns_unattributed'] = [
                u for u in rec.get('columns_unattributed', [])
                if not ignore.ignore_object(u.split('.')[0])]
    for rec in plsql_files:
        rec['reads'] = [t for t in rec.get('reads', [])
                        if not ignore.ignore_object(t)]
        rec['writes'] = [t for t in rec.get('writes', [])
                         if not ignore.ignore_object(t)]
        rec['references'] = [t for t in rec.get('references', [])
                             if not ignore.ignore_object(t)]
        rec['calls'] = [c for c in rec.get('calls', [])
                        if not ignore.ignore_object(c)]
        rec['ddl_columns'] = {t: v for t, v in
                              rec.get('ddl_columns', {}).items()
                              if not ignore.ignore_object(t)}
        rec['table_columns'] = {t: v for t, v in
                                rec.get('table_columns', {}).items()
                                if not ignore.ignore_object(t)}
        # R7-G5: same rule as the scanners — dotted on the first segment,
        # bare on the name itself. This also covers the script-SQL
        # records: script_sql holds references to these same plsql
        # record objects, so the columns they contribute at ~line 403
        # (cols_unattributed.update(prec...)) are already filtered here.
        if 'columns_unattributed' in rec:
            rec['columns_unattributed'] = [
                u for u in rec.get('columns_unattributed', [])
                if not ignore.ignore_object(u.split('.')[0])]
    return java_files, plsql_files


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--java', default='')
    ap.add_argument('--plsql', default='')
    ap.add_argument('--jobs', default='')
    ap.add_argument('--scripts', default='',
                    help='scan_scripts.py output (shell/python/perl invocations)')
    ap.add_argument('--ignore', default='',
                    help='ignore.json: Java imports / Oracle objects to exclude')
    ap.add_argument('--only', default='',
                    help='comma-separated unit IDs to keep; everything else is '
                         'pruned (dependency inference still uses the full estate)')
    ap.add_argument('--outdir', required=True)
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)

    java_files = load(a.java, [])
    plsql_files = load(a.plsql, [])
    jobs = load(a.jobs, [])
    script_recs = load(a.scripts, [])
    java_files, plsql_files = apply_ignore(java_files, plsql_files,
                                           load_ignore(a.ignore))

    nodes, edges = {}, []
    def node(nid, kind, name, repo=''):
        if nid not in nodes:
            nodes[nid] = {'id': nid, 'kind': kind, 'name': name, 'repo': repo}

    # --- class index: FQN -> record, simple name -> fqns ---
    fqn_index, simple_index = {}, defaultdict(list)
    for rec in java_files:
        for cls in rec['classes']:
            fqn = f"{rec['package']}.{cls}" if rec['package'] else cls
            fqn_index[fqn] = rec
            simple_index[cls].append(fqn)
            node(f'java:{fqn}', 'java_class', fqn, rec['repo'])

    # --- db object index ---
    db_defs = {}
    for rec in plsql_files:
        for d in rec['definitions']:
            db_defs.setdefault(d['name'], d)
            node(f"db:{d['name']}", 'db_object', d['name'], rec['repo'])
    # also index objects only ever referenced (not defined in scan)
    def db_node(name, repo=''):
        node(f'db:{name}', 'db_object', name, repo)

    # --- per-DB-object read/write sets, for transitive data-flow inference ---
    db_access = {}
    for rec in plsql_files:
        for d in rec['definitions']:
            acc = db_access.setdefault(d['name'], {'reads': set(), 'writes': set()})
            acc['reads'].update(rec.get('reads', []))
            acc['writes'].update(rec.get('writes', []))
    # --- per-DB-object column sets, for the via-proc column merge (B5) ---
    # object name -> table -> {'read': set, 'write': set}, from the record(s)
    # that define the object
    def_table_cols = defaultdict(dict)
    for rec in plsql_files:
        for d in rec['definitions']:
            tc = def_table_cols[d['name']]
            for t, kinds in rec.get('table_columns', {}).items():
                e = tc.setdefault(t, {'read': set(), 'write': set()})
                e['read'].update(kinds.get('read', []))
                e['write'].update(kinds.get('write', []))

    # --- referenced-but-undefined objects, for the catalog (G13) ---
    # name -> inferred kind ('TABLE' for read/write references,
    # 'PROCEDURE' for call references, 'UNKNOWN' if neither is known)
    ref_kinds = {}
    for rec in java_files:
        for t in rec.get('tables_read', []) + rec.get('tables_written', []):
            ref_kinds.setdefault(t, 'TABLE')
        for p in rec.get('procs_called', []):
            ref_kinds.setdefault(p, 'PROCEDURE')
    for rec in plsql_files:
        for t in rec.get('references', []):
            ref_kinds.setdefault(t, 'TABLE')
        for c in rec.get('calls', []):
            ref_kinds.setdefault(c, 'PROCEDURE')

    # --- java -> java (imports) and java -> db edges ---
    file_edges = defaultdict(list)
    for rec in java_files:
        src = None
        fqns = [f"{rec['package']}.{c}" if rec['package'] else c
                for c in rec['classes']]
        for imp in rec['imports']:
            if imp in fqn_index:
                for fqn in fqns:
                    edges.append({'src': f'java:{fqn}', 'dst': f'java:{imp}',
                                  'kind': 'imports'})
                    file_edges[rec['path']].append(fqn_index[imp]['path'])
        for fqn in fqns:
            for t in rec['tables_read']:
                db_node(t); edges.append({'src': f'java:{fqn}', 'dst': f'db:{t}',
                                          'kind': 'reads'})
            for t in rec['tables_written']:
                db_node(t); edges.append({'src': f'java:{fqn}', 'dst': f'db:{t}',
                                          'kind': 'writes'})
            for p in rec['procs_called']:
                db_node(p); edges.append({'src': f'java:{fqn}', 'dst': f'db:{p}',
                                          'kind': 'calls'})

    # --- db -> db (plsql references / calls) ---
    for rec in plsql_files:
        owners = [d['name'] for d in rec['definitions']] or [rec['path']]
        for owner in owners:
            db_node(owner, rec['repo'])
            for ref in rec['references']:
                if ref == owner:
                    continue
                db_node(ref)
                edges.append({'src': f'db:{owner}', 'dst': f'db:{ref}',
                              'kind': 'references'})
            for call in rec['calls']:
                if call == owner:
                    continue
                db_node(call)
                edges.append({'src': f'db:{owner}', 'dst': f'db:{call}',
                              'kind': 'calls'})

    # --- script internals: what shell/python/perl scripts invoke ---
    # Production paths in job commands (e.g. /opt/risk/bin/x.sh) rarely match
    # repo checkout paths, so scripts are resolved by basename.
    script_by_base = defaultdict(list)
    for srec in script_recs:
        script_by_base[os.path.basename(srec['path']).lower()].append(srec)
    sql_by_base = defaultdict(list)
    for prec in plsql_files:
        sql_by_base[os.path.basename(prec['path']).lower()].append(prec)

    def resolve_script(base):
        cands = script_by_base.get(base.lower(), [])
        if len(cands) > 1:
            print(f"warning: {len(cands)} scanned scripts match basename "
                  f"'{base}'; using {cands[0]['path']}", file=sys.stderr)
        return cands[0] if cands else None

    script_java = defaultdict(list)    # script node id -> [java FQN]
    script_script = defaultdict(list)  # script node id -> [script node id]
    script_sql = defaultdict(list)     # script node id -> [plsql record]
    script_rec_by_id = {}              # script node id -> scan record
    for srec in script_recs:
        sid = f"script:{srec['path']}"
        script_rec_by_id[sid] = srec
        node(sid, 'script', os.path.basename(srec['path']), srec['repo'])
        for jm in srec.get('java_mains', []):
            if jm in fqn_index:
                edges.append({'src': sid, 'dst': f'java:{jm}', 'kind': 'invokes'})
                script_java[sid].append(jm)
        for sc in srec.get('scripts_called', []):
            # resolve by basename, like job->script: production paths in
            # scripts rarely match checkout paths (G16)
            hit = resolve_script(os.path.basename(sc))
            tid = f"script:{hit['path']}" if hit else f'script:{sc}'
            node(tid, 'script', os.path.basename(sc))
            edges.append({'src': sid, 'dst': tid, 'kind': 'invokes'})
            script_script[sid].append(tid)
        for sq in srec.get('sql_files', []):
            cands = sql_by_base.get(os.path.basename(sq).lower(), [])
            if cands and cands[0] not in script_sql[sid]:
                script_sql[sid].append(cands[0])
                node(f"sql:{cands[0]['path']}", 'sql_file', cands[0]['path'],
                     cands[0]['repo'])
                edges.append({'src': sid, 'dst': f"sql:{cands[0]['path']}",
                              'kind': 'invokes'})
        for jr in srec.get('jars', []):
            jb = os.path.basename(jr)
            jnode = f'jar:{jb}'
            node(jnode, 'jar', jb)
            edges.append({'src': sid, 'dst': jnode, 'kind': 'uses'})

    # --- jobs -> code ---
    for job in jobs:
        jid = f"job:{job['job_name']}"
        node(jid, 'job', job['job_name'])
        mc = job.get('main_class')
        if mc and mc in fqn_index:
            edges.append({'src': jid, 'dst': f'java:{mc}', 'kind': 'invokes'})
        elif mc:
            for c in simple_index.get(mc.split('.')[-1], []):
                edges.append({'src': jid, 'dst': f'java:{c}',
                              'kind': 'invokes_maybe'})
        for s in job.get('scripts', []):
            base = os.path.basename(s)
            hit = resolve_script(base)
            sid = f"script:{hit['path']}" if hit else f'script:{s}'
            node(sid, 'script', base)
            edges.append({'src': jid, 'dst': sid, 'kind': 'invokes'})
        for jr in job.get('jars', []):
            jb = os.path.basename(jr)
            jnode = f'jar:{jb}'
            node(jnode, 'jar', jb)
            edges.append({'src': jid, 'dst': jnode, 'kind': 'uses'})
        for dep in job.get('depends_on', []):
            node(f'job:{dep}', 'job', dep)
            edges.append({'src': jid, 'dst': f'job:{dep}', 'kind': 'depends_on'})
        for p in job.get('parent_jobs', []):
            node(f'job:{p}', 'job', p)
            edges.append({'src': jid, 'dst': f'job:{p}', 'kind': 'child_of'})

    # --- Java entry points missing from scheduler data always become units ---
    # (the scheduler export may be incomplete; code-discovered processes must
    # not be silently dropped)
    covered_fqns = set()
    for e in edges:
        if (e['src'].startswith('job:') and e['dst'].startswith('java:')
                and e['kind'] in ('invokes', 'invokes_maybe')):
            covered_fqns.add(e['dst'][5:])
    # R7-B2: script-mediated coverage — a main invoked only via a wrapper
    # script a job names is covered, not synthetic. BFS each job's own
    # scripts (following script->script) and add every reached
    # script_java FQN to covered_fqns before synthetic creation. A main
    # invoked only by a script no job names is genuinely unreferenced
    # and still becomes synthetic (it is never reached from a job seed).
    _job_scripts = defaultdict(list)
    for e in edges:
        if (e['src'].startswith('job:') and e['dst'].startswith('script:')
                and e['kind'] == 'invokes'):
            _job_scripts[e['src']].append(e['dst'])
    for _jid, _sids in _job_scripts.items():
        _seen_scripts, _stack = set(), list(_sids)
        while _stack:
            _sid = _stack.pop()
            if _sid in _seen_scripts:
                continue
            _seen_scripts.add(_sid)
            covered_fqns.update(script_java.get(_sid, []))
            _stack.extend(script_script.get(_sid, []))
    seen_fqn = set()
    for rec in java_files:
        if rec['metrics'].get('has_main'):
            for cls in rec['classes'][:1]:
                fqn = f"{rec['package']}.{cls}" if rec['package'] else cls
                if fqn not in covered_fqns and fqn not in seen_fqn:
                    seen_fqn.add(fqn)
                    jobs.append({'job_name': f'main:{fqn}', 'command': '',
                                 'host': '', 'schedule': '', 'depends_on': [],
                                 'parent_jobs': [], 'main_class': fqn,
                                 'scripts': [], 'jars': [], 'synthetic': True})
                    node(f'job:main:{fqn}', 'job', f'main:{fqn}')
                    edges.append({'src': f'job:main:{fqn}', 'dst': f'java:{fqn}',
                                  'kind': 'invokes'})

    # --- per-process units: entry files + import closure ---
    # Linkage quality: 'ok' (exact FQN or script-resolved match), 'maybe'
    # (simple class-name match only, e.g. file has no package declaration),
    # 'missing' (no code linked at all).
    path_index = {r['path']: r for r in java_files}
    job_java_exact, job_java_maybe, job_scripts = (
        defaultdict(list), defaultdict(list), defaultdict(list))
    for e in edges:
        if not e['src'].startswith('job:'):
            continue
        if e['dst'].startswith('java:'):
            if e['kind'] == 'invokes':
                job_java_exact[e['src']].append(e['dst'][5:])
            elif e['kind'] == 'invokes_maybe':
                job_java_maybe[e['src']].append(e['dst'][5:])
        elif e['dst'].startswith('script:') and e['kind'] == 'invokes':
            job_scripts[e['src']].append(e['dst'])

    units = []
    for job in jobs:
        jid = f"job:{job['job_name']}"
        # script-mediated entry points: BFS over script->script, then
        # script->java and script->sql. Seed with the job's own scripts AND
        # wrapper scripts that invoke the job's entry Java mains (a job
        # command often calls Java directly while a wrapper script invokes
        # the same main — the wrapper's sqlplus files still belong to the
        # process).
        exact_fqns = job_java_exact.get(jid, [])
        maybe_fqns = job_java_maybe.get(jid, [])
        java_to_scripts = defaultdict(list)
        for sid, fqns_ in script_java.items():
            for f in fqns_:
                java_to_scripts[f].append(sid)
        script_fqns, script_sqls, script_seen = [], [], set()
        stack = list(job_scripts.get(jid, []))
        for f in exact_fqns + maybe_fqns:
            stack.extend(java_to_scripts.get(f, []))
        while stack:
            sid = stack.pop()
            if sid in script_seen:
                continue
            script_seen.add(sid)
            script_fqns.extend(script_java.get(sid, []))
            for prec in script_sql.get(sid, []):
                if prec not in script_sqls:
                    script_sqls.append(prec)
            stack.extend(script_script.get(sid, []))
        fqns = list(dict.fromkeys(exact_fqns + script_fqns + maybe_fqns))
        entry_paths = [fqn_index[f]['path'] for f in fqns if f in fqn_index]
        unit_jars = {os.path.basename(j) for j in job.get('jars', []) if j}
        for sid in script_seen:
            srec = script_rec_by_id.get(sid)
            if srec:
                unit_jars.update(os.path.basename(j)
                                 for j in srec.get('jars', []) if j)
        if exact_fqns or script_fqns:
            linkage = 'ok'
        elif maybe_fqns:
            linkage = 'maybe'
        else:
            linkage = 'missing'
        # import closure, depth-limited
        seen, frontier = set(entry_paths), list(entry_paths)
        for _ in range(3):
            nxt = []
            for p in frontier:
                for q in file_edges.get(p, []):
                    if q not in seen:
                        seen.add(q); nxt.append(q)
            frontier = nxt
        # R5-B1: sort by path — iterating the `seen` set directly made
        # java_files order follow CPython string-hash randomization and
        # flip run to run. Sorted-by-path matches the entry_points
        # sorted(set(...)) convention already used below.
        files = [path_index[p] for p in sorted(seen) if p in path_index]

        agg = {'loc': 0, 'branches': 0, 'methods': 0, 'sql_literals': 0,
               'jdbc_sites': 0, 'proc_calls': 0, 'oracle_ism_total': 0,
               'writes': 0}
        # Per-table evidence is tracked per source tier so the final kind
        # follows the precedence rule (G11):
        #   direct write > direct read > transitive write > transitive read
        # (transitive = via_proc / via_script; script tier beats proc tier
        # for the same direction). A direct read that also has a transitive
        # write keeps kind 'read' and records the transitive write in
        # 'transitive_write' instead of being upgraded.
        direct_read, direct_write = set(), set()
        via_proc_read, via_proc_write = set(), set()
        via_script_read, via_script_write = set(), set()
        procs, isms, repos = set(), defaultdict(int), set()
        table_cols = defaultdict(lambda: {'read': set(), 'write': set()})
        cols_unattributed = set()
        for r in files:
            m = r['metrics']
            agg['loc'] += m['loc']; agg['branches'] += m['branches']
            agg['methods'] += m['methods_rough']
            agg['sql_literals'] += r['sql_literal_count']
            agg['jdbc_sites'] += sum(r['jdbc'].values())
            agg['proc_calls'] += len(r['procs_called'])
            agg['oracle_ism_total'] += sum(r['oracle_isms'].values())
            agg['writes'] += sum(r['jdbc'].get(k, 0)
                                 for k in ('executeUpdate', 'executeBatch', 'addBatch'))
            direct_read.update(r['tables_read'])
            direct_write.update(r['tables_written'])
            for t, kinds in r.get('table_columns', {}).items():
                table_cols[t]['read'].update(kinds.get('read', []))
                table_cols[t]['write'].update(kinds.get('write', []))
            cols_unattributed.update(r.get('columns_unattributed', []))
            procs.update(r['procs_called'])
            for k, v in r['oracle_isms'].items():
                isms[k] += v
            repos.add(r['repo'])
        # DB access from SQL files invoked by the job's scripts (sqlplus @file)
        for prec in script_sqls:
            via_script_read.update(prec.get('reads', []))
            via_script_write.update(prec.get('writes', []))
            for t, kinds in prec.get('table_columns', {}).items():
                table_cols[t]['read'].update(kinds.get('read', []))
                table_cols[t]['write'].update(kinds.get('write', []))
            cols_unattributed.update(prec.get('columns_unattributed', []))
            new_calls = [c for c in prec.get('calls', []) if c not in procs]
            procs.update(new_calls)
            agg['proc_calls'] += len(new_calls)
        # transitive DB access through called PL/SQL objects (one hop):
        # a unit that calls a proc effectively reads/writes what the proc touches
        for p in sorted(procs):
            key = p if p in db_access else p.split('.')[0]
            acc = db_access.get(key)
            if not acc:
                continue
            via_proc_read.update(acc['reads'])
            via_proc_write.update(acc['writes'])
            # B5: merge columns from the defining PL/SQL record(s) so a
            # via-proc table carries the columns the proc actually touches
            for t, kinds in def_table_cols.get(key, {}).items():
                table_cols[t]['read'].update(kinds.get('read', []))
                table_cols[t]['write'].update(kinds.get('write', []))
        db_objects = []
        for t in sorted(direct_read | direct_write | via_proc_read |
                        via_proc_write | via_script_read | via_script_write):
            transitive_write = None
            if t in direct_write:
                kind = 'write'
            elif t in direct_read:
                kind = 'read'
                if t in via_script_write:
                    transitive_write = 'write_via_script'
                elif t in via_proc_write:
                    transitive_write = 'write_via_proc'
            elif t in via_script_write:
                kind = 'write_via_script'
            elif t in via_proc_write:
                kind = 'write_via_proc'
            elif t in via_script_read:
                kind = 'read_via_script'
            else:
                kind = 'read_via_proc'
            entry = {'name': t, 'kind': kind,
                     'columns_read': sorted(table_cols.get(t, {}).get('read', [])),
                     'columns_written': sorted(table_cols.get(t, {}).get('write', []))}
            if transitive_write:
                entry['transitive_write'] = transitive_write
            db_objects.append(entry)
        # G10: 'call' entries carry the column keys too (empty), so consumers
        # can index d['columns_read'] / d['columns_written'] per the spec
        db_objects += [{'name': p, 'kind': 'call', 'columns_read': [],
                        'columns_written': []} for p in sorted(procs)]

        units.append({
            'unit_id': job['job_name'], 'job_name': job['job_name'],
            'command': job.get('command', ''), 'schedule': job.get('schedule', ''),
            'depends_on': job.get('depends_on', []),
            'parent_jobs': job.get('parent_jobs', []),
            'entry_points': sorted(set(entry_paths)),
            'java_file_count': len(files),
            'java_files': [{'path': r['path'], 'repo': r['repo'],
                            'classes': r['classes']} for r in files],
            'metrics': agg,
            'db_objects': db_objects,
            'oracle_isms': dict(isms),
            'repos': sorted(repos),
            'linkage': linkage,
            'linkage_candidates': sorted(set(maybe_fqns)) if linkage == 'maybe' else [],
            'synthetic': bool(job.get('synthetic', False)),
            'jars': sorted(unit_jars),
            'columns_unattributed': sorted(cols_unattributed),
        })

    # --- data-flow inference: if unit A writes a table that unit B reads,
    #     B likely depends on A. Heuristic ordering for wave planning when no
    #     scheduler data exists; agents/humans validate during review. ---
    READ_KINDS = ('read', 'read_via_proc', 'read_via_script')
    WRITE_KINDS = ('write', 'write_via_proc', 'write_via_script')
    unit_reads, unit_writes = {}, {}
    for u in units:
        unit_reads[u['unit_id']] = {d['name'] for d in u['db_objects']
                                    if d['kind'] in READ_KINDS}
        # a direct-read table with a recorded transitive write still counts
        # as a writer of that table (G11), or the data-flow edge to its
        # readers would be lost
        unit_writes[u['unit_id']] = {d['name'] for d in u['db_objects']
                                     if d['kind'] in WRITE_KINDS
                                     or d.get('transitive_write')}
    writers_of = defaultdict(set)
    for uid, ts in unit_writes.items():
        for t in ts:
            writers_of[t].add(uid)
    # R-G2: a job and its own wrapper share the same entry files (same
    # code closure), so each writes what the other reads and the heuristic
    # would infer mutual likely_depends_on edges — noise for wave
    # ordering, and it puts the wrapper in both SVG layers of the doc.
    # Skip pairs where one unit's entry files are a subset of the other's.
    entry_sets = {u['unit_id']: set(u.get('entry_points', [])) for u in units}

    def _same_closure(a, b):
        ea, eb = entry_sets.get(a, set()), entry_sets.get(b, set())
        return bool(ea) and bool(eb) and (ea <= eb or eb <= ea)

    required_by = defaultdict(set)
    for u in units:
        rid = u['unit_id']
        upstream = defaultdict(set)
        for t in unit_reads[rid]:
            for wid in writers_of.get(t, ()):
                if wid != rid and not _same_closure(rid, wid):
                    upstream[wid].add(t)
        u['likely_depends_on'] = sorted(upstream)
        for wid in sorted(upstream):
            required_by[wid].add(rid)
            edges.append({'src': f'job:{rid}', 'dst': f'job:{wid}',
                          'kind': 'likely_depends_on',
                          'via': sorted(upstream[wid])})
    for u in units:
        u['likely_required_by'] = sorted(required_by.get(u['unit_id'], []))
    n_inferred = sum(len(u['likely_depends_on']) for u in units)

    def _defined_in(name):
        # R5-G14: a package member (PKG.MEMBER) is defined inside the
        # package body, so attribute it to the owning package's file(s)
        # when the member itself has no definition record of its own.
        paths = [r['path'] for r in plsql_files
                 if any(x['name'] == name for x in r['definitions'])]
        if not paths and '.' in name and name.split('.')[0] in db_defs:
            owner = name.split('.')[0]
            paths = [r['path'] for r in plsql_files
                     if any(x['name'] == owner for x in r['definitions'])]
        return paths

    catalog = [{'object': name,
                'kind': db_defs[name]['kind'] if name in db_defs
                        else ref_kinds.get(name, 'UNKNOWN'),
                'columns': sorted({c for r in plsql_files
                                   for c in r.get('ddl_columns', {}).get(name, [])}),
                'defined_in': _defined_in(name)}
               for name in sorted(set(db_defs) | set(ref_kinds))]

    only = {s.strip() for s in a.only.split(',') if s.strip()}
    if only:
        missing = only - {u['unit_id'] for u in units}
        if missing:
            print(f'warning: --only units not found: {sorted(missing)}',
                  file=sys.stderr)
        units = [u for u in units if u['unit_id'] in only]
        # G12: per-unit likely_* lists must not name units that were pruned
        # away, and the inferred count is computed AFTER pruning
        kept = {u['unit_id'] for u in units}
        for u in units:
            u['likely_depends_on'] = [x for x in u['likely_depends_on']
                                      if x in kept]
            u['likely_required_by'] = [x for x in u['likely_required_by']
                                       if x in kept]
        n_inferred = sum(len(u['likely_depends_on']) for u in units)
        # prune the graph to the selected jobs' 3-hop neighbourhood
        # (scripts, jars, Java files, DB objects, upstream/downstream jobs)
        adj = defaultdict(set)
        for e in edges:
            adj[e['src']].add(e['dst'])
            adj[e['dst']].add(e['src'])
        keep = {f"job:{u['unit_id']}" for u in units}
        frontier = set(keep)
        for _ in range(3):
            nxt = set()
            for n in frontier:
                nxt |= adj.get(n, set())
            nxt -= keep
            keep |= nxt
            frontier = nxt
        edges = [e for e in edges if e['src'] in keep and e['dst'] in keep]
        nodes = {nid: n for nid, n in nodes.items() if nid in keep}
        touched = {d['name'] for u in units for d in u['db_objects']}
        # a unit touches PKG.PROC; the catalog is keyed by the package PKG
        touched |= {t.split('.')[0] for t in touched}
        catalog = [c for c in catalog if c['object'] in touched]

    with open(os.path.join(a.outdir, 'dependency-graph.json'), 'w') as f:
        json.dump({'nodes': list(nodes.values()), 'edges': edges}, f, indent=1)
    with open(os.path.join(a.outdir, 'units.json'), 'w') as f:
        json.dump(units, f, indent=1)
    with open(os.path.join(a.outdir, 'db-object-catalog.json'), 'w') as f:
        json.dump(catalog, f, indent=1)
    print(f'{len(nodes)} nodes, {len(edges)} edges, {len(units)} units, '
          f'{n_inferred} inferred data-flow dependencies -> {a.outdir}')


if __name__ == '__main__':
    main()
