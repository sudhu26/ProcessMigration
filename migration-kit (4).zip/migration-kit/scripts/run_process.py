#!/usr/bin/env python3
"""Run the whole pipeline for one (or a few) processes.

Usage:
  run_process.py --process NIGHTLY_RISK_JOB \\
      --repos Risk_DB=/path/Risk_DB,Risk_DL=/path/Risk_DL,CoreWM=/path/CoreWM \\
      --jobs jobs.csv [--ignore ignore.json] [--outdir runs/NIGHTLY_RISK_JOB]

The scan phase still runs over the full repos — dependency inference needs
the whole estate — but every output is filtered to the named process(es):
units.json, dependency-graph.json, db-object-catalog.json, the process HTML
doc, tables.md, the migration tree, and the review batches. That keeps a
4,000-process estate from turning into 4,000 documents when you only want
one. Stdlib only.
"""
import argparse, glob, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))


def run(cmd, step):
    print(f'== {step}')
    r = subprocess.run([sys.executable, *cmd])
    if r.returncode:
        sys.exit(f'!! {step} failed (exit {r.returncode})')


def merge(paths, out):
    recs = []
    for p in sorted(paths):
        with open(p, encoding='utf-8') as f:
            recs += json.load(f)
    with open(out, 'w', encoding='utf-8') as f:
        json.dump(recs, f, indent=1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--process', required=True,
                    help='process name(s), comma-separated — Autosys job name '
                         'or main:<fully-qualified-class> for a synthetic unit')
    ap.add_argument('--repos', required=True,
                    help='comma-separated RepoName=/path pairs')
    ap.add_argument('--jobs', default='',
                    help='scheduler export (Autosys CSV / Control-M XML/CSV)')
    ap.add_argument('--ignore', default='',
                    help='ignore.json: Java imports / Oracle objects to exclude')
    ap.add_argument('--patterns', default='',
                    help='patterns.json from learn_patterns.py (applied to '
                         'the migration tree)')
    ap.add_argument('--plsql-exts', default='.sql,.pks,.pkb,.fnc,.prc,.trg,.vw,.tab,.seq')
    ap.add_argument('--outdir', default='',
                    help='default: runs/<first-process>')
    a = ap.parse_args()
    procs = [s.strip() for s in a.process.split(',') if s.strip()]
    outdir = a.outdir or os.path.join('runs', procs[0].replace(':', '_'))
    raw = os.path.join(outdir, 'state', 'raw')
    graph_dir = os.path.join(outdir, 'state', 'graph')
    units_dir = os.path.join(outdir, 'state', 'units')
    for d in (raw, graph_dir, units_dir):
        os.makedirs(d, exist_ok=True)
    repos = {}
    for part in a.repos.split(','):
        name, _, path = part.partition('=')
        repos[name.strip()] = path.strip()
    ig = ['--ignore', a.ignore] if a.ignore else []
    pat = ['--patterns', a.patterns] if a.patterns else []

    # --- scan (full estate; cheap and needed for inference) ---
    for repo, root in repos.items():
        run([os.path.join(HERE, 'scan_java.py'), '--root', root,
             '--repo', repo, *ig,
             '--out', os.path.join(raw, f'java_{repo}.json')], f'scan_java {repo}')
        run([os.path.join(HERE, 'scan_plsql.py'), '--root', root,
             '--repo', repo, '--exts', a.plsql_exts, *ig,
             '--out', os.path.join(raw, f'plsql_{repo}.json')], f'scan_plsql {repo}')
        run([os.path.join(HERE, 'scan_scripts.py'), '--root', root,
             '--repo', repo,
             '--out', os.path.join(raw, f'scripts_{repo}.json')], f'scan_scripts {repo}')
    jobs_out = os.path.join(raw, 'jobs.json')
    if a.jobs:
        run([os.path.join(HERE, 'scan_jobs.py'), '--export', a.jobs,
             '--out', jobs_out], 'scan_jobs')
    else:
        json.dump([], open(jobs_out, 'w'))
    merge(glob.glob(os.path.join(raw, 'java_*.json')),
          os.path.join(raw, 'java_all.json'))
    merge(glob.glob(os.path.join(raw, 'plsql_*.json')),
          os.path.join(raw, 'plsql_all.json'))
    merge(glob.glob(os.path.join(raw, 'scripts_*.json')),
          os.path.join(raw, 'scripts_all.json'))

    # --- graph, filtered to the named process(es) ---
    run([os.path.join(HERE, 'build_graph.py'),
         '--java', os.path.join(raw, 'java_all.json'),
         '--plsql', os.path.join(raw, 'plsql_all.json'),
         '--scripts', os.path.join(raw, 'scripts_all.json'),
         '--jobs', jobs_out, *ig, '--only', ','.join(procs),
         '--outdir', graph_dir], 'build_graph (filtered)')
    run([os.path.join(HERE, 'classify.py'), '--units',
         os.path.join(graph_dir, 'units.json')], 'classify')

    # --- per-process outputs ---
    out_docs = os.path.join(outdir, 'output', 'process-docs')
    run([os.path.join(HERE, 'build_process_docs.py'),
         '--units', os.path.join(graph_dir, 'units.json'),
         '--graph', os.path.join(graph_dir, 'dependency-graph.json'),
         '--java', os.path.join(raw, 'java_all.json'),
         '--verdicts', units_dir, '--only', ','.join(procs),
         '--outdir', out_docs], 'build_process_docs (filtered)')
    run([os.path.join(HERE, 'build_table_catalog.py'),
         '--units', os.path.join(graph_dir, 'units.json'),
         '--plsql', os.path.join(raw, 'plsql_all.json'),
         '--only', ','.join(procs),
         '--out', os.path.join(outdir, 'output', 'tables.md')],
        'build_table_catalog (filtered)')
    run([os.path.join(HERE, 'prepare_migration_tree.py'),
         '--repos', a.repos, *ig, *pat, '--only', ','.join(procs),
         '--units', os.path.join(graph_dir, 'units.json'),
         '--graph', os.path.join(graph_dir, 'dependency-graph.json'),
         '--catalog', os.path.join(graph_dir, 'db-object-catalog.json'),
         '--outdir', os.path.join(outdir, 'migration-tree')],
        'prepare_migration_tree (filtered)')
    run([os.path.join(HERE, 'make_batches.py'),
         '--units', os.path.join(graph_dir, 'units.json'),
         '--checkpoints', units_dir, '--only', ','.join(procs),
         '--out', os.path.join(outdir, 'batches.json')], 'make_batches (filtered)')

    print(f'\nDone. Outputs under {outdir}/:')
    print(f'  state/graph/units.json, dependency-graph.json, db-object-catalog.json')
    print(f'  output/process-docs/  (HTML doc for {", ".join(procs)})')
    print(f'  output/tables.md      (only the tables this process touches)')
    print(f'  migration-tree/       (only this process\'s files, mirrored 1:1)')
    print(f'  batches.json          (review batch for this process)')
    print(f'\nNext: review this process with the oracle-migration-review '
          f'workflow over {outdir}/batches.json (checkpoints land in '
          f'{units_dir}/), then re-run build_process_docs.py with '
          f'--verdicts {units_dir} to pick up the review summary in the doc.')


if __name__ == '__main__':
    main()
