package com.risk.edge;

/** Commented-out Java SQL regression (R7-G11): SQL string literals
 *  inside // and block comments are dead code, not live SQL.
 *  Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (CommentedSql.java record): tables_read ['T_LIVE'],
 *  sql_literal_count 1. */
public class CommentedSql {

    public void run(java.sql.Statement st) throws Exception {
        // String dead = "SELECT a FROM t_dead";
        /* String dead2 = "SELECT b FROM t_dead2"; */
        String live = "SELECT c FROM t_live";
        st.executeQuery(live);
    }
}
