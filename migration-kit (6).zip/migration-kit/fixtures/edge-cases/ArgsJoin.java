package com.risk.edge;

/** args[0]- / (var)-joined fragments must merge in the tree (R6-B1):
 *  the tree's `between` regex must be identical to scan_java.py's, or a
 *  fragment joined by `args[0]` or `(suffix)` is silently dropped from
 *  the tree while the scanner counts it. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  and mirrored with prepare_migration_tree.py over a repo containing
 *  this file. Expected: the scanner reports one merged literal
 *  `SELECT a FROM t ? WHERE ROWNUM <= 5` with oracle_isms {ROWNUM: 1}
 *  for each ROWNUM method; the tree produces a bundle item for the
 *  ` WHERE ROWNUM <= 5` fragment with the ROWNUM flag and a
 *  `/* TODO-SPARK: ROWNUM ... */` marker in the mirrored file. The
 *  benign SYSDATE method still translates (SYSDATE ->
 *  current_timestamp()) with no flags. */
public class ArgsJoin {

    public String rownumArgs(String[] args) {
        return "SELECT a FROM t " + args[0] + " WHERE ROWNUM <= 5";
    }

    public String rownumSuffix(String suffix) {
        return "SELECT a FROM t " + (suffix) + " WHERE ROWNUM <= 5";
    }

    public String benignSysdate(String[] args) {
        return "SELECT SYSDATE FROM DUAL " + args[0] + " FROM DUAL";
    }
}
