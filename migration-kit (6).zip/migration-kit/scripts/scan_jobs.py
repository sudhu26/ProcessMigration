#!/usr/bin/env python3
"""Parse Control-M job definitions into job -> command -> code linkage.
Accepts an XML export or a CSV (job_name, command, depends_on, schedule).
Stdlib only.

Usage: scan_jobs.py --export <jobs.xml|jobs.csv> --out <out.json>
"""
import argparse, csv, json, re, xml.etree.ElementTree as ET

FQN_RE = re.compile(r'\b((?:[a-zA-Z_$][\w$]*\.){2,}[A-Z][\w$]*)\b')
SCRIPT_RE = re.compile(r'[\w./\\:-]+\.(?:sh|ksh|bash|bat|cmd|ps1)\b', re.IGNORECASE)
# .jar must not be followed by '.' or an identifier character, or a
# package segment literally named 'jar' (com.foo.jar.Bar) yields a
# phantom jar entry (R4-N8).
JAR_RE = re.compile(r'[\w./\\:-]+\.jar(?![\w.])', re.IGNORECASE)
JAVA_MAIN_RE = re.compile(
    r'\bjava\b\s+(?:-[^\s]+\s+(?:[^\s]+\s+)?)*?((?:[a-zA-Z_$][\w$]*\.)+[A-Z][\w$]*)')


def dissect_command(cmd):
    cmd = cmd or ''
    main = None
    # R6-G7: `-jar <jar>` is terminal — anything after it is an argument
    # to the jar's main(), not the main class. A main class is only
    # accepted when it starts before the -jar token. (Note: `\b-jar`
    # would never match after a space, because '-' is a non-word
    # character — hence the lookbehind below.)
    jar_m = re.search(r'(?<![\w-])-jar\s+\S+', cmd)
    jar_at = jar_m.start() if jar_m else None
    m = JAVA_MAIN_RE.search(cmd)
    if m and (jar_at is None or m.start(1) < jar_at):
        main = m.group(1)
    else:
        # R6-G8: the `jar`-segment skip stays, deliberately diverging
        # from scan_scripts.py (§4.4): FQN_RE matches 'my.jar.Main' in
        # 'lib/my.jar.Main', so dropping the skip would misread a jar
        # path as a class. A real class in a `.jar.` package
        # (com.foo.jar.Bar) is therefore still missed here.
        for cm in FQN_RE.finditer(cmd):
            cand = cm.group(1)
            if jar_at is not None and cm.start(1) >= jar_at:
                continue
            if all(seg != 'jar' for seg in cand.split('.')) and not cand.startswith(('java.', 'javax.', 'org.')):
                main = cand
                break
    return {
        'main_class': main,
        'scripts': sorted(set(SCRIPT_RE.findall(cmd))),
        'jars': sorted(set(JAR_RE.findall(cmd))),
    }


def parse_xml(path):
    tree = ET.parse(path)
    root = tree.getroot()
    jobs = []
    for el in root.iter():
        tag = el.tag.split('}')[-1].upper()
        if not tag.endswith('JOB'):
            continue
        attrs = {k.upper(): v for k, v in el.attrib.items()}
        name = (attrs.get('JOBNAME') or attrs.get('NAME') or attrs.get('JOB_NAME')
                or 'UNKNOWN')
        cmd = (attrs.get('CMDLINE') or attrs.get('COMMAND') or attrs.get('CMD')
               or attrs.get('CMDLINE_TEXT') or '')
        host = attrs.get('NODEID') or attrs.get('HOST') or attrs.get('NODE') or ''
        sched = attrs.get('SCHEDULE') or attrs.get('DAYS') or ''
        depends = []
        for child in el.iter():
            ctag = child.tag.split('}')[-1].upper()
            if ctag in ('INCOND', 'IN_COND', 'DEPENDENCY'):
                cattrs = {k.upper(): v for k, v in child.attrib.items()}
                dep = cattrs.get('NAME') or cattrs.get('COND') or cattrs.get('JOB')
                if dep:
                    depends.append(dep)
        # Control-M has no job id / parent / task / parameters: emit the
        # same 13 fields as Autosys with empty defaults.
        rec = {'job_name': name, 'job_id': '',
               'description': attrs.get('DESCRIPTION') or '',
               'command': cmd, 'host': host,
               'schedule': sched, 'depends_on': sorted(set(depends)),
               'parent_jobs': [], 'task_name': '', 'parameters': ''}
        rec.update(dissect_command(cmd))
        jobs.append(rec)
    return jobs


def parse_csv(path):
    jobs = []
    with open(path, newline='', encoding='utf-8-sig') as f:
        for row in csv.DictReader(f):
            # Header matching is case-insensitive (like parse_autosys):
            # an uppercase-header Control-M CSV must not yield UNKNOWN.
            row = {(k or '').strip().upper(): (v or '').strip()
                   for k, v in row.items()}
            cmd = row.get('COMMAND', '')
            depends = [d.strip() for d in (row.get('DEPENDS_ON') or '').split(';')
                       if d.strip()]
            parents = [p.strip()
                       for p in (row.get('PARENT_JOB_NAME') or '').split(';')
                       if p.strip()]
            # Same 13 fields as Autosys; a plain Control-M CSV only has
            # job_name/command/depends_on/schedule, the rest default empty.
            rec = {'job_name': row.get('JOB_NAME', 'UNKNOWN'),
                   'job_id': row.get('JOB_ID', ''),
                   'description': row.get('DESCRIPTION', ''),
                   'command': cmd,
                   'host': row.get('HOST', ''),
                   'schedule': row.get('SCHEDULE', ''),
                   'depends_on': depends,
                   'parent_jobs': parents,
                   'task_name': row.get('TASK_NAME', ''),
                   'parameters': row.get('PARAMETERS', '')}
            rec.update(dissect_command(cmd))
            jobs.append(rec)
    return jobs


def parse_condition_value(cond):
    """Extract depended-on job names from an Autosys CONDITION cell.

    Handles plain names ('FEED_LANDED'), Autosys expressions like
    's(JOB_A) AND s(JOB_B)', uppercase 'SUCCESS(...)', and a space before
    the paren ('s (NAME)'); ';'-separated lists. Inner spaces such as
    '( FEED )' are stripped.
    """
    cond = (cond or '').strip()
    if not cond:
        return []
    names = re.findall(r's(?:uccess)?\s*\(\s*([^)]+?)\s*\)', cond,
                       flags=re.IGNORECASE)
    if names:
        return [n.strip().strip('"\'').strip() for n in names if n.strip()]
    parts = re.split(r'\bAND\b|\bOR\b|;', cond, flags=re.IGNORECASE)
    return [p.strip().strip('()"\'').strip() for p in parts
            if p.strip().strip('()"\'').strip()]


def parse_autosys(path):
    """Parse an Autosys job-list CSV with columns
    JOB_ID,JOB_NAME,JOB_DESCRIPTION,COMMAND,CONDITION,PARENT_JOB_NAME,
    TASK_NAME,PARAMETERS.

    One row per condition: rows for the same job are grouped by JOB_NAME,
    exact duplicate rows are dropped, and CONDITION cells are aggregated
    into the job's depends_on list.
    """
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        rows = [{(k or '').strip().upper(): (v or '').strip()
                 for k, v in r.items()} for r in reader]
    n_rows = len(rows)
    seen, uniq = set(), []
    for r in rows:
        key = tuple(sorted(r.items()))
        if key not in seen:
            seen.add(key)
            uniq.append(r)
    n_dupes = n_rows - len(uniq)

    groups, order = {}, []
    for r in uniq:
        name = r.get('JOB_NAME') or r.get('JOB_ID') or 'UNKNOWN'
        if name not in groups:
            groups[name] = []
            order.append(name)
        groups[name].append(r)

    jobs = []
    for name in order:
        grows = groups[name]

        def first(col):
            for r in grows:
                v = r.get(col, '')
                if v:
                    return v
            return ''

        depends, parents = [], []
        for r in grows:
            for c in parse_condition_value(r.get('CONDITION', '')):
                if c not in depends:
                    depends.append(c)
            p = r.get('PARENT_JOB_NAME', '')
            if p and p not in parents:
                parents.append(p)
        cmds = sorted({r.get('COMMAND', '') for r in grows if r.get('COMMAND', '')})
        if len(cmds) > 1:
            print(f'warning: job {name} has {len(cmds)} distinct COMMAND values; '
                  f'using the first')
        cmd = cmds[0] if cmds else ''
        rec = {'job_name': name,
               'job_id': first('JOB_ID'),
               'description': first('JOB_DESCRIPTION'),
               'command': cmd,
               'host': '', 'schedule': '',
               'depends_on': depends,
               'parent_jobs': parents,
               'task_name': first('TASK_NAME'),
               'parameters': first('PARAMETERS')}
        info = dissect_command(cmd)
        if not info['main_class'] and not info['scripts']:
            # Retry on TASK_NAME + PARAMETERS, but MERGE into the COMMAND
            # result instead of replacing it: jars found in COMMAND must
            # not be lost. The retry fires only when both main_class and
            # scripts are empty (jars alone do not count as linkage).
            retry = dissect_command(
                f"{rec['task_name']} {rec['parameters']}".strip())
            for k, v in retry.items():
                if not info[k]:
                    info[k] = v
        rec.update(info)
        jobs.append(rec)
    print(f'autosys: {n_rows} rows, {n_dupes} exact-duplicate rows dropped, '
          f'{len(jobs)} jobs')
    return jobs


def detect_format(path):
    if path.lower().endswith('.xml'):
        return 'controlm'
    with open(path, newline='', encoding='utf-8-sig') as f:
        header = next(csv.reader([f.readline()]), [])
    cols = {(c or '').strip().upper() for c in header}
    if 'JOB_ID' in cols:
        return 'autosys'
    return 'controlm'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--export', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--format', default='auto',
                    choices=['auto', 'controlm', 'autosys'],
                    help='job export format (auto-detected by default)')
    a = ap.parse_args()
    fmt = a.format if a.format != 'auto' else detect_format(a.export)
    if fmt == 'autosys':
        jobs = parse_autosys(a.export)
    elif a.export.lower().endswith('.xml'):
        jobs = parse_xml(a.export)
    else:
        jobs = parse_csv(a.export)
    with open(a.out, 'w', encoding='utf-8') as f:
        json.dump(jobs, f, indent=1)
    linked = sum(1 for j in jobs if j['main_class'] or j['scripts'])
    print(f'parsed {len(jobs)} jobs ({linked} with code linkage) -> {a.out} '
          f'[format={fmt}]')


if __name__ == '__main__':
    main()
