-- Quoted CREATE TABLE regression (R7-G12): ddl_columns must accept a
-- quoted table name, mirroring DEF_RE's quoted-identifier acceptance.
-- Scanned with:
--   scan_plsql.py --root fixtures/edge-cases --repo EdgeCases --exts ".sql"
-- Expected (quoted_ddl.sql record): ddl_columns
-- {'RISK_POSITIONS': ['A', 'B'], 'RISK_CTRL': ['P', 'Q'],
--  'SCH.RISK_AUDIT_Q': ['X']}.
CREATE TABLE "RISK_POSITIONS" (a NUMBER, b VARCHAR2(10));
CREATE TABLE RISK_CTRL (p NUMBER, q VARCHAR2(5));
CREATE TABLE "SCH"."RISK_AUDIT_Q" (x NUMBER);
