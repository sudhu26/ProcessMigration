# Build a Portable AI Agent for Repeatable Work

Create a portable folder system that turns a general AI chat into an assistant capable of executing repeatable work.

## What you will achieve

You will build a working agent foundation with verified business context, editable memory, reusable skill files, connected tools, and a clear completion test for every task.

## Who this is for

Business owners, operators, creators, and professionals who want AI to perform useful work instead of only answering questions.

**Difficulty:** Intermediate

## Short tutorial

Create a portable folder system that turns a general AI chat into an assistant capable of executing repeatable work.

### Guide: Build a Practical AI Agent With Context, Memory, Skills, and Tools

**Time:** 35 to 50 minutes

## What You Will Build

An AI agent is an AI that can do work on your behalf. A chat answers a question. An agent takes actions, examines the result, and continues until a defined job is complete.

A useful agent needs four components:

| Component | Purpose |
|---|---|
| Context | Tells the agent about you, your business, and its operating environment |
| Memory | Records important preferences and lessons learned while working with you |
| Skills | Defines exactly how to perform recurring jobs |
| Tools | Gives the agent access to applications, accounts, and data sources |

This tutorial creates those components as portable Markdown files. You can use the folder with any AI harness that can read and edit local files. If your current interface cannot access files, create the files manually and attach or paste them when needed.

The application you choose is only the harness. Claude, ChatGPT, Gemini, Codex, and similar interfaces may differ, but the underlying setup remains the same.

## 1. Choose One Job for the Agent

Start with one specific workflow. Do not begin by trying to automate your entire business.

Good first jobs include:

* Finding unanswered client emails and drafting replies
* Organizing folders in a connected drive
* Producing a recurring business report
* Adding voice prompted tasks to a task system
* Following your established video research or production process

Write the job and its completion condition before configuring anything.

```markdown
# Agent Job

## Job
Review client emails that have not received a response in the last two weeks and prepare a draft for each one.

## Completion Condition
The job is complete when:
1. Every qualifying client email has been identified.
2. One response draft has been prepared for each email.
3. No message has been sent without approval.
4. A summary lists the client, email subject, age of the message, and draft status.
```

The completion condition matters because an agent works in a loop:

1. Take an action.
2. Inspect the result.
3. Decide what remains.
4. Take the next action.
5. Stop when the completion condition is satisfied.

If the end state is vague, the agent may stop too early or continue in an unhelpful direction.

## 2. Create the Agent Folder

Create a small, focused folder rather than loading dozens of documents.

```text
ai-agent/
├── context.md
├── instructions.md
├── memory.md
├── job.md
├── reference/
└── skills/
    └── example-skill.md
```

Use Markdown files because they are easy for both you and the AI to read and edit. Keep the contents short and dense. Add only reference documents that can materially improve the agent's work, such as a company roadmap or an essential policy.

## 3. Build `context.md`

Context is the information the agent should know before receiving a job. Treat this like onboarding a new employee.

Use this interview prompt to create the first draft:

```text
I want to build a concise context file about me and my business.

Interview me by asking one question at a time. Cover only information that could materially affect your work, including:

1. What the business does
2. Its customers and offers
3. My role and responsibilities
4. Current priorities
5. Important operating rules
6. Communication preferences
7. Constraints you must respect
8. Essential terminology, systems, and workflows

Do not draft the file until you have finished asking questions. When you have enough information, produce a one page Markdown file named context.md. Keep it short and dense. Clearly separate verified business information from operating rules. Do not invent missing details. Mark anything uncertain for my review.
```

Review every line before using the file. Incorrect context can cause incorrect decisions later.

A practical `context.md` structure looks like this:

```markdown
# Business Context

## Business
Company name: [Name]
What we do: [Concise description]
Primary customers: [Customer groups]
Core offers: [Products or services]

## My Role
Name: [Name]
Role: [Role]
Primary responsibilities: [Responsibilities]

## Current Priorities
1. [Priority]
2. [Priority]
3. [Priority]

## Operating Rules
* [Rule the agent should consistently follow]
* [Constraint the agent must respect]
* [Required approval boundary]

## Communication Preferences
Tone: [Preferred tone]
Length: [Preferred length]
Formatting: [Formatting preferences]

## Essential Systems
* [System]: [How it is used]
* [System]: [How it is used]

## Terms
* [Internal term]: [Meaning]
```

Own and maintain this file yourself. This makes your context visible, editable, and portable instead of leaving it inside an application's hidden memory.

## 4. Configure `instructions.md`

The instructions file defines how the agent should behave and how it should maintain memory.

Copy and adapt this template:

```markdown
# Agent Instructions

## Working Style
* Act as a professional operator and strategist.
* Keep responses concise unless detail is required to complete the job.
* Use context.md as the source of truth for stable business context.
* Use memory.md for learned preferences and material workflow lessons.
* Read the relevant skill before performing a recurring task.
* Never invent business facts, tool results, or completed actions.

## Execution Process
For every assigned job:
1. Restate the intended outcome briefly.
2. Identify the relevant context, memory, skill, and tools.
3. Confirm that the required tools are available.
4. Execute one action at a time.
5. Inspect each result before continuing.
6. Compare progress with the completion condition in job.md.
7. Continue until the condition is satisfied or progress is blocked.
8. Report completed actions, unresolved items, and required decisions.

## Memory Rules
* When I provide a new preference or correction that could materially affect future work, update memory.md.
* Store only essential and reusable information.
* Do not store temporary details that apply to only one task.
* Tell me whenever memory.md has been updated.
* If a new instruction conflicts with an existing memory, ask which one should take priority.

## Approval Boundaries
* Drafting is allowed unless job.md says otherwise.
* Ask for approval before sending, publishing, deleting, purchasing, or making an irreversible change.
* If a required tool is unavailable, explain what access is missing instead of claiming the action was completed.
```

Adjust the approval boundaries to match the selected workflow. The important distinction is between preparing work and taking an external action.

## 5. Initialize `memory.md`

Context is what you provide up front. Memory is what the agent learns from working with you.

Start with only a few verified preferences:

```markdown
# Working Memory

## Communication Preferences
* The user prefers concise answers.
* The user prefers a professional, direct tone.

## Output Preferences
* [Add verified formatting preference]

## Workflow Lessons
* [Add a reusable lesson after receiving feedback]

## Avoid
* [Add a word, style, format, or behavior the user has rejected]
```

When correcting the agent, make the reusable lesson explicit:

```text
Do not use bullet points in client email drafts. Use short paragraphs instead. This is a recurring preference, so update memory.md and tell me exactly what you added.
```

Then inspect the update. Remove duplicate, temporary, or overly broad memories. The benefit of a file based memory system is that you can see and correct everything the agent remembers.

## 6. Turn a Workflow Into a Skill

A skill is an SOP for one specific job. It prevents you from explaining the same process repeatedly.

Create one file per recurring workflow inside `skills/`:

```markdown
# Skill: [Skill Name]

## Purpose
[What this skill accomplishes]

## Use When
[The conditions that should trigger this skill]

## Required Inputs
* [Input]
* [Input]

## Required Tools
* [Connector, application, or data source]

## Procedure
1. [First action]
2. [Second action]
3. [Validation step]
4. [Final action]

## Quality Rules
* [Standard the output must meet]
* [Common error to avoid]
* [Required source or method]

## Completion Condition
The task is complete when:
* [Observable result]
* [Observable result]

## Output Format
[Describe the final deliverable]

## Escalation Conditions
Stop and ask for input when:
* [Required information is missing]
* [A decision exceeds the agent's authority]
* [A tool returns an unexpected result]
```

### Example: Draft Unanswered Client Emails

```markdown
# Skill: Draft Unanswered Client Emails

## Purpose
Find client emails awaiting a response for at least two weeks and prepare a suitable draft for each one.

## Use When
The user requests an inbox follow up review.

## Required Inputs
* The review date
* The definition of a client
* Any clients or message categories to exclude

## Required Tools
* Connected email account

## Procedure
1. Search the connected inbox for client messages older than two weeks.
2. Exclude messages that already received a response.
3. Exclude categories identified by the user.
4. Read the relevant conversation before drafting.
5. Draft a concise response using context.md and memory.md.
6. Verify that the draft addresses the sender's actual request.
7. Prepare a summary table for review.

## Quality Rules
* Do not claim an action was taken unless the conversation confirms it.
* Do not send any email without approval.
* Match the user's established communication preferences.
* Preserve important dates, names, and commitments from the thread.

## Completion Condition
The task is complete when every qualifying email has one reviewed draft and appears in the summary.

## Output Format
| Client | Subject | Message age | Draft status | Notes |
|---|---|---:|---|---|

## Escalation Conditions
Stop and ask for input if the correct response requires a business decision, a refund, a commitment, or information not available in the thread.
```

You can develop a skill by narrating the workflow while performing it, then asking the AI to convert that demonstration into the template. If your interface supports screen recording and voice input, use both to capture actions and decision criteria.

```text
I am going to demonstrate and narrate a recurring workflow. Observe both the actions and the reasons for each decision.

After the demonstration, convert the process into one concise Markdown skill. Include purpose, trigger conditions, required inputs, required tools, ordered procedure, quality rules, completion condition, output format, and escalation conditions.

Do not add steps I did not demonstrate. If an important decision rule is unclear, ask me before finalizing the skill.
```

## 7. Connect Only the Tools the Job Needs

Tools let the agent reach outside its folder and perform actions. Without an inbox connector, an agent cannot inspect your email. Without a drive connector, it cannot organize your folders.

Open the connector or integration settings in your chosen harness and identify what the selected job requires.

| Job | Possible required access |
|---|---|
| Draft client replies | Email account |
| Organize company folders | Cloud drive |
| Add tasks to a CRM | Task or workspace application |
| Prepare a live market report | A suitable live financial data source |
| Use an external model | A connector that exposes that model |

Use this checklist before running the agent:

* The required connector is enabled.
* The correct account is connected.
* The agent can read the necessary source.
* Write access is enabled only if the workflow requires it.
* The skill identifies which actions require approval.
* The agent has been told not to claim success when a connector fails.

Test access with a small, observable action. For a drive workflow, you might ask the agent to create one clearly named test folder. If the connector is disabled, it should report that it cannot complete the action.

## 8. Run the Complete Agent Workflow

Place the job definition in `job.md`, then use this launch prompt:

```text
Read context.md, instructions.md, memory.md, and job.md. Then read the relevant skill in the skills folder.

Before acting:
1. State the completion condition.
2. List the tools required.
3. Confirm which required tools are currently available.
4. Identify any missing input or access.

If the required inputs and tools are available, execute the job. Work iteratively: take an action, inspect the result, compare progress with the completion condition, and continue until the job is complete.

Follow the approval boundaries in instructions.md. Do not claim that an external action succeeded unless the tool confirms it. At the end, report:

1. What you completed
2. What you changed
3. What remains unresolved
4. Any memory.md updates
5. Any recommended improvement to the skill
```

The agent should now combine all four components:

1. It reads context to understand the business.
2. It checks memory for learned preferences.
3. It follows the relevant skill.
4. It uses connected tools to perform the work.
5. It stops when the completion condition is satisfied.

## 9. Improve the System Through Feedback

After each run, give precise feedback that can improve either memory or the skill.

Use memory for preferences:

```text
The drafts were too long. For client follow ups, keep the body under three short paragraphs. Add this as a reusable preference in memory.md.
```

Use the skill for process improvements:

```text
Update the client email skill. Before drafting, check whether another team member replied in the thread. Add this as a required procedure and quality check.
```

Keep the distinction clear:

| Feedback type | Update |
|---|---|
| Personal style or recurring preference | `memory.md` |
| Stable business information or rule | `context.md` |
| Better method for performing a job | Relevant skill file |
| General agent behavior | `instructions.md` |

## Complete Folder Setup Prompt

If your AI harness can create and edit local files, use this prompt to generate the initial system:

```text
Create a portable AI agent folder with this structure:

ai-agent/
  context.md
  instructions.md
  memory.md
  job.md
  reference/
  skills/
    example-skill.md

First, interview me one question at a time to learn about me, my business, my working preferences, and the first job I want the agent to perform. Do not create the files until the interview is complete.

Then create:

1. context.md, containing concise, verified business context and stable operating rules.
2. instructions.md, defining working style, iterative execution, memory updates, reporting, and approval boundaries.
3. memory.md, containing only verified and reusable preferences.
4. job.md, defining the first job, required inputs, constraints, and an observable completion condition.
5. example-skill.md, containing an SOP for that job with purpose, trigger conditions, inputs, tools, ordered procedure, quality rules, completion condition, output format, and escalation conditions.

Keep every file short and dense. Do not invent facts or tool access. Mark uncertain information for review. After creating the files, show me the folder structure and ask me to verify each file before the agent performs any work.
```

## Final Validation Checklist

Before treating the setup as operational, confirm:

* `context.md` is accurate, concise, and portable.
* `memory.md` contains only important reusable preferences.
* `instructions.md` explains behavior, memory updates, and approval limits.
* The selected job has an observable completion condition.
* The relevant skill captures the real process and quality checks.
* Every required external system has a working connector.
* The agent reports missing access instead of pretending to act.
* The agent checks its result before declaring the job complete.
* Important local files are backed up appropriately.

Once one workflow performs reliably, create additional skills and connect additional tools as needed. Scheduling or recurring loops can then be added where your chosen harness supports them.