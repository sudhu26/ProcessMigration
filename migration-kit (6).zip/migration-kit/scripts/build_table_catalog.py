#!/usr/bin/env python3
"""Build one Markdown catalog of Oracle tables: columns (from DDL where
available, else from observed usage), the processes that read each table
(inputs) and the processes that write it (outputs).

Usage: build_table_catalog.py --units units.json --plsql plsql_all.json
       --out tables.md
"""
import argparse, json, os
from collections import defaultdict


def load(p, default):
    if p and os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    return default


READ_KINDS = ('read', 'read_via_proc', 'read_via_script')
WRITE_KINDS = ('write', 'write_via_proc', 'write_via_script')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--units', required=True)
    ap.add_argument('--plsql', default='')
    ap.add_argument('--only', default='',
                    help='comma-separated unit IDs; only their tables are listed')
    ap.add_argument('--out', required=True)
    a = ap.parse_args()
    units = load(a.units, [])
    plsql = load(a.plsql, [])
    only = {s.strip() for s in a.only.split(',') if s.strip()}
    if only:
        units = [u for u in units if u['unit_id'] in only]

    ddl_cols = defaultdict(set)
    defined_in = defaultdict(list)
    for rec in plsql:
        for t, cols in rec.get('ddl_columns', {}).items():
            ddl_cols[t].update(cols)
        for d in rec.get('definitions', []):
            if d['kind'] in ('TABLE', 'VIEW', 'MATERIALIZED VIEW'):
                defined_in[d['name']].append(rec['path'])

    readers = defaultdict(list)   # table -> [(unit_id, [cols], kind)]
    writers = defaultdict(list)
    used_cols = defaultdict(lambda: {'read': set(), 'write': set()})
    for u in units:
        for d in u.get('db_objects', []):
            t = d['name']
            # kind is the single dominant direction; columns tell the rest
            if d['kind'] in READ_KINDS or d.get('columns_read'):
                readers[t].append((u['unit_id'], d.get('columns_read', []), d['kind']))
                used_cols[t]['read'].update(d.get('columns_read', []))
            if d['kind'] in WRITE_KINDS or d.get('columns_written'):
                writers[t].append((u['unit_id'], d.get('columns_written', []), d['kind']))
                used_cols[t]['write'].update(d.get('columns_written', []))

    # G14: with --only, DDL columns are intersected with the selected
    # units' tables — a table with DDL but untouched by the selected units
    # must not leak into the catalog
    if only:
        unit_tables = set(readers) | set(writers)
        ddl_cols = {t: c for t, c in ddl_cols.items() if t in unit_tables}

    tables = sorted(set(readers) | set(writers) | set(ddl_cols))
    lines = ['# Oracle table catalog',
             '',
             'One section per table: its columns, the processes that read it '
             '(inputs) and the processes that write it (outputs). Columns from '
             '`CREATE TABLE` DDL are authoritative; otherwise the columns '
             'observed in use are listed.',
             '',
             '## Summary',
             '',
             '| Table | Columns (DDL) | Readers | Writers | Defined in repo? |',
             '|---|---|---|---|---|']
    for t in tables:
        lines.append(f"| `{t}` | {len(ddl_cols.get(t, []))} | "
                     f"{len(readers.get(t, []))} | {len(writers.get(t, []))} | "
                     f"{'yes' if t in defined_in else 'NO — referenced, not defined'} |")
    lines.append('')
    for t in tables:
        lines.append(f'## {t}')
        lines.append('')
        cols = sorted(ddl_cols.get(t, []))
        if cols:
            lines.append(f"**Columns (DDL):** {', '.join(f'`{c}`' for c in cols)}")
        else:
            used = sorted(used_cols[t]['read'] | used_cols[t]['write'])
            lines.append('**Columns (DDL):** *(no DDL found)* — columns observed '
                         'in use: ' + (', '.join(f'`{c}`' for c in used) if used else '*(none)*'))
        lines.append('')
        if t in defined_in:
            lines.append('**Defined in:** ' + ', '.join(f'`{p}`' for p in defined_in[t]))
            lines.append('')
        lines.append('### Read by (inputs)')
        lines.append('')
        if readers.get(t):
            for uid, cs, kind in sorted(readers[t]):
                col_txt = f" — columns: {', '.join(f'`{c}`' for c in cs)}" if cs else ''
                lines.append(f"- `{uid}` ({kind}){col_txt}")
        else:
            lines.append('*(no process reads this table)*')
        lines.append('')
        lines.append('### Written by (outputs)')
        lines.append('')
        if writers.get(t):
            for uid, cs, kind in sorted(writers[t]):
                col_txt = f" — columns: {', '.join(f'`{c}`' for c in cs)}" if cs else ''
                lines.append(f"- `{uid}` ({kind}){col_txt}")
        else:
            lines.append('*(no process writes this table)*')
        lines.append('')
    with open(a.out, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    n_undef = sum(1 for t in tables if t not in defined_in)
    print(f'{len(tables)} tables ({n_undef} referenced but not defined) -> {a.out}')


if __name__ == '__main__':
    main()
