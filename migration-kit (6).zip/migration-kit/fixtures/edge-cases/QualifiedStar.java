package com.risk.edge;

/** Qualified-star regression (R5-G11): prefix.* is '*' for that
 *  prefix's table, never a bare column named after the table. Scanned
 *  with: scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (QualifiedStar.java record):
 *  tables_read ['T1', 'T2'],
 *  table_columns {'T1': {'read': ['*'], 'write': []},
 *                   'T2': {'read': ['C'], 'write': []}},
 *  columns_unattributed []. */
public class QualifiedStar {

    public void run(java.sql.Statement st) throws Exception {
        String starSingle = "SELECT t1.* FROM t1";
        st.executeQuery(starSingle);

        String starJoin = "SELECT t1.* FROM t1 JOIN t2 ON t1.id = t2.id";
        st.executeQuery(starJoin);

        String starAndCol = "SELECT t1.*, t2.c FROM t1 JOIN t2 ON t1.id = t2.id";
        st.executeQuery(starAndCol);
    }
}
