#!/usr/bin/env python3
"""Prepare the migration working tree.

- Mirrors each source repo's folder/file structure EXACTLY (same relative
  paths) under <outdir>/<repo>/.
- Java files are copied as-is, except SQL string literals: the deterministic
  first-pass translator (translate_sql.py) rewrites mechanical Oracle patterns
  in place. Literals it cannot safely translate keep their original text and
  get a /* TODO-SPARK: ... */ marker.
- PL/SQL files (.sql/.pks/.pkb/.fnc/.prc/.trg/.vw/.tab/.seq) get the same
  first-pass treatment applied statement-by-statement (each ;-terminated
  statement translated on its own, so statement-level approved SQL
  overrides apply in multi-statement files), plus a header comment
  listing what was changed and what still needs agent work. The header's
  flag count is the number of needs-review statements.
- Every other file is copied byte-for-byte.
- One translation bundle per touched file lands in
  <outdir>/translation-bundles/<repo>/<relpath>.translate.json: every SQL
  literal/statement, its translation, applied rules, flags and confidence.
- A summary report is written to <outdir>/translation-report.md.

This is a FIRST PASS. Agents complete the translation per bundle; the tree
is the workspace, not the finished migration.

Usage: prepare_migration_tree.py --repos Risk_DB=/path,Risk_DL=/path,CoreWM=/path
       --outdir migration-tree [--patterns patterns.json]
       [--only UNIT --units units.json --graph dependency-graph.json
        --catalog db-object-catalog.json]
"""
import argparse, json, os, re, shutil, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ignore_lists import load_ignore  # noqa: E402
from translate_sql import (translate, _FLAG_PATTERNS, split_statements,  # noqa: E402
                           _split_leading_comments)
from scan_java import BETWEEN_RE  # noqa: E402

SQL_KEYWORDS = re.compile(
    r'\b(SELECT|INSERT\s+INTO|INSERT|UPDATE|DELETE\s+FROM|DELETE|MERGE\s+INTO|MERGE|'
    r'WITH|TRUNCATE|CALL|CREATE|DROP|ALTER)\b', re.IGNORECASE)
# a statement that is CREATE TABLE DDL (leading comments/whitespace allowed)
_CREATE_TABLE_RE = re.compile(
    r'\A\s*(?:--[^\n]*\n\s*|/\*.*?\*/\s*)*CREATE\s+TABLE\b', re.I | re.S)


def _is_create_table(stmt):
    return bool(_CREATE_TABLE_RE.match(stmt))
LIT_RE = re.compile(r'"""(.*?)"""|"(?:\\.|[^"\\])*"', re.DOTALL)
PLSQL_EXTS = ('.sql', '.pks', '.pkb', '.fnc', '.prc', '.trg', '.vw', '.tab', '.seq')


def _unescape(raw):
    try:
        return bytes(raw, 'utf-8').decode('unicode_escape')
    except Exception:
        return raw


def _escape(s):
    return s.replace('\\', '\\\\').replace('"', '\\"')


def apply_java_patterns(text, patterns):
    """Apply APPROVED learned patterns to a Java file. Import rewrites are
    mechanical and applied in place. Call sites are NEVER auto-rewritten —
    cloud APIs differ in shape, so they are flagged with the pattern attached
    for the agent. Returns (new_text, applied, flags)."""
    applied, flags = [], []
    lib = [m for m in patterns.get('library_map', [])
           if m.get('status') == 'approved']
    calls = [m for m in patterns.get('call_map', [])
             if m.get('status') == 'approved']
    for m in lib:
        pat = re.compile(r'(?m)^(\s*import\s+)' + re.escape(m['from']) +
                         r'(\s*;)')
        new_text, n = pat.subn(r'\g<1>' + m['to'] + r'\g<2>', text)
        if n:
            text = new_text
            applied.append({'pattern': m['id'], 'from': m['from'],
                            'to': m['to'], 'kind': 'import-rewrite'})
        # call sites still using the on-prem class name
        old = m['from'].split('.')[-1]
        lines = [i + 1 for i, ln in enumerate(text.splitlines())
                 if re.search(r'\b' + re.escape(old) + r'\b', ln)
                 and not ln.strip().startswith('import ')]
        if lines:
            flags.append({'pattern': m['id'], 'from': m['from'],
                          'to': m['to'], 'kind': 'call-site',
                          'lines': lines,
                          'note': 'call sites still use the on-prem class — '
                                  'rewrite using the cloud API'})
    for m in calls:
        meth = (m['from'] or '').split('.')[-1]
        if not meth:
            continue
        lines = [i + 1 for i, ln in enumerate(text.splitlines())
                 if re.search(r'\.' + re.escape(meth) + r'\s*\(', ln)]
        if lines:
            flags.append({'pattern': m['id'], 'from': m['from'],
                          'to': m.get('to'), 'kind': 'call-site',
                          'lines': lines,
                          'note': ('dropped in migrated code — no equivalent '
                                   'call; check the exemplar')
                          if m.get('to') is None else
                          'rewrite using the cloud call'})
    return text, applied, flags


def translate_java_file(text, ignore=None, overrides=None):
    """Translate SQL literals in place. Concatenated fragments are handled
    as a chain: each fragment is translated on its own, but a fragment only
    counts as SQL when the whole chain is SQL (so a fragment like
    "GROUP BY ... WHERE ROWNUM <= 10" still gets its TODO marker).
    Returns (new_text, bundle_items)."""
    spans = []  # (start, end, content, is_textblock)
    for m in LIT_RE.finditer(text):
        if m.group(1) is not None:
            spans.append((m.start(), m.end(), m.group(1), True))
        else:
            spans.append((m.start(), m.end(), _unescape(m.group(0)[1:-1]), False))
    # R6-B1 / R7-G2: the `+`-concatenation separator is the shared
    # BETWEEN_RE imported from scan_java.py (see the import at the top
    # of this file) — never a local copy. The tree and the scanner must
    # merge the same `+`-concatenated chains; when they differed, an
    # args[0]- / (var)-joined fragment (e.g. a ROWNUM fragment) was
    # silently dropped from the tree while the scanner counted it.
    chains, cur = [], None
    for s, e, val, tb in spans:
        if cur and BETWEEN_RE.match(text[cur[1]:s]):
            cur[2].append((s, e, val, tb))
            cur[1] = e
        else:
            if cur:
                chains.append(cur)
            cur = [s, e, [(s, e, val, tb)]]
    if cur:
        chains.append(cur)
    items, edits = [], []
    for chain in chains:
        merged = ' ? '.join(v for _, _, v, _ in chain[2])
        if not SQL_KEYWORDS.search(merged):
            continue
        for s, e, val, tb in chain[2]:
            r = translate(val, ignore, overrides)
            items.append({'original': val, 'translated': r['translated'],
                          'applied': r['applied'], 'flags': r['flags'],
                          'confidence': r['confidence'],
                          'chain_sql': merged[:1000]})
            if r['confidence'] == 'needs-review':
                marker = ' /* TODO-SPARK: ' + '; '.join(r['flags'])[:300] + ' */'
                edits.append((e, e, marker))
            elif r['translated'] != val:
                if tb:
                    edits.append((s + 3, e - 3, r['translated']))
                else:
                    edits.append((s + 1, e - 1, _escape(r['translated'])))
    for start, end, rep in sorted(edits, reverse=True):
        text = text[:start] + rep + text[end:]
    return text, items


def translate_plsql_file(text, ignore=None, overrides=None):
    """Apply the first-pass translator to a whole PL/SQL file. CREATE TABLE
    DDL is copied as-is, never translated. The mirrored body is rebuilt
    statement-by-statement from the per-statement translate() results
    computed in the loop below (CREATE TABLE statements and statements
    matching neither the SQL-keyword nor any flag pattern are restored
    verbatim in the same pass) — never by one whole-file translate()
    call, which cannot match a statement-level approved SQL override in
    a multi-statement file. Statements are split with the
    string/comment-aware split_statements() from translate_sql.py, so a
    ';' inside a string literal or a comment does not split a statement.
    Every statement that reaches translate() is recorded in the bundle
    (applied: [] / flags: [] / confidence: high for a no-op), so a
    reviewed no-op is distinguishable from a statement that never
    reached the translator. Overrides are compared without the statement
    terminator (translate() strips a single trailing ';' from both
    sides); the terminator is preserved from the original chunk in both
    directions — if the original chunk ends with ';' and the replacement
    doesn't, ';' is re-appended before the trailing whitespace, and if
    the original chunk lacks ';' and the replacement ends with one, the
    trailing ';' is stripped from the replacement. Returns
    (new_text, bundle_items, applied, flags). The header comment is
    always emitted, even when there is nothing to translate or flag —
    but its bundle sentences ("see bundle" / "Original Oracle code is
    preserved in the translation bundle.") appear ONLY when a bundle
    will be written for the file, i.e. when at least one statement
    reached translate() (items) or any flags were recorded. The header's
    flag count is the number of needs-review statements, exactly as for
    Java literals (see main()): two statements sharing one flag message
    count as 2."""
    items, applied, flags = [], set(), set()
    parts = []  # rebuilt body, one entry per ;-terminated chunk of text
    for stmt in split_statements(text):
        if _is_create_table(stmt):
            parts.append(stmt)
            continue
        # A statement is translated when it is SQL (SQL_KEYWORDS) OR when
        # it matches a flag pattern: a flag-only procedural statement such
        # as EXECUTE IMMEDIATE or a DBMS_/UTL_ call carries no SQL keyword
        # but must still reach the header, the bundle and the report —
        # gating on SQL_KEYWORDS alone silently dropped those flags.
        # translate() itself only fires flags outside string literals and
        # comments, so a flag-pattern hit inside a literal yields no item.
        if not SQL_KEYWORDS.search(stmt) and not any(
                pat.search(stmt) for pat, _ in _FLAG_PATTERNS):
            parts.append(stmt)
            continue
        prefix, rest = _split_leading_comments(stmt)
        if not rest.strip():
            parts.append(stmt)
            continue
        r = translate(rest, ignore, overrides)
        # Preserve the chunk's surrounding whitespace (the split puts
        # the newline after ';' at the head of the next chunk, and an
        # approved override's 'to' text is whitespace-normalized, so
        # joining bare translated cores would glue statements onto one
        # line); only the statement core itself is replaced. The leading
        # comment prefix is preserved verbatim ahead of the translation.
        trail = rest[len(rest.rstrip()):]
        translated = r['translated'].strip()
        if rest.rstrip().endswith(';') and not translated.endswith(';'):
            translated += ';'
        elif not rest.rstrip().endswith(';') and translated.endswith(';'):
            # R7-G3 (b): the terminator is preserved from the ORIGINAL
            # chunk in both directions — a stored override `to` ending
            # in ';' must not add a terminator the original lacked
            # (the mechanical path keeps the input terminator intact,
            # so this branch can only fire for an override `to`).
            translated = translated[:-1]
        parts.append(prefix + translated + trail)
        items.append({'original': stmt.strip()[:2000],
                      'translated': translated[:2000],
                      'applied': r['applied'], 'flags': r['flags'],
                      'confidence': r['confidence']})
        applied.update(r['applied'])
        flags.update(r['flags'])
    flagged = sum(1 for it in items if it['confidence'] == 'needs-review')
    header = ('/* MIGRATION FIRST PASS — Oracle -> Spark SQL\n'
              f'   Applied: {", ".join(sorted(applied)) or "(none)"}\n'
              f'   Still needs agent work: {flagged} flag(s)'
              + (' — see bundle.\n'
                 '   Original Oracle code is preserved in the translation bundle.\n'
                 if items or flags else '.\n')
              + '*/\n')
    return header + ''.join(parts), items, sorted(applied), sorted(flags)


def load_json(p, default):
    if p and os.path.exists(p):
        with open(p, encoding='utf-8') as f:
            return json.load(f)
    return default


def collect_process_files(repos, only, units, graph, catalog):
    """Files belonging to the selected processes: their Java files, the
    PL/SQL files defining the objects they touch, and the scripts/SQL files
    reachable from their jobs in the graph. Returns {abs_path: (repo, rel)}."""
    wanted = {s.strip() for s in only.split(',') if s.strip()}
    sel = [u for u in units if u['unit_id'] in wanted]
    missing = wanted - {u['unit_id'] for u in sel}
    if missing:
        print(f'warning: --only units not found: {sorted(missing)}',
              file=sys.stderr)
    touched = {d['name'] for u in sel for d in u.get('db_objects', [])}
    # a unit touches PKG.PROC; the catalog is keyed by the package PKG
    touched |= {t.split('.')[0] for t in touched}
    paths = set()
    for u in sel:
        for jf in u.get('java_files', []):
            paths.add(jf['path'])
    for c in catalog:
        if c['object'] in touched:
            paths.update(c.get('defined_in', []))
    # scripts + sql files reachable from the selected jobs (3 undirected
    # hops: a wrapper script often reaches the job only via the Java main
    # it invokes, i.e. job -- java -- script -- sql)
    adj = {}
    for e in graph.get('edges', []):
        adj.setdefault(e['src'], []).append(e['dst'])
        adj.setdefault(e['dst'], []).append(e['src'])
    frontier = {f"job:{u['unit_id']}" for u in sel}
    for _ in range(3):
        nxt = set()
        for n in frontier:
            for d in adj.get(n, []):
                nxt.add(d)
                if d.startswith(('script:', 'sql:')):
                    paths.add(d.split(':', 1)[1])
        frontier = nxt
    # resolve each path to (repo, relpath): prefix match first, then basename
    by_base = {}
    for repo, root in repos.items():
        for dirpath, _, filenames in os.walk(root):
            for fn in filenames:
                by_base.setdefault(fn.lower(), []).append(
                    (repo, os.path.relpath(os.path.join(dirpath, fn), root)))
    out = {}
    for p in sorted(paths):
        hit = None
        for repo, root in repos.items():
            if os.path.abspath(p).startswith(os.path.abspath(root) + os.sep):
                hit = (repo, os.path.relpath(p, root))
                break
        if not hit:
            cands = by_base.get(os.path.basename(p).lower(), [])
            if len(cands) > 1:
                print(f"warning: {len(cands)} repo files match basename "
                      f"'{os.path.basename(p)}'; using {cands[0]}",
                      file=sys.stderr)
            hit = cands[0] if cands else None
        if hit:
            out[os.path.join(repos[hit[0]], hit[1])] = hit
        else:
            print(f'warning: cannot locate {p} in the given repos; skipping',
                  file=sys.stderr)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repos', required=True,
                    help='comma-separated RepoName=/path pairs')
    ap.add_argument('--ignore', default='',
                    help='ignore.json: Java imports / Oracle objects to exclude')
    ap.add_argument('--only', default='',
                    help='comma-separated unit IDs: mirror only their files '
                         '(needs --units/--graph/--catalog)')
    ap.add_argument('--units', default='')
    ap.add_argument('--graph', default='')
    ap.add_argument('--catalog', default='')
    ap.add_argument('--patterns', default='',
                    help='patterns.json from learn_patterns.py: approved '
                         'library mappings rewrite imports, approved SQL '
                         'overrides replace mechanical rules, call sites are '
                         'flagged (never auto-rewritten)')
    ap.add_argument('--outdir', required=True)
    a = ap.parse_args()
    # F-B1: create the outdir up front — with --only and no --units /
    # --graph / --catalog nothing is mirrored, so the implicit makedirs in
    # the file loop never runs and the report write below would crash with
    # FileNotFoundError. The zero-file case must produce an empty tree +
    # report, as 4.14 promises.
    os.makedirs(a.outdir, exist_ok=True)
    ignore = load_ignore(a.ignore)
    patterns = load_json(a.patterns, {})
    approved_overrides = [o for o in patterns.get('sql_overrides', [])
                          if o.get('status') == 'approved']
    repos = {}
    for part in a.repos.split(','):
        name, _, path = part.partition('=')
        repos[name.strip()] = path.strip()
    bundle_root = os.path.join(a.outdir, 'translation-bundles')
    stats = {'files': 0, 'java': 0, 'plsql': 0, 'copied': 0,
             'literals': 0, 'translated': 0, 'flagged': 0,
             'patterns_applied': 0, 'pattern_flags': 0}
    flagged_files = []
    if a.only:
        todo = collect_process_files(
            repos, a.only, load_json(a.units, []), load_json(a.graph, {}),
            load_json(a.catalog, []))
        # todo: {abs_path: (repo, rel)} -> process exactly those files
        work = [(src, repo, rel) for src, (repo, rel) in sorted(todo.items())]
    else:
        work = []
        for repo, root in repos.items():
            for dirpath, _, filenames in os.walk(root):
                for fn in filenames:
                    src = os.path.join(dirpath, fn)
                    work.append((src, repo, os.path.relpath(src, root)))
    for src, repo, rel in work:
        dst = os.path.join(a.outdir, repo, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        stats['files'] += 1
        bundle = None
        if rel.endswith('.java'):
            with open(src, 'r', encoding='utf-8', errors='replace') as f:
                text = f.read()
            new_text, items = translate_java_file(text, ignore,
                                                 approved_overrides)
            stats['java'] += 1
            stats['literals'] += len(items)
            stats['translated'] += sum(
                1 for it in items if it['confidence'] != 'needs-review'
                and it['translated'] != it['original'])
            stats['flagged'] += sum(
                1 for it in items if it['confidence'] == 'needs-review')
            pat_applied, pat_flags = [], []
            if patterns:
                new_text, pat_applied, pat_flags = apply_java_patterns(
                    new_text, patterns)
                stats['patterns_applied'] += len(pat_applied)
                stats['pattern_flags'] += len(pat_flags)
            if items or pat_applied or pat_flags:
                bundle = {'source_path': src, 'target_path': dst,
                          'kind': 'java', 'literals': items,
                          'patterns_applied': pat_applied,
                          'pattern_flags': pat_flags}
            with open(dst, 'w', encoding='utf-8') as f:
                f.write(new_text)
        elif rel.lower().endswith(PLSQL_EXTS):
            with open(src, 'r', encoding='utf-8', errors='replace') as f:
                text = f.read()
            new_text, items, applied, flags = translate_plsql_file(
                text, ignore, approved_overrides)
            stats['plsql'] += 1
            stats['translated'] += sum(
                1 for it in items if it['confidence'] != 'needs-review'
                and it['translated'].strip() != it['original'].strip())
            # Count needs-review STATEMENTS, exactly as the Java branch
            # counts needs-review literals — not distinct flag messages
            # (len(flags)): two statements sharing one flag message
            # count as 2, matching the header and the report line
            # "Literals/statements flagged for agent review".
            stats['flagged'] += sum(
                1 for it in items if it['confidence'] == 'needs-review')
            if items or flags:
                bundle = {'source_path': src, 'target_path': dst,
                          'kind': 'plsql', 'statements': items,
                          'applied': applied, 'flags': flags,
                          'patterns_applied': sorted(
                              {a[len('pattern:'):] for it in items
                               for a in it['applied']
                               if a.startswith('pattern:')})}
            with open(dst, 'w', encoding='utf-8') as f:
                f.write(new_text)
        else:
            shutil.copyfile(src, dst)
            stats['copied'] += 1
        if bundle:
            bpath = os.path.join(bundle_root, repo, rel + '.translate.json')
            os.makedirs(os.path.dirname(bpath), exist_ok=True)
            with open(bpath, 'w', encoding='utf-8') as f:
                json.dump(bundle, f, indent=1)
            if any(it.get('confidence') == 'needs-review'
                   for it in bundle.get('literals', []) +
                   bundle.get('statements', [])) or bundle.get('pattern_flags'):
                flagged_files.append(f'{repo}/{rel}')
    report = ['# Translation report (first pass)', '',
              f"- Files mirrored: {stats['files']} "
              f"({stats['java']} Java, {stats['plsql']} PL/SQL, "
              f"{stats['copied']} copied as-is)",
              f"- SQL literals found in Java: {stats['literals']}",
              f"- Literals/statements translated by the first pass: {stats['translated']}",
              f"- Literals/statements flagged for agent review: {stats['flagged']}",
              f"- Learned patterns applied: {stats['patterns_applied']} "
              f"import rewrites, {stats['pattern_flags']} call-site flags",
              '',
              '## Files with items needing agent review',
              '']
    report += [f'- `{f}`' for f in sorted(flagged_files)] or ['*(none)*']
    if patterns:
        report += ['', '## Learned patterns used',
                   '',
                   f"- Library mappings approved: "
                   f"{sum(1 for m in patterns.get('library_map', []) if m.get('status') == 'approved')}",
                   f"- SQL overrides approved: {len(approved_overrides)}",
                   '- Call sites are flagged, never auto-rewritten — the '
                   'cloud APIs differ in shape, so the agent rewrites them '
                   'using the exemplar.']
    report += ['', '## Limits of this first pass',
               '',
               '- Patterns split across concatenated SQL fragments are left '
               'for the agent.',
               '  (Mechanical rewrites split across concatenated fragments are left for the',
               '  agent too: per-fragment translation means a call split across fragments',
               "  (e.g. `TO_DATE(' + asof + ', 'YYYY-MM-DD')` in the ROWNUM chain of",
               '  NightlyRiskJob.java) is not rewritten even though the merged `chain_sql`',
               '  is complete.)',
               '- `CREATE TABLE` DDL is copied as-is, not translated.',
               '']
    report += ['Bundles live in `translation-bundles/<repo>/<path>.translate.json`. '
                    'Each bundle lists every SQL literal/statement, its proposed '
                    'Spark SQL, applied rules, flags and confidence.']
    with open(os.path.join(a.outdir, 'translation-report.md'), 'w',
              encoding='utf-8') as f:
        f.write('\n'.join(report))
    print(f"mirrored {stats['files']} files -> {a.outdir} "
          f"({stats['translated']} literals/statements translated, "
          f"{stats['flagged']} flagged) — see translation-report.md")


if __name__ == '__main__':
    main()
