package com.risk.edge;

/** UNION/MINUS/INTERSECT-branch column regression (R6-G2, new
 *  assertion 38): extract_table_columns recurses set-operator
 *  branches like _read_tables does, so branch columns are attributed
 *  instead of dropped. Scanned with:
 *  scan_java.py --root fixtures/edge-cases --repo EdgeCases
 *  Expected (UnionColumns.java record): tables_read ['T1', 'T2'],
 *  table_columns {'T1': {'read': ['A'], 'write': []},
 *                   'T2': {'read': ['B'], 'write': []}},
 *  columns_unattributed [] — the top-level UNION `*` is dropped as
 *  multi-table (it names two tables), while the UNION/MINUS/
 *  INTERSECT branch columns A and B are attributed. */
public class UnionColumns {

    public void run(java.sql.Statement st) throws Exception {
        String unionCols = "SELECT a FROM t1 UNION SELECT b FROM t2";
        st.executeQuery(unionCols);

        String unionStar = "SELECT * FROM t1 UNION SELECT * FROM t2";
        st.executeQuery(unionStar);

        String minusCols = "SELECT a FROM t1 MINUS SELECT b FROM t2";
        st.executeQuery(minusCols);

        String intersectCols =
                "SELECT a FROM t1 INTERSECT SELECT b FROM t2";
        st.executeQuery(intersectCols);
    }
}
