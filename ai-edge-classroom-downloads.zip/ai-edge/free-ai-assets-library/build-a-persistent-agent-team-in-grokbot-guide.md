# Build a Persistent Agent Team in GrokBot

A practical blueprint for configuring persistent research, operations, finance, and scouting agents that continue working while you are away.

## What you will achieve

You will create a focused team of GrokBot agents, connect each agent only to the tools it needs, establish persistent operating instructions, and launch scheduled workflows with clear review and safety controls.

## Who this is for

Entrepreneurs, executives, analysts, creators, and operators who have repeatable computer based work they want AI agents to monitor or prepare autonomously.

**Difficulty:** Intermediate

## Short tutorial

A practical blueprint for configuring persistent research, operations, finance, and scouting agents that continue working while you are away.

### Guide: Build an Autonomous AI Agent Team in GrokBot

**Time:** 35 to 50 minutes

## What you will build

This tutorial shows you how to use GrokBot as an agent harness rather than as a general chat interface. You will configure separate agents for distinct responsibilities, give them persistent context, connect relevant applications, and schedule routines that can continue running when your computer is off.

The central principle is simple: treat each agent like a new employee. Give it one role, a defined scope, the information required to perform that role, and a precise reporting format.

Use the complete blueprint or select only the agents relevant to your work:

| Agent | Responsibility | Example output |
|---|---|---|
| Research analyst | Find content or market outliers | Curated opportunity report |
| Property scout | Monitor listings against criteria | Qualified listing shortlist |
| Portfolio analyst | Summarize positions and important events | Morning finance briefing |
| Executive assistant | Triage communications and commitments | Priority action list |

## 1. Decide whether an agent harness fits the task

Use GrokBot when the work benefits from persistence, scheduling, application access, or autonomous execution.

A direct model such as Claude or GPT may be simpler when you are completing one immediate task and already know which model you want. An agent harness becomes useful when the task must:

* Run while you are away from your computer.
* Repeat on a schedule.
* Browse sites, run commands, or create files.
* Draw from persistent context.
* Connect to applications such as Gmail, Google Calendar, Google Drive, Slack, or HubSpot.
* Coordinate work across different models or subtasks.

Before paying for a premium setup, identify at least one routine that consumes meaningful time or could reveal a valuable outlier. If you do not yet have such a routine, start with a direct coding or chat agent and learn through practical use.

## 2. Create separate agents with narrow roles

Do not place research, finance, communications, and property monitoring inside one general agent. Create a separate agent for each responsibility so that its memory, permissions, and reports remain focused.

Start with this role definition prompt for every agent. Replace the bracketed fields.

```text
You are my [ROLE NAME].

Your primary responsibility is:
[ONE SENTENCE DESCRIPTION OF THE JOB]

You support:
[PERSON, TEAM, OR BUSINESS]

Your recurring duties are:
1. [DUTY]
2. [DUTY]
3. [DUTY]

Your approved information sources are:
* [SOURCE OR APPLICATION]
* [SOURCE OR APPLICATION]

Your operating rules are:
* Stay within the assigned role.
* Distinguish confirmed facts from estimates and assumptions.
* Include source references whenever possible.
* Do not take irreversible actions without explicit approval.
* Ask for clarification when required information is missing.
* Save useful preferences, definitions, and corrections for future work.
* Keep reports concise and organized by priority.

Use this report structure unless I specify otherwise:
1. Executive summary
2. Important findings
3. Recommended actions
4. Risks or uncertainties
5. Sources and supporting files

Confirm your understanding, identify missing information, and propose the first routine you can run for me.
```

## 3. Onboard each agent with durable context

Persistent memory reduces repeated explanation, but the agent still needs deliberate onboarding. Supply the same type of information you would give a human employee.

### Context checklist

Provide only what the role needs:

* Business model and current priorities.
* Products, services, clients, or portfolio definitions.
* Preferred tools and data sources.
* Key terminology and internal acronyms.
* Decision criteria and thresholds.
* Report format and delivery schedule.
* Examples of strong and weak outputs.
* Actions requiring approval.
* Sensitive information the agent must not expose.

Use this onboarding prompt after creating the role:

```text
I am onboarding you into this role. Build and maintain an internal operating brief from the information below.

Business or personal context:
[CONTEXT]

Current priorities:
1. [PRIORITY]
2. [PRIORITY]
3. [PRIORITY]

Definitions and terminology:
* [TERM]: [DEFINITION]
* [TERM]: [DEFINITION]

Decision criteria:
* [CRITERION]
* [CRITERION]

Preferred output style:
[FORMAT, LENGTH, AND LEVEL OF DETAIL]

Approval boundaries:
* You may independently: [ACTIONS]
* You must request approval before: [ACTIONS]
* You must never independently: [ACTIONS]

Store this as persistent operating context. Then return:
1. Your concise understanding of the role
2. Any contradictions or missing details
3. The permissions and connections you need
4. A proposed recurring routine
```

Review its summary carefully. Correct misunderstandings before allowing scheduled work.

## 4. Connect the minimum necessary tools

Open the plugins or connections area and enable only the applications required by that agent. The transcript describes connections for Gmail, Google Calendar, Google Drive, Granola, Slack, and HubSpot, along with support for custom plugins.

Use least privilege access:

| Agent | Likely connections | Avoid unless required |
|---|---|---|
| Research analyst | Browser, YouTube, file storage | Email and financial accounts |
| Property scout | Browser, spreadsheet or Drive | Trading and communication access |
| Portfolio analyst | Portfolio sheet or financial data source | Trade execution access |
| Executive assistant | Gmail, Calendar, Slack, Drive | Brokerage and unrelated business systems |

Test each connection with a harmless request. For example:

```text
Confirm that you can access [APPLICATION]. Do not modify, send, delete, or publish anything. Read only the minimum information needed and return:
1. What you can access
2. What you cannot access
3. Any permission errors
4. The specific actions that would require my approval
```

## 5. Configure a research analyst

This agent monitors selected channels or sources, identifies unusually strong results, examines why they worked, and proposes ideas adapted to your goals.

```text
You are my YouTube research analyst. Save this as a recurring routine.

Objective:
Find high potential video opportunities in AI, Claude, and AI agents.

Schedule:
Run every morning at 6:00 AM.

Process:
1. Scan the leading YouTube channels covering AI, Claude, and AI agents.
2. Record each relevant video's title, channel, publication time, subscriber count, views, and topic.
3. Compare performance with that channel's typical or median performance when enough information is available.
4. Flag videos that appear to outperform expectations relative to channel size or normal performance.
5. Review the strongest candidates and their available transcripts.
6. Explain why each candidate may be working, including topic, framing, title, timing, structure, and audience promise.
7. Generate original spinoff ideas suitable for my channel. Do not simply copy titles or scripts.

Morning report:
* Top five outliers
* Evidence supporting each outlier
* Why each video appears to be working
* Three original spinoff ideas per major opportunity
* One recommended idea to prioritize today
* Source references

If data is missing or cannot be verified, label it clearly rather than guessing.
```

After several reports, ask the agent to maintain a dashboard or spreadsheet containing historical findings. This makes it easier to detect repeated topics and sustained patterns.

## 6. Configure a property scout

A property scout is valuable when desirable listings are rare and repeated manual searches are impractical. Define exact geographic, property, budget, and valuation criteria.

```text
You are my property scouting agent. Save this as a recurring routine.

Objective:
Monitor new property listings and identify candidates that match my acquisition criteria or appear meaningfully under market value.

Search schedule:
Run once in the morning and once in the evening.

Target criteria:
* Location: [AREA, COMMUNITY, OR STREET NAMES]
* Property type: [VILLA, LAND, APARTMENT, OR OTHER]
* Budget: [MINIMUM AND MAXIMUM]
* Minimum size: [SIZE]
* Maximum size: [SIZE]
* Bedrooms or use requirements: [REQUIREMENTS]
* Additional requirements: [REQUIREMENTS]

Process:
1. Search the approved property websites.
2. Identify listings added or materially changed since the previous scan.
3. Compare asking prices with relevant historical or nearby pricing when reliable data is available.
4. Flag listings that satisfy the criteria or appear unusually priced.
5. Record all qualified listings in [SPREADSHEET OR FILE LOCATION].
6. Avoid presenting an estimated discount as a confirmed fact. State the comparison method and data limitations.

For every qualified listing, report:
* Property and location
* Asking price
* Size and price per unit of area
* Listing date or detected change
* Relevant comparison data
* Estimated difference from comparison value
* Reason it may be worth reviewing
* Important risks or missing information
* Direct source reference

Notify me immediately only when a listing meets all mandatory criteria or exceeds this opportunity threshold:
[THRESHOLD]
```

The agent should surface candidates, not make the purchase decision. Verify listing status, ownership, condition, fees, and valuation independently.

## 7. Configure a portfolio analyst safely

The transcript describes using a live spreadsheet or data connection to produce morning portfolio updates. Begin with information and analysis only. Do not grant trade execution permissions during initial setup.

```text
You are my portfolio analyst. Save this routine.

Portfolio data source:
[GOOGLE SHEET, FILE, OR APPROVED DATA CONNECTION]

Schedule:
Prepare a report every morning at [TIME].

Your responsibilities:
1. Read the latest portfolio positions and monitored assets.
2. Summarize total portfolio exposure using the available data.
3. Identify significant overnight moves.
4. List major scheduled events that may affect current or monitored positions.
5. Flag unexpected changes, concentration risks, or deviations from my stated allocation targets.
6. Suggest items for my review, but do not execute trades.

Allocation targets and thresholds:
* [ASSET OR CATEGORY]: [TARGET OR RANGE]
* Significant move threshold: [PERCENTAGE OR RULE]
* Concentration warning threshold: [PERCENTAGE OR RULE]

Morning report:
1. Portfolio snapshot
2. Important overnight moves
3. Today's relevant calendar events
4. Threshold breaches or unusual activity
5. Rebalancing items for human consideration
6. Data quality problems or stale values

Rules:
* Never place, modify, or cancel a trade.
* Never treat missing or delayed data as current.
* Show the source and timestamp for important figures.
* Separate factual observations from interpretations.
* Require my explicit review before any action involving real money.
```

### Financial safety checklist

Before considering any execution capability:

* Verify the analysis workflow over multiple reports.
* Confirm that all values include timestamps.
* Test with simulated or nonfinancial actions first.
* Define position, value, and frequency limits.
* Require explicit approval for every transaction.
* Maintain independent account alerts and records.
* Never allow a natural language request to bypass established controls.

The transcript specifically warns that an error involving real money is materially different from an error in a text draft. Treat awareness and reporting as the default use case.

## 8. Configure an executive assistant

Use this agent to reduce the need to open every communication channel first thing in the morning.

```text
You are my executive assistant. Save this as a recurring morning routine.

Connected sources:
* Gmail
* Google Calendar
* Slack
* [OTHER APPROVED SOURCE]

Objective:
Give me a concise briefing of what requires my attention without overwhelming me with routine activity.

Every morning at [TIME]:
1. Review new messages and relevant activity since the previous report.
2. Identify urgent requests, blocked projects, deadlines, decisions, and commitments.
3. Review today's calendar and flag preparation requirements or conflicts.
4. Separate items that require my action from items that are informational.
5. Do not send messages, edit events, or make commitments without approval.

Report format:

URGENT
* Items requiring immediate attention

TODAY
* Decisions, deadlines, meetings, and preparation

WAITING ON ME
* Requests that require my response or approval

INFORMATIONAL
* Important updates that require no immediate action

SUGGESTED NEXT ACTIONS
* A short prioritized list

For every item, include the source, owner, deadline if known, and why it matters. If nothing is urgent, state that clearly.
```

Once its summaries are consistently reliable, you can ask it to draft replies for approval. Keep sending and calendar changes behind a human confirmation step.

## 9. Teach an agent a workflow by demonstration

GrokBot's task teaching feature can record your screen and spoken explanation. Use it for workflows where the sequence is easier to demonstrate than describe.

### Prepare the demonstration

Before recording:

1. Choose one repeatable task with a clear beginning and end.
2. Remove unrelated or sensitive information from the screen.
3. Prepare representative sample data.
4. Decide what counts as a successful result.
5. Identify every point where human judgment or approval is required.

During the recording, narrate both the action and the reason:

```text
I am teaching you how to perform [TASK].

The goal is [RESULT].

I start here because [REASON].

At this step, check [CONDITION]. If [CONDITION A] is true, do [ACTION A]. If [CONDITION B] is true, stop and ask me for guidance.

This field means [DEFINITION]. A valid value looks like [EXAMPLE].

Do not continue past this point without approval because [RISK].

The task is complete when [SUCCESS CRITERIA].

After observing the workflow, create a written procedure containing:
1. Required inputs
2. Ordered actions
3. Decision rules
4. Approval points
5. Error handling
6. Completion criteria
```

Run the learned task on sample data before trusting it with live work. Correct the procedure and ask the agent to store those corrections.

## 10. Launch a controlled overnight routine

Start with work that is reversible and easy to inspect, such as research, file preparation, data organization, or drafting.

```text
Run the following task overnight:
[TASK DESCRIPTION]

Inputs:
* [INPUT]
* [INPUT]

Approved tools and sources:
* [TOOL]
* [SOURCE]

Deliverables by [TIME]:
1. [DELIVERABLE]
2. [DELIVERABLE]
3. A concise activity log

Quality requirements:
* [REQUIREMENT]
* [REQUIREMENT]

Boundaries:
* Do not publish, send, purchase, trade, delete, or deploy anything.
* Do not access systems outside the approved list.
* If credentials, payment, or irreversible action is required, stop and report the blocker.
* Label assumptions and unresolved errors.
* Preserve intermediate files so I can inspect the work.

In the final report, include:
1. What was completed
2. What changed
3. What remains unfinished
4. Decisions requiring my approval
5. Files and sources used
```

Inspect the first several runs closely. Give specific corrections, then ask the agent to save the corrected process as its standard routine.

## 11. Review your setup before leaving it unattended

Use this final checklist for every agent:

* The agent has one clearly defined role.
* Its recurring task has a schedule and completion condition.
* Inputs and approved sources are named.
* The expected report format is explicit.
* Missing data must be labeled rather than guessed.
* The agent has only the permissions it needs.
* Publishing, sending, purchasing, deleting, and financial execution require approval.
* A test run has been completed with safe data.
* Corrections have been added to persistent context.
* The morning report includes actions, uncertainties, sources, and files.

The strongest initial deployment is not the most complex one. It is a narrow routine that saves time repeatedly, produces inspectable output, and has clear boundaries between autonomous preparation and human decisions.