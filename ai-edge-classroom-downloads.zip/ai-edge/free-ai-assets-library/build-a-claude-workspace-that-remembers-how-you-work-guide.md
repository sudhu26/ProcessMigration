# Build a Claude Workspace That Remembers How You Work

Set up a portable folder system, teach Claude repeatable skills, connect your tools, and automate recurring work.

## What you will achieve

You will create a Claude workspace with editable instructions, memory, and context files, then use it through Cowork or Claude Code for tailored, repeatable workflows.

## Who this is for

Claude users who want to move beyond isolated chats and use Claude as a persistent personal or business assistant.

**Difficulty:** Beginner

## Short tutorial

Set up a portable folder system, teach Claude repeatable skills, connect your tools, and automate recurring work.

### Guide: Build a Claude Workspace That Remembers How You Work

**Time:** 30 to 45 minutes

## What you will build

This tutorial turns Claude from a blank chat into a working environment that understands your goals, preferences, and processes.

You will create a local workspace containing:

- Instructions that define how Claude should behave
- An editable memory file containing durable facts and preferences
- Context documents describing you, your work, and your goals
- A skills folder for repeatable processes
- A workflow for connectors, scheduled tasks, and more advanced automation

Use Cowork for most folder based work. Use Claude Code when a task requires terminal access, application development, broader computer control, or more advanced agent workflows.

## 1. Choose the right Claude interface

| Interface | Best use |
|---|---|
| Chat | Quick questions, brainstorming, research, file analysis, and temporary work |
| Cowork | Ongoing work involving a local folder, persistent context, and editable files |
| Claude Code | Coding, terminal operations, application development, and advanced agent workflows |

For this setup, begin in Cowork and connect it to a dedicated local folder. You can open the same folder with Claude Code when you need more capability.

Projects remain useful if you prefer Chat. A project can hold instructions and shared context across multiple conversations. A local folder gives you more direct control because you can inspect, edit, back up, and move the files to another model later.

## 2. Create your local workspace

Create a folder named `claude-workspace` with this structure:

```text
claude-workspace/
├── instructions.md
├── memory.md
├── context/
│   ├── profile.md
│   ├── goals.md
│   ├── work.md
│   └── preferences.md
├── skills/
└── outputs/
```

You can create it manually, or connect Cowork to an empty folder and use this prompt:

```text
Create a workspace in the current folder with the following structure:

instructions.md
memory.md
context/profile.md
context/goals.md
context/work.md
context/preferences.md
skills/
outputs/

Add clear section headings and placeholder questions to each Markdown file. Do not invent information about me. Leave unknown fields marked as "Not provided."

When finished, show me the files you created and briefly explain the purpose of each one.
```

## 3. Define Claude's operating instructions

The instructions file contains Claude's standing rules. These rules should describe how it uses context, handles uncertainty, updates memory, and formats work.

Paste this into `instructions.md`:

```markdown
# Operating Instructions

## Primary objective
Use the information in this workspace to produce work that is relevant to my goals, preferences, and established processes.

## Context use
1. Review the relevant files in the context folder before beginning substantial work.
2. Use memory.md for durable facts, decisions, and preferences.
3. Do not invent personal or business details that are not present in the workspace.
4. If essential information is missing, ask a focused clarification question.

## Memory management
1. Update memory.md whenever new material information is clearly important for future work.
2. Notify me whenever you change memory.md and summarize what changed.
3. If information may or may not belong in long term memory, ask me before adding it.
4. Do not treat temporary tasks, unconfirmed assumptions, or one time examples as durable memory.
5. If new information conflicts with existing memory, flag the conflict and ask which version is correct.

## Work style
1. Focus on the requested outcome rather than narrating every internal step.
2. Keep recommendations practical and specific.
3. Use existing skills when a task matches a documented process.
4. Save requested deliverables in the outputs folder using descriptive file names.
5. Report any files created or modified at the end of the task.

## Quality control
Before presenting final work, verify that it:

- Matches the requested outcome
- Uses the relevant workspace context
- Follows documented preferences
- Does not rely on unsupported assumptions
- Is complete and ready to use
```

Adjust these rules when you discover a better way for Claude to work with you.

## 4. Build an editable memory system

The memory file should contain stable information that will matter in future sessions. It should not become a transcript of everything you say.

Paste this structure into `memory.md`:

```markdown
# Memory

## Identity
- Name: Not provided
- Role: Not provided
- Organization: Not provided

## Current priorities
- Not provided

## Durable goals
- Not provided

## Working preferences
- Communication style: Not provided
- Preferred output formats: Not provided
- Decision making preferences: Not provided
- Tools commonly used: Not provided

## Established decisions
- Not provided

## Important constraints
- Not provided

## Lessons and feedback
- Not provided

## Last reviewed
- Date: Not provided
```

Review this file periodically. Correct outdated facts and remove details that are no longer useful. Editable memory prevents an incorrect assumption, such as a changed preference, from affecting future output.

## 5. Onboard Claude with your context

The context folder explains who you are, what you do, and what you are trying to achieve. Use voice transcription if speaking is faster than typing.

Start an onboarding conversation with this prompt:

```text
Help me populate the context files in this workspace.

Interview me one focused question at a time. Cover:

1. My role and responsibilities
2. My business or personal situation
3. My products, services, or recurring projects
4. My current goals and priorities
5. My typical workflows
6. My tools and information sources
7. My preferred communication and output style
8. Important constraints, standards, and dislikes
9. Decisions or facts that should remain in long term memory

Ask follow-up questions when an answer is unclear. Do not invent missing details.

When the interview is complete:

1. Update context/profile.md
2. Update context/goals.md
3. Update context/work.md
4. Update context/preferences.md
5. Propose the durable facts that should be added to memory.md
6. Ask for my approval before adding anything that is uncertain
7. Show me a concise summary of every file changed
```

A business workspace might document customers, offers, team responsibilities, production processes, and performance goals. A personal workspace might document finances, fitness goals, calendar routines, and household processes.

## 6. Prompt for outcomes, not every intermediate action

Once Claude has good context, prompts can become shorter. State the outcome you want, the required deliverable, and any real constraints. Avoid prescribing every reasoning step unless the process itself must be followed exactly.

Use this general prompt template:

```text
Outcome: [Describe the result you want.]

Deliverable: [Name the document, analysis, plan, file, or decision you need.]

Requirements:
- [Required condition]
- [Required format]
- [Relevant deadline or constraint]

Use the relevant workspace context and existing skills. Ask only if missing information would materially change the result. Save the final deliverable to the outputs folder and tell me which files you changed.
```

Example:

```text
Outcome: Prepare me for tomorrow's client renewal meeting.

Deliverable: A concise meeting brief containing the client's goals, completed work, unresolved issues, likely objections, and recommended next actions.

Requirements:
- Use the client information available in this workspace
- Separate confirmed facts from assumptions
- Keep the brief under two pages

Save the final brief to the outputs folder and tell me which sources you used.
```

## 7. Turn your process into a reusable skill

A skill teaches Claude how you perform a repeatable task. Examples include client onboarding, monthly reconciliation, video scripting, research, file organization, or contract review.

### Create a skill through an interview

Use this prompt with Claude's skill creator or within your workspace:

```text
Create a reusable skill for this process:

Process name: [Name the process]
Desired outcome: [Describe a successful result]

Interview me about how I perform the process. Ask about:

1. Required inputs
2. The order of operations
3. Decision points
4. Tools and data sources
5. Quality standards
6. Common mistakes
7. Exceptions
8. The final output format
9. How success should be verified

Ask one focused question at a time. When the interview is complete, draft the skill, run a small test, and ask me for feedback. Incorporate my corrections into the skill before treating it as complete.
```

### Create a skill from a screen recording

If skill recording is available in your Claude interface, record yourself completing a real task while explaining:

1. What you are trying to accomplish
2. Why you take each important action
3. What information you inspect
4. How you make decisions
5. What errors or exceptions you watch for
6. How you know the task is complete

After recording, use this refinement prompt:

```text
Convert this recording into a reusable skill.

Document the required inputs, ordered procedure, decision rules, exceptions, output format, and completion checks. Distinguish required steps from personal habits that do not affect the result.

Then test the skill on a small example. Show me the result and ask for corrections before updating the final skill.
```

Keep improving the skill when Claude produces an output you like or dislike. Explain the specific difference, then ask Claude to update the skill accordingly.

## 8. Add connectors and plugins only where they support the workflow

Connectors act as bridges between Claude and external tools or data sources. Depending on what is available in your connector library, this can include services such as Google Drive, Notion, calendars, finance data sources, or media tools.

Use connectors when Claude needs to retrieve current information or take action outside the local workspace.

| Need | Possible setup |
|---|---|
| Organize production files | Google Drive connector plus a file organization skill |
| Read or update tasks | Notion connector plus a task management skill |
| Retrieve current market data | A suitable finance data connector |
| Prepare for meetings | Calendar or meeting data connector |

After adding a connector, test it with a narrow request:

```text
Confirm whether you can access [tool or data source].

Retrieve one small example relevant to my workspace. Explain what information you can read and what actions you can perform. Do not make broader changes during this test.
```

Plugins provide specialized assistance in areas such as design, data, legal work, marketing, engineering, and productivity. Install the relevant plugin, then name it in the request:

```text
Review this contract using the installed legal plugin. Identify important obligations, unusual clauses, risks, and questions that require professional clarification. Separate direct observations from interpretation.
```

For work requiring broader source collection and a structured report, enable research mode before submitting the request.

## 9. Automate a recurring task

In Cowork, scheduled tasks can run recurring workflows. Their usefulness increases when the required connectors and skills are already configured.

Example morning briefing prompt:

```text
Every morning at 9:00, prepare a concise briefing using the connected sources available to you.

Include:

1. Important changes since the previous briefing
2. Items requiring my attention
3. Upcoming meetings or deadlines
4. High priority messages
5. Recommended next actions

Use confirmed information only. Clearly label unavailable data instead of guessing. Send me the briefing and save a dated copy in the outputs folder.
```

Other useful scheduled workflows include:

- Sorting overnight emails by importance
- Producing a weekly summary of business messages
- Preparing context before a scheduled meeting
- Reviewing a portfolio or operational dashboard
- Checking whether recurring files have been organized correctly

If you use Dispatch to access Cowork or Claude Code from your phone, the connected computer must remain on for Claude to access its local files.

## 10. Map advanced workflows before automating them

For a complex goal, first break it into a graph of connected steps. Each step should have an input, an action, a tool, and a verifiable output.

Use this workflow mapping prompt:

```text
Turn the following goal into an automation graph:

Goal: [Describe the final outcome]

For each step, specify:

1. Required input
2. Action to perform
3. Skill to use
4. Connector or tool required
5. Expected output
6. Verification check
7. What triggers the next step
8. What should happen if verification fails

Show dependencies between steps. Identify which steps require human approval and which could run autonomously. Do not execute the workflow yet.
```

For example, the goal of landing and onboarding a client could become:

1. Identify target prospects
2. Verify which prospects match the criteria
3. Enrich approved records with contact data
4. Conduct outreach
5. Monitor the CRM for responses
6. Begin the documented onboarding skill after approval

In Claude Code, recurring execution can be combined conceptually with `/goal` for a verifiable outcome and `/loop` for an execution interval. Begin with a small, observable process before using loops for consequential work.

## Final setup checklist

Before relying on the workspace, confirm that:

- Cowork or Claude Code is connected to the correct folder
- `instructions.md` contains the memory update rules
- `memory.md` contains only durable, verified information
- The context files accurately describe your work and goals
- Claude reports every memory change
- At least one repeatable process has been documented as a skill
- Each connector has been tested with a narrow request
- Scheduled tasks have a clear output and verification method
- You periodically review and correct the memory file

The central principle is simple: keep your prompts focused on outcomes, and invest most of the setup effort in context, editable memory, instructions, skills, and reliable tool connections.